from __future__ import annotations

import ast
import copy
import json
import operator
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..non_engineering_evaluation import classify_conversational_courtesy


ROUTES = {
    "courtesy", "utility", "assistant_identity", "assistant_capabilities",
    "executor_identity", "company_information", "equipment_overview",
    "project_fact_intake", "engineering_consultation",
}

DETERMINISTIC_HANDLERS = {
    "courtesy": "courtesy",
    "utility": "utility",
    "assistant_identity": "assistant_identity",
    "assistant_capabilities": "assistant_capabilities",
    "executor_identity": "executor_identity_policy",
    "company_information": "safe_response",
    "equipment_overview": "safe_response",
    "project_fact_intake": "safe_response",
}

_DOMAIN_RE = re.compile(
    r"\b(?:парковк\w*|автоматизац\w*|шлагбаум\w*|госномер\w*|номер\w*|"
    r"карт\w*|билет\w*|rfid|qr|въезд\w*|выезд\w*)\b", re.I,
)
_ENGINEERING_RE = re.compile(
    r"\b(?:что\s+выбрать|что\s+лучше|сравни\w*|порекоменду\w*|посовет\w*|"
    r"как\s+автоматизир\w*|хочу\s+автоматизир\w*)\b", re.I,
)
_PROJECT_FACT_SIGNALS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(?:бизнес[- ]?центр|торгов\w+\s+центр|жил\w+\s+комплекс|склад)\b", re.I),
    re.compile(r"\b\d+\s+въезд\w*\b", re.I),
    re.compile(r"\b\d+\s+выезд\w*\b", re.I),
    re.compile(r"\b\d+\s+(?:машин|автомобил)\w*\s+(?:в|за)\s+(?:день|сутки)\b", re.I),
    re.compile(r"\b(?:сотрудник\w*|арендатор\w*|гост\w*)\b", re.I),
    re.compile(r"\bоператор\w*\b", re.I),
    re.compile(r"\b(?:быстр\w*|скорост\w*)\s+автоматическ\w+\s+проезд\w*\b", re.I),
    re.compile(r"\b(?:обязательн\w+\s+)?автоматическ\w+\s+резерв\w*\b", re.I),
)
_EXECUTOR_RE = re.compile(
    r"\b(?:какая|какой|что\s+за)\s+(?:у\s+тебя\s+)?(?:модель|версия)|"
    r"\b(?:qwen|codex|ollama|openai|alibaba|tongyi)|\bкогда\s+(?:тебя|вы)\s+создал", re.I,
)
_IDENTITY_RE = re.compile(r"\b(?:кто\s+ты|ты\s+кто|представься)\b", re.I)
_CAPABILITY_RE = re.compile(
    r"\b(?:чем\s+(?:ты\s+)?можешь\s+помочь|что\s+ты\s+умеешь|"
    r"на\s+какие\s+вопросы\s+(?:ты\s+)?можешь\s+ответить)\b", re.I,
)
_COMPANY_RE = re.compile(
    r"\b(?:что\s+(?:ты\s+)?знаешь\s+(?:о|про)\s+роспарк|"
    r"расскажи\w*\s+(?:о|про)\s+роспарк|что\s+такое\s+роспарк)\b", re.I,
)
_EQUIPMENT_RE = re.compile(
    r"\b(?:расскажи\w*|что\s+есть|какое)\b.{0,40}\bоборудован\w*\b|"
    r"\bоборудование\s+роспарк\b", re.I,
)
_ARITHMETIC_RE = re.compile(r"^\s*(?:сколько\s+будет\s*)?(\d+(?:\s*[+\-*/]\s*\d+)+)\s*=*\s*\??\s*$", re.I)

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}


@dataclass(frozen=True)
class SemanticRoute:
    name: str
    deterministic_handler: str | None
    controller_bypass: bool
    engineering_bypass: bool
    reason_codes: tuple[str, ...] = ()


def classify_route(message: str) -> SemanticRoute:
    text = " ".join(str(message or "").split())
    # Содержательный запрос всегда важнее приветственной вводной.
    if _DOMAIN_RE.search(text) and _ENGINEERING_RE.search(text):
        return SemanticRoute("engineering_consultation", None, False, False)
    project_signal_count = sum(bool(pattern.search(text)) for pattern in _PROJECT_FACT_SIGNALS)
    if project_signal_count >= 2 and "?" not in text:
        return SemanticRoute("project_fact_intake", "safe_response", False, True)
    if classify_conversational_courtesy(text) or re.fullmatch(
        r"\s*(?:и\s+снова\s+|ещ[её]\s+раз\s+)?(?:привет|здравствуйте)[!.?\s]*",
        text, re.I,
    ):
        return SemanticRoute("courtesy", "courtesy", True, True)
    if _ARITHMETIC_RE.fullmatch(text):
        return SemanticRoute("utility", "utility", True, True)
    if _EXECUTOR_RE.search(text):
        return SemanticRoute("executor_identity", "executor_identity_policy", True, True)
    if _IDENTITY_RE.search(text) and _CAPABILITY_RE.search(text):
        return SemanticRoute("assistant_identity", "assistant_identity", True, True)
    if _IDENTITY_RE.search(text):
        return SemanticRoute("assistant_identity", "assistant_identity", True, True)
    if _CAPABILITY_RE.search(text):
        return SemanticRoute("assistant_capabilities", "assistant_capabilities", True, True)
    if _COMPANY_RE.search(text):
        return SemanticRoute("company_information", "safe_response", True, True)
    if _EQUIPMENT_RE.search(text):
        return SemanticRoute("equipment_overview", "safe_response", True, True)
    return SemanticRoute("engineering_consultation", None, False, False)


def _safe_arithmetic(message: str) -> str:
    match = _ARITHMETIC_RE.fullmatch(message)
    if not match:
        return "Не удалось распознать арифметическое выражение."
    node = ast.parse(match.group(1), mode="eval")

    def visit(item: ast.AST) -> float:
        if isinstance(item, ast.Expression):
            return visit(item.body)
        if isinstance(item, ast.Constant) and type(item.value) in {int, float}:
            return float(item.value)
        if isinstance(item, ast.BinOp) and type(item.op) in _OPS:
            return _OPS[type(item.op)](visit(item.left), visit(item.right))
        raise ValueError("unsupported_arithmetic")

    value = visit(node)
    rendered = str(int(value)) if value.is_integer() else str(value)
    return f"{match.group(1).replace(' ', '')} = {rendered}."


class VerifiedPublicKnowledge:
    def __init__(self, path: Path) -> None:
        self.path = path

    def load(self) -> dict[str, Any] | None:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        required = {"company_information", "equipment_overview", "source_manifest"}
        return value if required <= set(value) else None


def deterministic_answer(
    route: SemanticRoute, message: str, knowledge: dict[str, Any] | None,
) -> tuple[str, tuple[str, ...]]:
    turn = classify_conversational_courtesy(message)
    if route.name == "courtesy":
        answers = {
            "greeting": "Здравствуйте! Чем могу помочь по парковке или автоматизации объекта?",
            "thanks": "Пожалуйста! Если появится вопрос по парковке или автоматизации, обращайтесь.",
            "acknowledgement": "Хорошо, понял.",
            "farewell": "До свидания! Хорошего дня.",
            "small_talk": "Здравствуйте! Чем могу помочь по парковке или автоматизации объекта?",
        }
        return answers.get(turn or "small_talk", answers["small_talk"]), ()
    if route.name == "utility":
        return _safe_arithmetic(message), ()
    if route.name == "assistant_identity":
        return (
            "Я AI-консультант РОСПАРК. Помогаю разобраться в автоматизации парковок, "
            "доступе, оплате и предварительном подборе решения.", ()
        )
    if route.name == "assistant_capabilities":
        return (
            "Я отвечаю на вопросы об автоматизации парковок, способах доступа и оплаты, "
            "оборудовании РОСПАРК и помогаю собрать исходные данные для предварительного подбора.", ()
        )
    if route.name == "executor_identity":
        return (
            "Я AI-консультант РОСПАРК. Внутренний исполнитель и его версия не являются "
            "частью публичной консультации; моя задача — помогать по парковкам и их автоматизации.", ()
        )
    if route.name == "project_fact_intake":
        return (
            "Зафиксировал параметры объекта и ваши требования. "
            "Финальную архитектуру пока не выбираю.",
            ("decision_pending",),
        )
    if knowledge is None:
        return (
            "Сейчас я не могу подтвердить сведения по корпоративной базе знаний, поэтому не буду их придумывать.",
            ("required_knowledge_unavailable",),
        )
    if route.name == "company_information":
        return str(knowledge["company_information"]["answer"]), ()
    if route.name == "equipment_overview":
        return str(knowledge["equipment_overview"]["answer"]), ()
    raise ValueError("deterministic_route_not_supported")


def recover_trusted_user_facts(
    state: Any, history: list[dict[str, Any]], *, state_version: int,
) -> tuple[list[str], list[str]]:
    recovered: list[str] = []
    reasons: list[str] = []
    patterns: tuple[tuple[str, re.Pattern[str], Any], ...] = (
        ("object_type", re.compile(r"\bбизнес[- ]?центр\b", re.I), lambda _: "business_center"),
        ("entrances_count", re.compile(r"\b(\d+)\s+въезд\w*\b", re.I), lambda m: int(m.group(1))),
        ("exits_count", re.compile(r"\b(\d+)\s+выезд\w*\b", re.I), lambda m: int(m.group(1))),
        ("daily_traffic", re.compile(r"\b(?:поток\w*\s+)?(?:около\s+)?(\d+)\s+(?:машин|автомобил)\w*\s+(?:в|за)\s+(?:день|сутки)\b", re.I), lambda m: int(m.group(1))),
        ("operator_present", re.compile(r"\bоператор\s+(?:есть|присутствует)\b", re.I), lambda _: True),
        ("speed_priority", re.compile(r"\b(?:максимальн\w+\s+)?быстр\w+\s+автоматическ\w+\s+проезд\w*\b", re.I), lambda _: "high"),
        ("mandatory_automated_fallback", re.compile(r"\b(?:обязательн\w+\s+)?автоматическ\w+\s+резерв\w*\b", re.I), lambda _: True),
    )
    for item in history:
        if item.get("role") != "user":
            continue
        content = str(item.get("content") or "")
        source_id = str(item.get("message_id") or "history_user")
        timestamp = str(item.get("timestamp") or item.get("created_at") or "1970-01-01T00:00:00Z")
        for field, pattern, converter in patterns:
            match = pattern.search(content)
            if not match or field in state.confirmed_facts:
                continue
            state.confirmed_facts[field] = {
                "value": converter(match), "source_message_id": source_id,
                "confirmed_at": timestamp, "version": max(1, state_version),
                "conflict_state": "none",
            }
            recovered.append(field)
            if field == "daily_traffic" and re.search(r"\b(?:около|примерно|порядка)\b", content, re.I):
                state.confirmed_facts["daily_traffic_certainty"] = {
                    "value": "approximate", "source_message_id": source_id,
                    "confirmed_at": timestamp, "version": max(1, state_version),
                    "conflict_state": "none",
                }
                recovered.append("daily_traffic_certainty")
        if "сотруд" in content.casefold() or "арендатор" in content.casefold() or "гост" in content.casefold():
            segments = [name for token, name in (("сотруд", "employees"), ("арендатор", "tenants"), ("гост", "guests")) if token in content.casefold()]
            if segments and "user_segments" not in state.confirmed_facts:
                state.confirmed_facts["user_segments"] = {
                    "value": segments, "source_message_id": source_id,
                    "confirmed_at": timestamp, "version": max(1, state_version),
                    "conflict_state": "none",
                }
                recovered.append("user_segments")
    if any(item.get("role") == "user" and _DOMAIN_RE.search(str(item.get("content") or "")) for item in history) and not recovered and not state.confirmed_facts:
        reasons.append("trusted_user_fact_not_recovered")
    return recovered, reasons


def remove_executor_disclosure(answer: str) -> tuple[str, bool]:
    fragments = re.split(r"(?<=[.!?])\s+", str(answer or ""))
    forbidden = re.compile(r"\b(?:qwen|codex|ollama|alibaba|tongyi|openai|верси\w+\s+модел\w*)\b", re.I)
    kept = [fragment for fragment in fragments if not forbidden.search(fragment)]
    changed = len(kept) != len(fragments)
    clean = " ".join(item.strip() for item in kept if item.strip())
    if changed and not clean:
        clean = "Я AI-консультант РОСПАРК."
    return clean, changed
