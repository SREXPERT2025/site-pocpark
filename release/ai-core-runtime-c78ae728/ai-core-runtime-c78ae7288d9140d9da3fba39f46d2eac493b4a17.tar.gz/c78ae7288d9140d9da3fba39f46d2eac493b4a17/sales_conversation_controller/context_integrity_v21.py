from __future__ import annotations

import ast
import operator
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

from .context_integrity_v2 import (
    LINK_TOPICS,
    OBJECT_TYPES,
    SOURCE_ROUTES,
    AnswerLinkDecision,
    ContextIntentIntegrityLayerV2,
    ExpectedQuestion,
    FinalIntegrityResult,
    IntegrityResolution,
    IntegrityState as IntegrityStateV2,
    RetrievalPlan,
    TurnIngestion,
)


EVALUATION_STATUSES = {"pass", "fail", "insufficient_evidence", "not_applicable"}
SUPPORTED_FACT_FIELDS = (
    "object_type", "entrances_count", "exits_count", "daily_traffic",
    "permanent_users_share", "entry_price_rub", "current_system", "timeline",
    "location", "budget_status",
)
OPTION_PATTERNS = {
    "license_plate": r"\b(?:госномер\w*|номер\w*\s+автомобил\w*|распознаван\w+\s+номер\w*)\b",
    "card": r"\b(?:rfid[- ]?)?карт\w*\b",
    "ticket": r"\bбилет\w*\b",
    "qr": r"\bqr[- ]?код\w*\b",
}
DIMENSION_PATTERNS = {
    "speed": r"\b(?:скорост|быстр|медлен)\w*\b",
    "convenience": r"\bудоб\w*\b",
    "reliability": r"\bнад[её]ж\w*\b",
    "cost": r"\b(?:цен|стоимост|затрат)\w*\b",
}
RECOMMENDATION_PATTERN = re.compile(
    r"\b(?:рекоменду\w*|лучше\s+(?:выбрать|использовать|рассматривать)|"
    r"предпочтител\w*|оптималь\w+\s+(?:(?:вариант|схем|комбинир)\w*|будет)|целесообразн\w*|"
    r"имеет\s+смысл|основн\w+\s+способ\w*\s+стоит\s+сделать|я\s+бы\s+выбрал\w*|"
    r"для\s+ваш\w+\s+сценари\w+\s+подход\w*)\b",
    re.I,
)
RECOMMENDATION_BASIS_PATTERN = re.compile(
    r"\b(?:потому\s+что|так\s+как|учитывая|для\s+(?:(?:ваш|постоян|разов|гост|сотруд|аренд|разн)\w*|такого\s+(?:объекта|трафика))|"
    r"при\s+(?:так|этом|налич|поток)|это\s+позволит|зависит|основн\w+\s+способ|резерв)\b",
    re.I,
)
ARITHMETIC_RE = re.compile(
    r"(?:\b(?:скок|сколько|сколька)(?:\s+будет|\s+получится)?|\b(?:посчитай|посчетай|реши)|"
    r"\bчему\s+равно)?\s*(\d+(?:\s*[+\-*/]\s*\d+)+)\s*=*\s*\??$",
    re.I,
)


@dataclass
class IntegrityStateV21(IntegrityStateV2):
    active_comparison: dict[str, Any] | None = None
    last_artifact: dict[str, Any] | None = None


IntegrityState = IntegrityStateV21


@dataclass(frozen=True)
class FinalIntegrityResultV21(FinalIntegrityResult):
    evaluation_status: str = "insufficient_evidence"
    no_proven_failure: bool = True
    all_required_assessments_pass: bool = False
    required_assessments: tuple[str, ...] = ()
    unknown_required_assessments: tuple[str, ...] = ()

    @property
    def passed(self) -> bool:
        return self.evaluation_status != "fail"

    @property
    def proven_passed(self) -> bool:
        return self.evaluation_status == "pass"

    def to_dict(self) -> dict[str, Any]:
        payload = super().to_dict()
        payload.update({
            "evaluation_status": self.evaluation_status,
            "no_proven_failure": self.no_proven_failure,
            "all_required_assessments_pass": self.all_required_assessments_pass,
            "required_assessments": list(self.required_assessments),
            "unknown_required_assessments": list(self.unknown_required_assessments),
            "passed": self.passed,
            "proven_passed": self.proven_passed,
        })
        return payload


class ContextIntentIntegrityLayerV21(ContextIntentIntegrityLayerV2):
    VERSION = "2.1"

    def process(
        self, *, conversation_id: str, message_id: str, raw_text: str,
        state: IntegrityStateV21, recent_messages: list[dict[str, str]] | None = None,
        timestamp: str | None = None,
    ) -> IntegrityResolution:
        normalized = self.normalize(raw_text)
        before = state.to_dict()
        expected = self._active_expected(state)
        independent = self._independent_request(normalized)
        link = self._link_expected(normalized, expected, independent)
        intent, command = self._intent_command(normalized, "standalone_request")
        facts, candidates = self._extract_facts(normalized, link, expected, command, message_id)
        relation = self._relation(normalized, expected, link, independent, intent)
        if relation == "answer_to_previous_question":
            intent, command = "answer_to_agent_question", "remember_fact"
        elif relation == "answer_plus_new_request":
            intent, command = self._intent_command(normalized, relation)
        elif relation == "request_to_recall":
            intent, command = "recall_request", "recall_facts"
        elif relation == "correction":
            intent, command = "correction", "remember_fact"

        topic_resolution = self._resolve_topic(normalized, state, relation, intent, command)
        topic = str(topic_resolution["topic"])
        answered = self._close_questions_by_facts(state, facts, message_id)
        updates = self._apply_preferences(state, normalized, command)
        conflicts = self._reconcile_facts(state, facts, message_id, relation)
        state.candidate_facts.extend(candidates)
        self._update_comparison(state, normalized, message_id)
        self._update_subject(state, topic_resolution, message_id)

        retrieval = self.build_retrieval(intent, topic, normalized, state.active_subject)
        if retrieval.required_route:
            state.last_artifact = {
                "type": "demo_page" if "/demo" in retrieval.required_route else "website_page",
                "route": retrieval.required_route,
                "source_message_id": message_id,
            }
        dependency = self._action_dependency(command, intent, state, conflicts, normalized)
        state.last_topic = topic or state.last_topic
        state.last_intent = intent
        state.last_user_message_id = message_id
        if message_id not in state.ingested_message_ids:
            state.ingested_message_ids.append(message_id)

        parent = expected.asked_at_message_id if expected and expected.question_id in answered else None
        reply_goal = expected.question_goal if expected and expected.question_id in answered else None
        ingestion = TurnIngestion(
            conversation_id=conversation_id, message_id=message_id,
            timestamp=timestamp or datetime.now(timezone.utc).isoformat(),
            raw_text=raw_text, normalized_text=normalized,
            parent_turn_id=parent, reply_to_question_goal=reply_goal,
        )
        requirements = self._command_requirements_v21(command, normalized, facts, retrieval, state)
        question_allowed = not bool(state.conversation_preferences.get("stop_questions"))
        if command in {"give_link", "be_brief", "stop_questions", "recall_facts"}:
            question_allowed = False
        return IntegrityResolution(
            ingestion=ingestion, version=self.VERSION, relation=relation, intent=intent,
            command=command, resolved_topic=topic, topic_resolution=topic_resolution,
            active_subject=state.active_subject,
            resolved_text=self._resolved_text(normalized, relation, expected, link, topic, command),
            required_action=self._required_action(intent, command),
            command_requirements=requirements, action_dependency=dependency,
            sales_motion_allowed=intent not in {
                "link_request", "identity_question", "simple_utility_question",
                "small_talk", "out_of_domain", "recall_request",
            },
            question_allowed=question_allowed, answer_link=link,
            answered_question_ids=tuple(answered), extracted_facts=facts,
            candidate_facts=tuple(candidates), state_updates=updates,
            retrieval=retrieval, state_before=before, state_after=state.to_dict(),
            conflicts=tuple(conflicts),
        )

    def _intent_command(self, text: str, relation: str) -> tuple[str, str]:
        if re.search(
            r"\b(?:спроси\s+(?:у\s+)?меня|задай\s+(?:мне\s+)?(?:один\s+)?вопрос|"
            r"что\s+(?:тебе|ещ[её])\s+(?:ещ[её]\s+)?нужно\s+узнать|уточни\s+у\s+меня|"
            r"можешь\s+спросить|давай\s+по\s+одному\s+вопросу|спрашивай\s+по\s+одному|"
            r"задавай\s+по\s+одному)\b", text,
        ):
            return "instruction_to_agent", "ask_one_question"
        if self._is_utility(text):
            return "simple_utility_question", "answer_directly"
        if re.search(r"\b(?:следующ\w+\s+(?:практическ\w+\s+)?шаг|что\s+дальше)\b", text):
            return "next_step_request", "handoff"
        return super()._intent_command(text, relation)

    @staticmethod
    def _is_utility(text: str) -> bool:
        if re.search(r"\bкакой\s+сегодня\s+день\s+недели\b", text):
            return True
        if re.search(r"\b(?:парковк|въезд|выезд|тариф|руб|модел|контроллер|полос)\w*", text):
            return False
        return bool(ARITHMETIC_RE.search(text))

    @staticmethod
    def _arithmetic_expression(text: str) -> str | None:
        match = ARITHMETIC_RE.search(text.strip())
        return re.sub(r"\s+", "", match.group(1)) if match else None

    @classmethod
    def _utility_answer(cls, text: str) -> str:
        expression = cls._arithmetic_expression(text)
        if expression:
            try:
                node = ast.parse(expression, mode="eval")
                allowed = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}

                def calculate(item: ast.AST) -> float:
                    if isinstance(item, ast.Expression):
                        return calculate(item.body)
                    if isinstance(item, ast.Constant) and isinstance(item.value, (int, float)):
                        return float(item.value)
                    if isinstance(item, ast.BinOp) and type(item.op) in allowed:
                        return allowed[type(item.op)](calculate(item.left), calculate(item.right))
                    raise ValueError("unsafe_expression")

                return f"{expression} = {calculate(node):g}."
            except (SyntaxError, ValueError, ZeroDivisionError):
                return "Не удалось безопасно вычислить выражение."
        return super()._utility_answer(text)

    def _resolve_topic(
        self, text: str, state: IntegrityStateV21, relation: str, intent: str, command: str,
    ) -> dict[str, Any]:
        rules: list[tuple[str, str, float]] = [
            ("utility_calculation", r"(?:\d+\s*[+\-*/]\s*\d+|день\s+недели)", 1.0),
            ("card_dispenser_capacity", r"\b(?:сколько|минимум|максимум|влез|залож)\w*\b.*\bкарт\w*|\bкарт\w*\b.*\b(?:стойк|диспенсер|влез)\w*", .98),
            ("ticket_roll_capacity", r"\bрулон\w*\b.*\b(?:проезд|хват|расход|билет)\w*|\b(?:проезд|хват)\w*\b.*\bрулон\w*", .98),
            ("maintenance_frequency", r"\b(?:как\s+часто|периодичност)\b.*\b(?:то|обслуживан)\w*|\bтехническ\w+\s+обслуживан\w*", .98),
            ("service_scope", r"\b(?:обслуживаете|сопровождаете|только\s+поставляете|сервис)\w*", .96),
            ("roi", r"\b(?:окупа|возврат\s+инвестиц)\w*", .98),
            ("commercial_configuration", r"\b(?:сборк|комплектаци)\w*\b.*\b(?:выгод|брать|выбрать)\w*", .96),
            ("diagnostic_explanation", r"\b(?:что\s+это\s+значит|объясни\s+это|почему\s+так)\b", .9),
            ("sales_feedback", r"\b(?:не\s+продажник|научи\w*\s+продавать|плохо\s+прода[её]шь|продаж\w+\s+навык)\b", .96),
            ("next_step_selection", r"\b(?:следующ\w+\s+(?:практическ\w+\s+)?шаг|консультаци|обследовани\w+\s+объект|расч[её]т\s+проект)\b", .92),
            ("access_identifier_selection", r"\b(?:что\s+(?:лучше\s+)?выбрать|что\s+лучше|сравни)\b.*\b(?:госномер|карт|билет)\w*", .98),
            ("solution_selection", r"\b(?:что\s+подойд[её]т|какое\s+решение|что\s+посовету)\w*\b.*\b(?:объект|парковк)\w*", .86),
        ]
        for topic, pattern, confidence in rules:
            matches = re.findall(pattern, text, re.I)
            if matches:
                return {
                    "topic": topic, "scores": {topic: confidence},
                    "matched_features": [str(item) for item in matches[:5]],
                    "rejected_features": [], "confidence": confidence,
                    "source": "current_turn",
                }
        base = super()._resolve_topic(text, state, relation, intent, command)
        if base.get("source") == "active_subject" and base.get("topic") in {
            "tenant_payment_demo", "guest_demo", "online_payment",
        } and state.active_subject:
            semantic_topic = str(state.active_subject.get("topic") or base["topic"])
            base = {
                "topic": semantic_topic, "scores": {semantic_topic: float(base.get("confidence", .8))},
                "matched_features": ["structured_semantic_subject_reference"],
                "rejected_features": ["route_topic_kept_as_artifact"],
                "confidence": float(base.get("confidence", .8)), "source": "active_subject",
            }
        if base.get("topic") == "comparison_identifiers":
            base = dict(base)
            base["topic"] = "access_identifier_selection"
            base["scores"] = {"access_identifier_selection": max(base.get("scores", {}).values(), default=.8)}
        elif command == "compare_options" and state.active_comparison and state.active_comparison.get("options"):
            base = {
                "topic": "access_identifier_selection", "scores": {"access_identifier_selection": .9},
                "matched_features": ["active_comparison"], "rejected_features": [],
                "confidence": .9, "source": "active_comparison",
            }
        return base

    def _update_comparison(self, state: IntegrityStateV21, text: str, message_id: str) -> None:
        options = [key for key, pattern in OPTION_PATTERNS.items() if re.search(pattern, text)]
        dimensions = [key for key, pattern in DIMENSION_PATTERNS.items() if re.search(pattern, text)]
        if not options and not dimensions:
            return
        current = dict(state.active_comparison or {})
        current["options"] = list(dict.fromkeys(current.get("options", []) + options))
        current["dimensions"] = list(dict.fromkeys(current.get("dimensions", []) + dimensions))
        current["source_message_ids"] = list(dict.fromkeys(current.get("source_message_ids", []) + [message_id]))
        current["status"] = "active"
        state.active_comparison = current

    @staticmethod
    def _subject_key(subject: dict[str, Any]) -> str:
        entities = subject.get("entities") or {}
        normalized_entities = ";".join(f"{key}={entities[key]}" for key in sorted(entities))
        return f'{subject.get("topic", "")}|{normalized_entities}|{subject.get("action", "")}'

    def _update_subject(self, state: IntegrityStateV21, topic_resolution: dict[str, Any], message_id: str) -> None:
        topic = str(topic_resolution.get("topic") or "")
        if topic in {
            "general", "assistant_identity", "utility", "utility_calculation", "pricing",
            "tenant_payment_demo", "guest_demo", "demo_catalog", "contacts",
        } or not topic_resolution.get("confidence"):
            return
        entities: dict[str, str] = {}
        action = ""
        if topic == "tenant_pays_guest_parking":
            entities = {"payer": "tenant", "parking_user": "guest"}
            action = "pay_parking"
        elif topic == "guest_self_payment":
            entities = {"payer": "guest", "parking_user": "guest"}
            action = "pay_parking"
        subject = {
            "topic": topic, "entities": entities, "action": action,
            "source_message_ids": [message_id], "confidence": float(topic_resolution.get("confidence", 0.0)),
            "status": "active",
        }
        key = self._subject_key(subject)
        existing = [item for item in state.subject_stack if self._subject_key(item) == key]
        if existing:
            merged_sources = [source for item in existing for source in item.get("source_message_ids", [])]
            subject["source_message_ids"] = list(dict.fromkeys(merged_sources + [message_id]))
            subject["confidence"] = max([float(item.get("confidence", 0.0)) for item in existing] + [subject["confidence"]])
        deduped: list[dict[str, Any]] = []
        seen: set[str] = {key}
        for item in reversed(state.subject_stack):
            item_key = self._subject_key(item)
            if item_key in seen:
                continue
            copy = dict(item)
            copy["status"] = "recent"
            deduped.append(copy)
            seen.add(item_key)
        state.active_subject = subject
        state.subject_stack = [subject] + deduped[:4]

    def build_retrieval(self, intent: str, topic: str, normalized: str, subject: dict[str, Any] | None) -> RetrievalPlan:
        plan = super().build_retrieval(intent, topic, normalized, subject)
        subject_topic = str((subject or {}).get("topic") or "")
        route = plan.required_route
        if intent in {"link_request", "demo_link_request"} and subject_topic == "tenant_pays_guest_parking":
            route = LINK_TOPICS["tenant_payment_demo"]
        return RetrievalPlan(plan.intent, topic, plan.query, plan.required_artifact_type, plan.allowed_sources, route)

    def _command_requirements_v21(
        self, command: str, text: str, facts: dict[str, Any], retrieval: RetrievalPlan,
        state: IntegrityStateV21,
    ) -> dict[str, Any]:
        requirements = super()._command_requirements(command, text, facts, retrieval)
        if command == "compare_options":
            current_options = [key for key, pattern in OPTION_PATTERNS.items() if re.search(pattern, text)]
            current_dimensions = [key for key, pattern in DIMENSION_PATTERNS.items() if re.search(pattern, text)]
            frame = state.active_comparison or {}
            requirements["required_options"] = current_options or list(frame.get("options", []))
            requirements["required_dimensions"] = current_dimensions or list(frame.get("dimensions", []))
            requirements["requirements_source"] = {
                "options": "current_turn" if current_options else "active_comparison" if frame.get("options") else "unknown",
                "dimensions": "current_turn" if current_dimensions else "active_comparison" if frame.get("dimensions") else "unknown",
            }
        if command == "recommend":
            requirements.update(
                recommended_option_present=True,
                recommendation_basis_present=True,
                conditionality_handled=True,
            )
        if command == "ask_one_question":
            goal, question = self._next_question(state)
            requirements.update(next_question_goal=goal, deterministic_question=question)
        return requirements

    def _command_requirements(self, command: str, text: str, facts: dict[str, Any], retrieval: RetrievalPlan) -> dict[str, Any]:
        return super()._command_requirements(command, text, facts, retrieval)

    @staticmethod
    def _next_question(state: IntegrityStateV21) -> tuple[str | None, str | None]:
        candidates = (
            ("identify_object_type", "Какой у вас тип объекта?", "object_type"),
            ("identify_entrances_count", "Сколько въездов планируется оборудовать?", "entrances_count"),
            ("identify_current_system", "Какая система сейчас установлена?", "current_system"),
        )
        for goal, question, field_name in candidates:
            if field_name not in state.confirmed_facts:
                return goal, question
        return None, None

    def _action_dependency(
        self, command: str, intent: str, state: IntegrityStateV21,
        conflicts: list[dict[str, Any]], text: str = "",
    ) -> dict[str, Any]:
        subtype = command
        required: list[str] = []
        if command == "recommend":
            required = ["object_type", "entrances_count", "daily_traffic"]
            subtype = "recommend_configuration"
        elif command == "handoff":
            if re.search(r"\bобследовани\w*\b", text):
                subtype = "next_step_site_survey"
            elif re.search(r"\bрасч[её]т\w*\b", text):
                subtype = "next_step_calculation"
                required = ["object_type", "entrances_count", "exits_count", "daily_traffic"]
            elif re.search(r"\bконсультаци\w*\b", text):
                subtype = "next_step_consultation"
            elif intent == "contact_request":
                subtype = "request_contact"
        open_conflicts = [item for item in state.conflicts if item.get("status") == "open"]
        conflicting = sorted({str(item.get("field")) for item in open_conflicts if item.get("field") in required})
        return {
            "action": subtype, "required_facts": required,
            "conflicting_required_facts": conflicting, "blocking": bool(conflicting),
        }

    def required_assessments_for(
        self, resolution: IntegrityResolution, answer: str, claim_types: list[str],
    ) -> tuple[str, ...]:
        required = ["context"]
        if not (resolution.intent == "instruction_to_agent" and resolution.resolved_topic == "general"):
            required.insert(0, "topic")
        if resolution.command not in {"answer_directly", "explain", "be_brief"} or resolution.intent == "simple_utility_question":
            required.append("command")
        if resolution.command in {"recommend", "recall_facts", "remember_fact"} or any(
            item in {"recalled_confirmed_fact", "new_product_claim", "numeric_product_claim"}
            for item in claim_types
        ):
            required.append("fact")
        if resolution.command in {"compare_options", "give_link"} or any(
            item in {"new_product_claim", "numeric_product_claim"} for item in claim_types
        ):
            required.append("source")
        if resolution.command == "give_link":
            required.append("link")
        if resolution.command in {"ask_one_question", "stop_questions"}:
            required.append("question")
        return tuple(dict.fromkeys(required))

    def final_check(
        self, answer: str, resolution: IntegrityResolution, state: IntegrityStateV21,
        knowledge_package: Any | None = None,
    ) -> FinalIntegrityResultV21:
        clean = " ".join(str(answer or "").split())
        lower = clean.lower()
        topic = self._assess_topic(lower, resolution)
        command = self._assess_command(lower, resolution, state)
        fact, claim_types, numeric_claims = self._assess_facts(lower, resolution, state)
        question = self._assess_questions(clean, resolution)
        link = self._assess_link(clean, resolution)
        source = self._assess_source(lower, resolution, knowledge_package, claim_types, numeric_claims, link)
        context = self._assess_current_turn(lower, resolution, topic, command)
        assessments = {
            "topic": topic, "command": command, "fact": fact, "question": question,
            "link": link, "source": source, "context": context,
        }
        required = self.required_assessments_for(resolution, lower, claim_types)
        unknown = tuple(name for name in required if assessments[name].get("result") == "unknown")
        failures = tuple(name for name in required if assessments[name].get("result") == "fail")
        if failures:
            status = "fail"
        elif not required:
            status = "not_applicable"
        elif unknown:
            status = "insufficient_evidence"
        else:
            status = "pass"
        violations: list[str] = [f"{name}_assessment_failed" for name in failures]
        violations.extend(command.get("missing_requirements", []))
        if fact.get("contradictions"):
            violations.append("confirmed_fact_contradiction")
        fallback_type, fallback = self._fallback(resolution, state, violations)
        return FinalIntegrityResultV21(
            topic_assessment=topic, command_assessment=command, fact_assessment=fact,
            question_assessment=question, link_assessment=link, source_assessment=source,
            context_assessment=context, violations=tuple(dict.fromkeys(violations)),
            fallback_type=fallback_type, fallback_answer=fallback,
            evaluation_status=status, no_proven_failure=not failures,
            all_required_assessments_pass=status == "pass",
            required_assessments=required, unknown_required_assessments=unknown,
        )

    def _assess_questions(self, answer: str, resolution: IntegrityResolution) -> dict[str, Any]:
        count = self.semantic_question_count(answer)
        if resolution.command == "ask_one_question":
            result = "pass" if count == 1 else "fail"
            required = 1
        elif resolution.command == "stop_questions":
            result = "pass" if count == 0 else "fail"
            required = 0
        else:
            result = "unknown"
            required = 0
        return {"result": result, "semantic_question_count": count, "required_count": required}

    @staticmethod
    def _assess_link(answer: str, resolution: IntegrityResolution) -> dict[str, Any]:
        required_route = resolution.retrieval.required_route
        routes = re.findall(r"(?:https?://\S+|/[-\w./]+)", answer)
        required = resolution.command == "give_link"
        result = "unknown" if not required or not required_route else "pass" if required_route in routes else "fail"
        return {
            "result": result, "required": required, "present": bool(routes),
            "route_verified": bool(required_route and required_route in routes),
            "required_route": required_route,
        }

    def _assess_current_turn(
        self, answer: str, resolution: IntegrityResolution, topic: dict[str, Any], command: dict[str, Any],
    ) -> dict[str, Any]:
        required_entities: list[str] = []
        covered_entities: list[str] = []
        reasons: list[str] = []
        expression = self._arithmetic_expression(resolution.ingestion.normalized_text)
        if expression:
            required_entities.append(f"calculation:{expression}")
            expected = self._utility_answer(resolution.ingestion.normalized_text)
            expected_value = re.search(r"=\s*(-?\d+(?:\.\d+)?)", expected)
            if expected_value and re.search(rf"(?:=\s*)?{re.escape(expected_value.group(1))}(?:\D|$)", answer):
                covered_entities.append(f"calculation:{expression}")
            else:
                reasons.append("answer_does_not_address_current_request")
        for name, pattern in OPTION_PATTERNS.items():
            if re.search(pattern, resolution.ingestion.normalized_text):
                required_entities.append(f"option:{name}")
                if re.search(pattern, answer):
                    covered_entities.append(f"option:{name}")
        if resolution.resolved_topic == "maintenance_frequency":
            required_entities.append("maintenance_frequency")
            if re.search(r"\b(?:зависит|периодичност|по\s+регламенту|раз\s+в|ежемесяч|ежегод|кажд\w+\s+\d)\w*", answer):
                covered_entities.append("maintenance_frequency")
            else:
                reasons.append("maintenance_frequency_not_answered")
        if resolution.command in {"ask_one_question", "stop_questions", "give_link", "compare_options", "recommend", "handoff"}:
            if command.get("result") == "pass":
                covered_entities.append(f"command:{resolution.command}")
            elif command.get("result") == "fail":
                reasons.append("current_command_not_fulfilled")
        if topic.get("result") == "pass" and not required_entities:
            covered_entities.append(f"topic:{resolution.resolved_topic}")
        if topic.get("result") == "fail":
            reasons.append("answer_matches_unrelated_or_missing_topic")
        result = "fail" if reasons else "pass" if covered_entities else "unknown"
        return {
            "result": result, "uses_current_turn": result,
            "uses_required_context": "pass" if resolution.answered_question_ids and result == "pass" else "unknown",
            "required_entities": required_entities, "covered_entities": covered_entities,
            "answer_topic_candidates": [resolution.resolved_topic] if topic.get("result") == "pass" else [],
            "reason_codes": reasons or (["current_turn_evidence_present"] if result == "pass" else ["insufficient_current_turn_evidence"]),
        }

    def _assess_facts(
        self, answer: str, resolution: IntegrityResolution, state: IntegrityStateV21,
    ) -> tuple[dict[str, Any], list[str], list[str]]:
        contradictions = self._answer_contradictions(answer, state)
        claim_types: list[str] = []
        numeric_claims: list[str] = []
        if resolution.command == "recall_facts":
            claim_types.append("recalled_confirmed_fact")
        if re.search(r"\b(?:может|зависит|при\s+условии|нужно\s+проверить|предварительн)\w*", answer):
            claim_types.append("conditional_statement")
        numeric_patterns = (
            r"\b\d+[–-]\d+\s+(?:год|месяц|дн|проезд|карт)",
            r"\b\d+\s*(?:проезд|карт|руб|₽|лет|год)\w*",
        )
        for pattern in numeric_patterns:
            numeric_claims.extend(re.findall(pattern, answer, re.I))
        if numeric_claims:
            claim_types.append("numeric_product_claim")
        if re.search(r"\b(?:система\s+(?:умеет|поддерживает|обеспечивает)|мы\s+(?:обслуживаем|поставляем)|комплектаци\w+\s+включает)\b", answer):
            claim_types.append("new_product_claim")
        if not claim_types and re.search(r"\b(?:обычно|как\s+правило|лучше|зависит)\b", answer):
            claim_types.append("general_advice")
        if contradictions:
            result = "fail"
        elif any(item in {"new_product_claim", "numeric_product_claim"} for item in claim_types):
            result = "unknown"
        elif resolution.command in {"recall_facts", "remember_fact"}:
            result = "pass" if not contradictions else "fail"
        elif claim_types:
            result = "pass"
        else:
            result = "unknown"
        return ({
            "result": result, "contradictions": contradictions,
            "unsupported_recalled_facts": [], "claim_types": list(dict.fromkeys(claim_types)),
            "numeric_claims": list(dict.fromkeys(numeric_claims)),
        }, list(dict.fromkeys(claim_types)), list(dict.fromkeys(numeric_claims)))

    @staticmethod
    def _flatten_knowledge(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, dict):
            return " ".join(ContextIntentIntegrityLayerV21._flatten_knowledge(item) for item in value.values())
        if isinstance(value, (list, tuple)):
            return " ".join(ContextIntentIntegrityLayerV21._flatten_knowledge(item) for item in value)
        return str(value).lower()

    def _assess_source(
        self, answer: str, resolution: IntegrityResolution, knowledge_package: Any | None,
        claim_types: list[str], numeric_claims: list[str], link: dict[str, Any],
    ) -> dict[str, Any]:
        if resolution.command == "give_link":
            return {
                "result": link["result"], "required_artifact_type": "website_page",
                "allowed_sources": list(resolution.retrieval.allowed_sources),
                "reason": "verified_website_route" if link["result"] == "pass" else "route_not_verified",
            }
        needs_source = resolution.command in {"compare_options", "recommend"} or any(
            item in {"new_product_claim", "numeric_product_claim"} for item in claim_types
        )
        if not needs_source:
            return {
                "result": "unknown", "required_artifact_type": resolution.retrieval.required_artifact_type,
                "allowed_sources": list(resolution.retrieval.allowed_sources), "reason": "source_not_required_or_not_assessed",
            }
        knowledge = self._flatten_knowledge(knowledge_package)
        if not knowledge:
            return {
                "result": "unknown", "required_artifact_type": resolution.retrieval.required_artifact_type,
                "allowed_sources": list(resolution.retrieval.allowed_sources), "reason": "knowledge_package_not_saved",
                "numeric_claims": numeric_claims,
            }
        unsupported = [claim for claim in numeric_claims if claim.lower() not in knowledge]
        return {
            "result": "fail" if unsupported else "pass",
            "required_artifact_type": resolution.retrieval.required_artifact_type,
            "allowed_sources": list(resolution.retrieval.allowed_sources),
            "reason": "claims_not_found_in_knowledge" if unsupported else "knowledge_evidence_present",
            "unsupported_claims": unsupported,
        }

    def _assess_topic(self, answer: str, resolution: IntegrityResolution) -> dict[str, Any]:
        if resolution.retrieval.required_route and resolution.retrieval.required_route in answer:
            return {"result": "pass", "confidence": 1.0, "evidence": [resolution.retrieval.required_route], "reason": "verified_route_matches_topic"}
        if resolution.resolved_topic == "utility_calculation":
            expected = self._utility_answer(resolution.ingestion.normalized_text)
            value = re.search(r"=\s*(-?\d+(?:\.\d+)?)", expected)
            matched = bool(value and re.search(rf"(?:=\s*)?{re.escape(value.group(1))}(?:\D|$)", answer)) or bool(
                re.search(r"сегодня\s+(?:понедельник|вторник|среда|четверг|пятница|суббота|воскресенье)", answer)
            )
            return {"result": "pass" if matched else "fail", "confidence": 1.0, "evidence": [value.group(1)] if value and matched else [], "reason": "deterministic_utility_checked"}
        contracts = {
            "access_configuration_by_user_segments": r"\b(?:сотрудник|арендатор|гост|абонемент|гостев\w+\s+заявк|распознаван\w+\s+номер)\w*",
            "access_identifier_selection": r"\b(?:госномер|распознаван\w+\s+номер|карт|билет|rfid|qr|основн\w+\s+способ|резервн\w+\s+сценари)\w*",
            "solution_selection": r"\b(?:решени|конфигураци|комплектаци|въезд|выезд|оборудован)\w*",
            "maintenance_frequency": r"\b(?:то|обслужив|регламент|периодичност|нагрузк|услови\w+\s+эксплуатац|регулярн)\w*",
            "service_scope": r"\b(?:обслужив|сопровожд|поставк|монтаж|поддержк|договор)\w*",
            "card_dispenser_capacity": r"\b(?:карт|диспенсер|стойк|вместимост|загрузк)\w*",
            "ticket_roll_capacity": r"\b(?:рулон|билет|проезд|расход|чек)\w*",
            "roi": r"\b(?:окупа|инвестиц|тариф|загрузк|доход|затрат)\w*",
            "commercial_configuration": r"\b(?:сборк|комплектаци|стоимост|задач|объект|конфигураци)\w*",
            "diagnostic_explanation": r"\b(?:значит|причин|объясн|это\s+(?:означает|связано))\w*",
            "sales_feedback": r"\b(?:спасибо|учту|помочь|уточн|вопрос|продав|консульт)\w*",
            "utility_calculation": r"(?:=\s*-?\d|сегодня\s+(?:понедельник|вторник|среда|четверг|пятница|суббота|воскресенье))",
            "next_step_selection": r"\b(?:обследовани|консультаци|расч[её]т|следующ\w+\s+шаг|начать)\w*",
            "tenant_pays_guest_parking": r"\b(?:арендатор|организаци)\w*\b.*\b(?:оплат|гост)\w*|\bгост\w*\b.*\b(?:арендатор|оплат)\w*",
            "guest_self_payment": r"\bгост\w*\b.*\bоплат\w*|\bоплат\w*\b.*\bгост\w*",
            "online_payment": r"\b(?:онлайн[- ]?оплат|сбп|оплат\w*\s+через\s+(?:сайт|qr))\w*",
            "guest_access": r"\b(?:гостев|гост|заявк|временн\w+\s+доступ)\w*",
            "qr_entry_station": r"\b(?:qr|стойк|въезд|терминал)\w*",
            "card_distribution": r"\b(?:карт|диспенсер|выдач)\w*",
            "pricing": r"\b(?:стоимост|цена|тариф|расч[её]т)\w*",
            "parking_access": r"\b(?:въезд|выезд|шлагбаум|проезд|карт|билет|госномер)\w*",
            "assistant_identity": r"\b(?:ai-консультант|ии-консультант|помощник|консультант)\b",
        }
        pattern = contracts.get(resolution.resolved_topic)
        if not pattern:
            return {"result": "unknown", "confidence": 0.0, "evidence": [], "reason": "no_topic_contract"}
        matches = re.findall(pattern, answer, re.I)
        return {
            "result": "pass" if matches else "fail", "confidence": .95 if matches else .9,
            "evidence": [str(item) for item in matches[:5]],
            "reason": "topic_evidence_present" if matches else "topic_evidence_missing",
        }

    def _assess_command(self, answer: str, resolution: IntegrityResolution, state: IntegrityStateV21) -> dict[str, Any]:
        if resolution.intent == "simple_utility_question":
            expression = self._arithmetic_expression(resolution.ingestion.normalized_text)
            expected = self._utility_answer(resolution.ingestion.normalized_text)
            expected_value = re.search(r"=\s*(-?\d+(?:\.\d+)?)", expected)
            ok = bool(expected_value and re.search(rf"(?:=\s*)?{re.escape(expected_value.group(1))}(?:\D|$)", answer)) if expression else bool(re.search(r"сегодня\s+(?:понедельник|вторник|среда|четверг|пятница|суббота|воскресенье)", answer))
            return {"command": "deterministic_action", "result": "pass" if ok else "fail", "missing_requirements": [] if ok else ["utility_result_missing"], "evidence": {"expression": expression}, "reason": "utility_result_checked"}
        command = resolution.command
        requirements = resolution.command_requirements
        if command == "recommend":
            recommendation = bool(RECOMMENDATION_PATTERN.search(answer))
            basis = bool(RECOMMENDATION_BASIS_PATTERN.search(answer))
            conditionality = bool(re.search(r"\b(?:предварительн|окончательн|зависит|при\s+условии|нужно\s+уточнить)\w*", answer)) or recommendation
            missing = []
            if not recommendation:
                missing.append("recommendation_missing")
            if not basis:
                missing.append("recommendation_basis_missing")
            if not conditionality:
                missing.append("conditionality_not_handled")
            return {"command": command, "result": "fail" if missing else "pass", "missing_requirements": missing, "evidence": {"recommended_option_present": recommendation, "recommendation_basis_present": basis, "conditionality_handled": conditionality}, "reason": "recommendation_structure_checked"}
        if command == "compare_options":
            missing: list[str] = []
            required_options = requirements.get("required_options", [])
            required_dimensions = requirements.get("required_dimensions", [])
            covered_options = [name for name in required_options if re.search(OPTION_PATTERNS[name], answer)]
            covered_dimensions = [name for name in required_dimensions if re.search(DIMENSION_PATTERNS[name], answer)]
            if not required_options:
                return {"command": command, "result": "unknown", "missing_requirements": ["comparison_options_unknown"], "evidence": {}, "reason": "comparison_frame_missing"}
            if set(covered_options) != set(required_options):
                missing.append("options_not_compared")
            if required_dimensions and set(covered_dimensions) != set(required_dimensions):
                missing.append("dimensions_not_covered")
            if not re.search(r"\b(?:а|но|тогда\s+как|в\s+отличие|быстр|удоб|над[её]ж|медлен|требу|подход)\w*", answer):
                missing.append("comparison_not_present")
            return {"command": command, "result": "fail" if missing else "pass", "missing_requirements": missing, "evidence": {"required_options": required_options, "covered_options": covered_options, "required_dimensions": required_dimensions, "covered_dimensions": covered_dimensions, "requirements_source": requirements.get("requirements_source")}, "reason": "comparison_frame_checked"}
        if command == "handoff" and resolution.action_dependency.get("action") in {
            "next_step_site_survey", "next_step_consultation", "next_step_calculation",
        }:
            patterns = {
                "next_step_site_survey": r"\b(?:обследовани|осмотр)\w*",
                "next_step_consultation": r"\bконсультаци\w*",
                "next_step_calculation": r"\bрасч[её]т\w*",
            }
            action = resolution.action_dependency["action"]
            selected = bool(re.search(patterns[action], answer))
            basis = bool(RECOMMENDATION_BASIS_PATTERN.search(answer) or re.search(r"\b(?:позволит|чтобы|сначала)\b", answer))
            missing = ([] if selected else ["next_step_not_selected"]) + ([] if basis else ["next_step_basis_missing"])
            return {"command": command, "result": "fail" if missing else "pass", "missing_requirements": missing, "evidence": {"action": action, "selected": selected, "basis": basis}, "reason": "next_step_checked"}
        return super()._assess_command(answer, resolution, state)

    @staticmethod
    def _answer_contradictions(answer: str, state: IntegrityStateV21) -> list[str]:
        contradictions: list[str] = []
        object_fact = (state.confirmed_facts.get("object_type") or {}).get("value")
        if object_fact:
            found = [value for value, pattern in OBJECT_TYPES if pattern.search(answer)]
            if found and object_fact not in found:
                contradictions.append("object_type")
        patterns = {
            "entrances_count": r"\b(\d+)\s+въезд\w*",
            "exits_count": r"\b(\d+)\s+выезд\w*",
            "daily_traffic": r"\b(\d{2,6})\s+(?:автомобил|машин)\w*",
            "permanent_users_share": r"\b(\d{1,3}(?:[.,]\d+)?)\s*(?:%|процент)",
            "entry_price_rub": r"\b(\d[\d\s]{0,8})\s*(?:руб\w*|₽)\b",
        }
        for field_name, pattern in patterns.items():
            record = state.confirmed_facts.get(field_name)
            if not record:
                continue
            values = re.findall(pattern, answer, re.I)
            if not values:
                continue
            expected = float(record.get("value")) * 100 if field_name == "permanent_users_share" else float(record.get("value"))
            parsed = [float(str(value).replace(" ", "").replace(",", ".")) for value in values]
            if all(abs(value - expected) > 1e-6 for value in parsed):
                contradictions.append(field_name)
        for field_name in ("current_system", "timeline", "location", "budget_status"):
            record = state.confirmed_facts.get(field_name)
            if not record:
                continue
            label_present = re.search(rf"\b{re.escape(field_name.replace('_', ' '))}\b", answer)
            if label_present and str(record.get("value", "")).lower() not in answer:
                contradictions.append(field_name)
        return list(dict.fromkeys(contradictions))

    def _fallback(
        self, resolution: IntegrityResolution, state: IntegrityStateV21, violations: list[str],
    ) -> tuple[str | None, str | None]:
        if resolution.command == "ask_one_question" and "command_assessment_failed" in violations:
            question = resolution.command_requirements.get("deterministic_question")
            if question:
                return "deterministic_one_question", str(question)
        if resolution.command == "compare_options" and "command_assessment_failed" in violations:
            return "comparison_requires_verified_knowledge", "Для корректного сравнения нужны подтверждённые данные по всем запрошенным вариантам и критериям."
        return super()._fallback(resolution, state, violations)


ContextIntentIntegrityLayer = ContextIntentIntegrityLayerV21
