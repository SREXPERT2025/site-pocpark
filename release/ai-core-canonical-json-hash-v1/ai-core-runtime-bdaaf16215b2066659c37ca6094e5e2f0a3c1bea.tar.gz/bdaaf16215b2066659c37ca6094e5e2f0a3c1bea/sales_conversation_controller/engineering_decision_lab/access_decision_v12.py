from __future__ import annotations

from typing import Any

from .models import (
    AssistedRecovery, AccessAuthorization, AutomatedFallbackCredential,
    DecisionPackageV12, EmergencyOverride, InfrastructureRequirement,
    LaneIdentifier, ObjectiveProfile, PrimitiveOptionAssessment,
    ProjectFacts, SegmentAccessPlanV12, PRIMITIVE_IDENTIFIER_OPTIONS,
)


READER_FIELDS = {
    "parking_card": ("card_reader", "card_reader_present"),
    "parking_ticket": ("ticket_reader", "ticket_reader_present"),
    "guest_qr": ("qr_reader", "qr_reader_present"),
    "radio_tag": ("rfid_reader", "rfid_reader_present"),
}


class AccessDecisionOntologyEngineV12:
    VERSION = "1.2"

    def __init__(self, *, objectives: Any, questions: Any, evidence: Any) -> None:
        self.objectives = objectives
        self.questions = questions
        self.evidence = evidence

    def decide(
        self, facts: ProjectFacts | dict, *, objective_profile: ObjectiveProfile | dict | None = None,
        constraints=(), asked_questions=(),
    ) -> DecisionPackageV12:
        facts = ProjectFacts.from_dict(facts) if isinstance(facts, dict) else facts
        if isinstance(objective_profile, dict):
            objective = ObjectiveProfile(**objective_profile)
        else:
            objective = objective_profile or self.objectives.resolve(facts)
        assessments = tuple(self._assess(option, facts, objective) for option in PRIMITIVE_IDENTIFIER_OPTIONS)
        segments, candidates, reasons = self._segments(facts)
        components = sorted({
            item
            for plan in segments.values()
            for item in (
                ([plan["primary_identifier"]["type"]] if plan.get("primary_identifier") else [])
                + [value["type"] for value in plan.get("automated_fallback_credentials") or []]
            )
        })
        architecture_type = self._architecture_type(
            facts=facts,
            components=components,
            segments=segments,
            candidates=candidates,
        )
        ranking = self.questions.rank_questions_v12(facts, asked_questions)
        next_question = next((item["question"] for item in ranking if item["applicable"] and not item["already_asked"]), None)
        missing = self.questions.missing_critical_facts_v12(facts)
        confidence, confidence_trace = self._confidence(facts, assessments)
        evidence_refs = self.evidence.validate_refs((
            "lpr_speed_conditional", "automated_fallback_vs_assisted_recovery",
        ))
        package = DecisionPackageV12(
            decision_type="access_identifier_selection",
            recommended_architecture={
                "architecture_type": architecture_type,
                "components": components,
                "segments": segments,
                "emergency_override": EmergencyOverride().to_dict(),
            },
            primitive_option_assessments=assessments,
            candidate_credentials_requiring_confirmation=tuple(candidates),
            why=(
                "Предварительная архитектура разделяет право доступа, идентификацию на полосе и обработку исключений.",
                "Распознавание номеров соответствует приоритету скорости, но окончательный резерв зависит от подтверждённой инфраструктуры.",
            ),
            tradeoffs=(
                "Карты создают нагрузку по выдаче, возврату, переносу и контролю состояния.",
                "Билеты создают нагрузку по расходу ленты и обслуживанию механизма выдачи.",
                "Значимость этих факторов зависит от потока, бесплатного периода и организации эксплуатации.",
            ),
            assumptions=(
                "Наличие считывателей карт, RFID, QR и билетов не считается подтверждённым без отдельного факта.",
                "Числовые оценки используются только для внутреннего ранжирования и не показываются клиенту.",
            ),
            missing_critical_facts=missing, confidence=confidence, confidence_trace=confidence_trace,
            next_question=next_question,
            next_step=None if missing else "Передать сегментную архитектуру инженеру для проверки оборудования.",
            evidence_refs=evidence_refs, question_ranking=tuple(ranking),
            sensitivity_analysis=self._sensitivity(facts), reason_codes=tuple(dict.fromkeys(reasons)),
        )
        self._validate_invariants(package)
        return package

    @staticmethod
    def _validate_invariants(package: DecisionPackageV12) -> None:
        options = {item.option for item in package.primitive_option_assessments}
        if "operator_assisted_access" in options:
            raise ValueError("operator_in_primitive_identifier_options")
        if "hybrid_access" in options:
            raise ValueError("hybrid_in_primitive_identifier_options")
        architecture = package.recommended_architecture
        confirmed_components = set(architecture.get("components") or ())
        architecture_type = architecture.get("architecture_type")
        if architecture_type == "hybrid_access" and len(confirmed_components) < 2:
            raise ValueError("hybrid_access_requires_two_confirmed_components")
        if architecture_type == "primary_with_pending_fallback" and len(confirmed_components) != 1:
            raise ValueError("pending_fallback_requires_one_confirmed_primary")
        for segment, plan in package.recommended_architecture["segments"].items():
            primary = (plan.get("primary_identifier") or {}).get("type")
            authorization = (plan.get("authorization") or {}).get("type")
            if primary == "guest_application":
                raise ValueError(f"authorization_misclassified_as_identifier:{segment}")
            if authorization in PRIMITIVE_IDENTIFIER_OPTIONS:
                raise ValueError(f"identifier_misclassified_as_authorization:{segment}")
            if any(item.get("type") == "operator_assisted_access" for item in plan.get("automated_fallback_credentials") or []):
                raise ValueError(f"operator_in_automated_fallback:{segment}")

    @staticmethod
    def _architecture_type(
        *, facts: ProjectFacts, components: list[str], segments: dict[str, dict],
        candidates: list[dict],
    ) -> str:
        """Classify only assigned lane identifiers; candidates and manual paths do not count."""
        confirmed_component_count = len(set(components))
        automatic_fallback_count = sum(
            len(plan.get("automated_fallback_credentials") or ())
            for plan in segments.values()
        )
        if confirmed_component_count >= 2 and automatic_fallback_count > 0:
            return "hybrid_access"
        if confirmed_component_count == 1:
            if facts.mandatory_fallback is True and automatic_fallback_count == 0:
                return "primary_with_pending_fallback"
            return "single_primary"
        if candidates:
            return "hybrid_candidate"
        return "single_primary"

    @staticmethod
    def _normalized_segments(facts: ProjectFacts) -> tuple[str, ...]:
        aliases = {
            "employee": "employees", "employees": "employees",
            "tenant": "tenants", "tenants": "tenants",
            "guest": "guests", "guests": "guests",
            "visitor": "walk_in_visitors", "visitors": "walk_in_visitors",
            "occasional": "walk_in_visitors", "walk_in": "walk_in_visitors",
            "service": "service_vehicles", "service_vehicle": "service_vehicles",
        }
        return tuple(dict.fromkeys(aliases.get(item, "unknown_segment") for item in facts.user_segments)) or ("unknown_segment",)

    def _segments(self, facts: ProjectFacts) -> tuple[dict[str, dict], list[dict], list[str]]:
        plans: dict[str, dict] = {}
        candidates: list[dict] = []
        reasons: list[str] = []
        assisted = AssistedRecovery("operator_verification") if facts.operator_present is True else None
        if facts.operator_present is False:
            reasons.append("assisted_recovery_missing")

        def add_candidate(segment: str, identifier: str, reader: str, prerequisite: str | None = None) -> None:
            value = {
                "segment": segment, "credential": {"type": identifier},
                "reason": "requires_infrastructure_confirmation", "required_reader": reader,
            }
            if prerequisite:
                value["prerequisite"] = prerequisite
            candidates.append(value)
            reasons.append("fallback_infrastructure_unknown")

        for segment in self._normalized_segments(facts):
            if segment == "employees":
                authorization = AccessAuthorization("employee_registry")
                primary = LaneIdentifier("license_plate_recognition", "conditional")
                fallback_types = ("parking_card", "radio_tag")
                failure_policy = "apply_site_security_policy"
            elif segment == "tenants":
                authorization = AccessAuthorization("tenant_registry")
                primary = LaneIdentifier("license_plate_recognition", "conditional")
                fallback_types = ("parking_card", "radio_tag")
                failure_policy = "apply_site_security_policy"
            elif segment == "guests":
                authorization = AccessAuthorization("guest_application", "confirmed_or_required")
                primary = LaneIdentifier("license_plate_recognition", "conditional")
                fallback_types = ("guest_qr", "parking_card")
                failure_policy = "apply_guest_access_policy"
            elif segment == "walk_in_visitors":
                authorization = AccessAuthorization(
                    "paid_session" if facts.payment_scenario else "other_confirmed_authorization",
                    "conditional" if facts.payment_scenario else "required",
                )
                primary = LaneIdentifier("parking_ticket", "confirmed") if facts.ticket_reader_present is True else None
                fallback_types = ("parking_card",)
                failure_policy = "apply_site_security_policy"
            elif segment == "service_vehicles":
                authorization = AccessAuthorization("white_list", "confirmed_or_required")
                primary = LaneIdentifier("license_plate_recognition", "conditional")
                fallback_types = ("parking_card", "radio_tag")
                failure_policy = "apply_site_security_policy"
            else:
                authorization = AccessAuthorization("other_confirmed_authorization", "required")
                primary = None
                fallback_types = ()
                failure_policy = "collect_segment_requirements_before_recommendation"
                reasons.append("lane_credential_missing")

            fallbacks: list[AutomatedFallbackCredential] = []
            requirements: list[InfrastructureRequirement] = []
            for identifier in fallback_types:
                reader, field = READER_FIELDS[identifier]
                confirmed = getattr(facts, field)
                requirements.append(InfrastructureRequirement(identifier, reader, confirmed))
                extra = None
                allowed = confirmed is True
                if identifier == "guest_qr":
                    flow = all(getattr(facts, name) is True for name in (
                        "guest_application_flow_confirmed", "guest_qr_delivery_confirmed",
                        "guest_qr_binding_confirmed", "guest_qr_reuse_policy_confirmed",
                        "guest_qr_expiry_confirmed",
                    ))
                    allowed = allowed and flow
                    if not flow:
                        reasons.append("guest_qr_flow_not_defined")
                        extra = "confirmed_guest_qr_workflow"
                if allowed:
                    fallbacks.append(AutomatedFallbackCredential(identifier, reader))
                else:
                    add_candidate(segment, identifier, reader, extra)
            if segment == "walk_in_visitors" and primary is None:
                requirements.append(InfrastructureRequirement("parking_ticket", "ticket_reader", facts.ticket_reader_present))
                add_candidate(segment, "parking_ticket", "ticket_reader")
                reasons.append("lane_credential_missing")
            if facts.mandatory_fallback and not fallbacks:
                reasons.append("automatic_fallback_missing")
            plan = SegmentAccessPlanV12(
                authorization=authorization, primary_identifier=primary,
                automated_fallback_credentials=tuple(fallbacks), assisted_recovery=assisted,
                failure_policy=("deny_access_when_identifier_not_verified" if facts.unknown_plate_policy == "deny" else failure_policy),
                infrastructure_requirements=tuple(requirements),
                evidence_refs=(
                    "knowledge_base/engineering/parking_solution_decision_framework.md#варианты-идентификации",
                    "knowledge_base/engineering/automated_fallback_vs_assisted_recovery.md",
                ),
            )
            plans[segment] = plan.to_dict()
        return plans, candidates, reasons

    def _assess(self, option: str, facts: ProjectFacts, objective: ObjectiveProfile) -> PrimitiveOptionAssessment:
        raw = {
            "license_plate_recognition": {"speed": 1.0, "reliability": .65, "staff_load": .7, "consumables": 1.0, "security": .7},
            "parking_card": {"speed": .55, "reliability": .8, "staff_load": .35, "consumables": .7, "security": .8},
            "parking_ticket": {"speed": .4, "reliability": .75, "staff_load": .55, "consumables": .25, "security": .65},
            "guest_qr": {"speed": .65, "reliability": .55, "staff_load": .9, "consumables": 1.0, "security": .6},
            "radio_tag": {"speed": .9, "reliability": .8, "staff_load": .75, "consumables": .9, "security": .75},
        }[option]
        weights = {
            "speed": objective.speed, "reliability": objective.reliability,
            "staff_load": objective.staff_load, "consumables": objective.consumables,
            "security": objective.security,
        }
        penalty = 0.0
        missing: list[str] = []
        reader_info = READER_FIELDS.get(option)
        if reader_info:
            status = getattr(facts, reader_info[1])
            if status is False:
                penalty = 1.0
            elif status is None:
                penalty = .05
                missing.append(reader_info[1])
        if option == "guest_qr" and not all(getattr(facts, name) is True for name in (
            "guest_application_flow_confirmed", "guest_qr_delivery_confirmed",
            "guest_qr_binding_confirmed", "guest_qr_reuse_policy_confirmed", "guest_qr_expiry_confirmed",
        )):
            missing.append("guest_qr_workflow")
        trace = tuple({
            "criterion": name, "raw_value": raw[name], "weight": round(weight, 4),
            "evidence": self._criterion_evidence(option, name),
            "missing_data": ["quantitative_calibration_dataset"],
            "penalty": penalty if name == "reliability" else 0.0,
            "contribution": round(raw[name] * weight, 6), "normalization": "weighted_sum_divided_by_total_weight",
            "calibration_status": "qualitative_heuristic",
        } for name, weight in weights.items())
        total_weight = sum(weights.values()) or 1.0
        normalized = max(0.0, min(1.0, (sum(item["contribution"] for item in trace) / total_weight) - penalty))
        if penalty >= 1:
            ordinal = "not_applicable"
        elif missing and normalized < .5:
            ordinal = "weak_candidate"
        elif missing:
            ordinal = "conditional_candidate"
        elif normalized >= .72:
            ordinal = "strong_candidate"
        elif normalized >= .5:
            ordinal = "conditional_candidate"
        else:
            ordinal = "weak_candidate"
        evidence_keys = {
            "license_plate_recognition": ("lpr_speed_conditional",),
            "parking_card": ("parking_card_operational_properties", "card_dispenser_typical_capacity"),
            "parking_ticket": ("ticket_roll_typical_capacity",),
            "guest_qr": ("automated_fallback_vs_assisted_recovery",),
            "radio_tag": ("automated_fallback_vs_assisted_recovery",),
        }[option]
        refs = self.evidence.validate_refs(evidence_keys)
        review_status = "supported_rule" if refs and not missing else "candidate_rule_missing_evidence"
        return PrimitiveOptionAssessment(
            option, ordinal, round(normalized, 4), True, trace, tuple(dict.fromkeys(missing)),
            review_status, refs,
        )

    @staticmethod
    def _criterion_evidence(option: str, criterion: str) -> list[str]:
        paths = {
            "license_plate_recognition": "knowledge_base/engineering/parking_solution_decision_framework.md#варианты-идентификации",
            "parking_card": "knowledge_base/engineering/rospark_engineering_experience.md#parking_card_operational_properties",
            "parking_ticket": "knowledge_base/engineering/rospark_engineering_experience.md#ticket_roll_typical_capacity",
            "guest_qr": "knowledge_base/engineering/automated_fallback_vs_assisted_recovery.md",
            "radio_tag": "knowledge_base/engineering/automated_fallback_vs_assisted_recovery.md",
        }
        return [paths[option], f"qualitative_criterion:{criterion}"]

    def _confidence(self, facts: ProjectFacts, assessments: tuple[PrimitiveOptionAssessment, ...]) -> tuple[float, dict[str, Any]]:
        core = (
            "object_type", "entrances_count", "exits_count", "daily_traffic", "user_segments",
            "existing_system", "modernization_or_new_build", "operator_present",
            "speed_priority", "security_priority", "mandatory_fallback", "payment_scenario",
        )
        completeness = sum(getattr(facts, field) not in (None, (), []) for field in core) / len(core)
        infrastructure = sum(getattr(facts, field) is not None for field in (
            "qr_reader_present", "card_reader_present", "rfid_reader_present", "ticket_reader_present",
        )) / 4
        evidence_coverage = sum(bool(item.evidence_refs) for item in assessments) / len(assessments)
        conflict_absence = 0.0 if facts.conflicts else 1.0
        components = {
            "evidence_coverage": round(evidence_coverage, 4),
            "confirmed_infrastructure": round(infrastructure, 4),
            "fact_completeness": round(completeness, 4),
            "absence_of_unresolved_conflicts": conflict_absence,
        }
        weights = {"evidence_coverage": .3, "confirmed_infrastructure": .3, "fact_completeness": .3, "absence_of_unresolved_conflicts": .1}
        value = sum(components[name] * weight for name, weight in weights.items())
        return round(value, 2), {"components": components, "weights": weights, "formula": "weighted_sum_independent_from_option_score"}

    def _sensitivity(self, facts: ProjectFacts) -> tuple[dict[str, Any], ...]:
        profiles = {
            "speed_priority": ObjectiveProfile(speed=3, reliability=1, staff_load=1, consumables=1, security=1),
            "staff_load_priority": ObjectiveProfile(speed=.5, reliability=.5, staff_load=6, consumables=.5, security=.5),
            "consumables_priority": ObjectiveProfile(speed=1, reliability=1, staff_load=1, consumables=3, security=1),
        }
        values = []
        for name, profile in profiles.items():
            assessments = [self._assess(option, facts, profile) for option in PRIMITIVE_IDENTIFIER_OPTIONS]
            ranking = [item.option for item in sorted(assessments, key=lambda item: item.normalized_score or -1, reverse=True)]
            values.append({"scenario": name, "ranking": ranking, "scores_internal_only": {item.option: item.normalized_score for item in assessments}})
        return tuple(values)
