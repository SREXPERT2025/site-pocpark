from __future__ import annotations

from .evidence_gate import EvidenceGate
from .explanation_contract import ExplanationContract
from .models import (
    AssistedRecovery,
    DecisionCard,
    DecisionPackage,
    EmergencyOverride,
    InfrastructureRequirement,
    ObjectiveProfile,
    ProjectFacts,
    SegmentAccessPlan,
)
from .objective_resolver import ObjectiveResolver
from .operational_load import OperationalLoadEstimator
from .question_planner import QuestionPlanner
from .risk_resilience import RiskResilienceAssessor
from .tco import TotalCostOfOwnershipModel


OPTIONS = (
    "license_plate_recognition", "parking_card", "parking_ticket",
    "guest_qr", "radio_tag", "operator_assisted_access", "hybrid_access",
)


class EngineeringDecisionEngine:
    VERSION = "1.2"

    def __init__(self, *, schema_version: str = "1.2") -> None:
        if schema_version not in {"1.1", "1.2"}:
            raise ValueError("engineering_decision_schema_version_invalid")
        self.schema_version = schema_version
        self.objectives = ObjectiveResolver()
        self.questions = QuestionPlanner()
        self.operations = OperationalLoadEstimator()
        self.tco = TotalCostOfOwnershipModel()
        self.risks = RiskResilienceAssessor()
        self.evidence = EvidenceGate()
        self.contract = ExplanationContract()

    def decide(
        self, facts: ProjectFacts | dict, *, objective_profile: ObjectiveProfile | dict | None = None,
        constraints: tuple[str, ...] | list[str] = (), asked_questions: tuple[str, ...] | list[str] = (),
    ) -> DecisionPackage:
        if self.schema_version == "1.2":
            from .access_decision_v12 import AccessDecisionOntologyEngineV12
            return AccessDecisionOntologyEngineV12(
                objectives=self.objectives, questions=self.questions, evidence=self.evidence,
            ).decide(
                facts, objective_profile=objective_profile, constraints=constraints,
                asked_questions=asked_questions,
            )
        facts = ProjectFacts.from_dict(facts) if isinstance(facts, dict) else facts
        if isinstance(objective_profile, dict):
            objective = ObjectiveProfile(**objective_profile)
        else:
            objective = objective_profile or self.objectives.resolve(facts)
        cards = tuple(self._score(option, facts, objective) for option in OPTIONS)
        eligible = [card for card in cards if not card.hard_constraints]
        ranked = sorted(eligible or list(cards), key=lambda card: (-card.score, OPTIONS.index(card.option)))
        segments, candidate_options, semantic_reasons = self._segment_access_plans(facts)
        missing = self.questions.missing_critical_facts(facts)
        question = self.questions.next_question(facts, asked_questions)
        top = ranked[0]
        why = [
            "Для сотрудников и арендаторов распознавание номеров поддерживает основной быстрый бесконтактный поток.",
            "Для гостей основной сценарий нужно связывать с заранее зарегистрированным номером или подтверждённой гостевой заявкой.",
            "Автоматический резерв определяется отдельно для каждой категории и только после подтверждения считывателя.",
        ]
        tradeoffs = [
            "Для карт эксплуатационная нагрузка зависит от выдачи, возврата, переноса и контроля состояния носителей.",
            "Для билетов эксплуатационная нагрузка зависит от потока, расхода ленты и обслуживания механизма выдачи.",
            "Ручная проверка оператором применяется только для исключений и не заменяет автоматический резервный идентификатор.",
        ]
        confidence = max(.25, min(.95, .95 - .07 * len(missing)))
        if not any(plan.get("primary_identifier") for plan in segments.values()):
            confidence = min(confidence, .35)
        refs = tuple(dict.fromkeys((*top.evidence_refs, "automated_fallback_vs_assisted_recovery")))
        assumptions = tuple(
            value for value in (
                "Не подтверждена доля пользователей каждого способа доступа." if facts.ticket_user_share is None else None,
                "Не подтверждены цены оборудования, труда и простоя; денежный TCO не рассчитывается.",
            ) if value
        )
        package = DecisionPackage(
            decision_type="access_identifier_selection",
            recommended_architecture={
                "segments": segments,
                "emergency_override": EmergencyOverride().to_dict(),
            },
            why=tuple(why), tradeoffs=tuple(tradeoffs), assumptions=assumptions,
            missing_critical_facts=missing, confidence=round(confidence, 2),
            next_question=question,
            next_step=None if missing else "Передать предварительную архитектуру инженеру для проверки оборудования и интерфейсов.",
            evidence_refs=self.evidence.validate_refs(refs), objective_profile=objective, option_cards=cards,
            candidate_options=tuple(candidate_options), reason_codes=tuple(dict.fromkeys(semantic_reasons)),
            schema_version="1.1",
        )
        self.contract.validate(package)
        return package

    @staticmethod
    def _normalized_segments(facts: ProjectFacts) -> tuple[str, ...]:
        aliases = {
            "employee": "employees", "employees": "employees",
            "tenant": "tenants", "tenants": "tenants",
            "guest": "guests", "guests": "guests",
            "occasional": "walk_in_visitors", "visitor": "walk_in_visitors",
            "visitors": "walk_in_visitors", "walk_in": "walk_in_visitors",
            "service": "service_vehicles", "service_vehicle": "service_vehicles",
        }
        result = tuple(dict.fromkeys(aliases.get(item, "unknown_segment") for item in facts.user_segments))
        return result or ("unknown_segment",)

    def _segment_access_plans(
        self, facts: ProjectFacts,
    ) -> tuple[dict[str, dict], list[dict], list[str]]:
        plans: dict[str, dict] = {}
        candidates: list[dict] = []
        reasons: list[str] = []
        assisted = AssistedRecovery("operator_verification") if facts.operator_present is True else None
        if facts.operator_present is False:
            reasons.append("assisted_recovery_missing")

        def candidate(segment: str, identifier: str, reader: str, extra: str | None = None) -> None:
            item = {
                "segment": segment,
                "identifier": identifier,
                "reason": "requires_infrastructure_confirmation",
                "required_reader": reader,
            }
            if extra:
                item["additional_requirement"] = extra
            candidates.append(item)
            reasons.extend(("fallback_requires_unconfirmed_reader", "fallback_infrastructure_unknown"))

        def confirmed_fallbacks(segment: str) -> tuple[list[str], list[InfrastructureRequirement]]:
            values: list[str] = []
            requirements: list[InfrastructureRequirement] = []
            if segment in {"employees", "tenants"}:
                for identifier, reader, confirmed in (
                    ("parking_card", "card_reader", facts.card_reader_present),
                    ("radio_tag", "rfid_reader", facts.rfid_reader_present),
                ):
                    requirements.append(InfrastructureRequirement(identifier, reader, confirmed))
                    if confirmed is True:
                        values.append(identifier)
                    else:
                        candidate(segment, identifier, reader)
            elif segment == "guests":
                qr_flow = all(value is True for value in (
                    facts.guest_application_flow_confirmed,
                    facts.guest_qr_delivery_confirmed,
                    facts.guest_qr_binding_confirmed,
                    facts.guest_qr_reuse_policy_confirmed,
                    facts.guest_qr_expiry_confirmed,
                ))
                requirements.append(InfrastructureRequirement("guest_qr", "qr_reader", facts.qr_reader_present))
                if facts.qr_reader_present is True and qr_flow:
                    values.append("guest_qr")
                else:
                    candidate(segment, "guest_qr", "qr_reader", "confirmed_guest_qr_flow")
                    if not qr_flow:
                        reasons.append("guest_qr_flow_not_defined")
                requirements.append(InfrastructureRequirement("guest_card", "card_reader", facts.card_reader_present))
                if facts.card_reader_present is True:
                    values.append("guest_card")
                else:
                    candidate(segment, "guest_card", "card_reader")
            elif segment == "walk_in_visitors":
                requirements.append(InfrastructureRequirement("parking_ticket", "ticket_reader", facts.ticket_reader_present))
                if facts.ticket_reader_present is True:
                    values.append("parking_ticket")
                else:
                    candidate(segment, "parking_ticket", "ticket_reader")
            return values, requirements

        for segment in self._normalized_segments(facts):
            fallbacks, requirements = confirmed_fallbacks(segment)
            if segment in {"employees", "tenants", "service_vehicles"}:
                primary = "license_plate_recognition"
                policy = "apply_site_security_policy"
            elif segment == "guests":
                primary = "pre_registered_plate_or_guest_application"
                policy = "apply_guest_access_policy"
            elif segment == "walk_in_visitors":
                primary = "parking_ticket" if facts.ticket_reader_present is True else None
                policy = "deny_or_manual_review_according_to_site_security_policy"
            else:
                primary = None
                policy = "collect_segment_requirements_before_recommendation"
            if facts.security_priority == "high" or facts.unknown_plate_policy == "deny":
                policy = "deny_access_when_identifier_not_verified"
            if facts.mandatory_fallback and not fallbacks:
                reasons.append("automatic_fallback_missing")
            plan = SegmentAccessPlan(
                primary_identifier=primary,
                automated_fallback_identifiers=tuple(fallbacks),
                assisted_recovery=assisted,
                failure_policy=policy,
                infrastructure_requirements=tuple(requirements),
                evidence_refs=(
                    "knowledge_base/engineering/parking_solution_decision_framework.md#варианты-идентификации",
                    "knowledge_base/engineering/automated_fallback_vs_assisted_recovery.md",
                ),
            )
            plans[segment] = plan.to_dict()
        if len(plans) > 1:
            reasons.append("fallback_not_segment_specific_resolved")
        return plans, candidates, reasons

    def _score(self, option: str, facts: ProjectFacts, objective) -> DecisionCard:
        score = 0.0
        strengths: list[str] = []
        limitations: list[str] = []
        refs: list[str] = []
        hard_constraints: list[str] = []
        suitable_when: list[str] = []
        less_suitable_when: list[str] = []
        segments = set(facts.user_segments)
        if option == "license_plate_recognition":
            score += 2.2 * objective.speed + 1.2 * objective.staff_load + .5 * objective.security
            strengths.append("Распознавание номеров поддерживает быстрый бесконтактный проезд при подходящих условиях установки.")
            limitations.append("Нужен резерв на случай нераспознанного номера.")
            refs.append("lpr_speed_conditional")
            suitable_when.append("Нужен бесконтактный основной поток и условия установки камер подтверждены.")
            if facts.weather_exposure in {"high", "open_air"}:
                score -= 1.0
                less_suitable_when.append("Открытая среда повышает требования к обзору и обслуживанию камеры.")
            if facts.interfaces_compatible is False:
                hard_constraints.append("interfaces_incompatible")
        elif option == "parking_card":
            score += 1.0 * objective.reliability + 1.2 * objective.consumables + 1.2 * objective.advertising
            strengths.append("Карта многоразовая и может применяться для разных категорий посетителей.")
            limitations.append("Возврат, перенос и сортировка создают нагрузку на персонал.")
            refs.extend(("parking_card_operational_properties", "card_dispenser_typical_capacity"))
            if facts.operator_present is False:
                score -= 2.5 * objective.staff_load
                less_suitable_when.append("Нет персонала для возврата, переноса и сортировки карт.")
                if facts.card_return_process is not True:
                    hard_constraints.append("no_staff_for_card_circulation")
            if facts.advertising_priority == "high":
                refs.append("parking_card_advertising")
        elif option == "parking_ticket":
            score += .8 * objective.reliability - 1.8 * objective.consumables
            strengths.append("Рулон допускает редкую загрузку стойки при подходящем потоке.")
            limitations.append("Билеты создают постоянные расходы на расходные материалы.")
            refs.append("ticket_roll_typical_capacity")
            if facts.consumables_forbidden:
                hard_constraints.append("consumables_forbidden")
                score -= 1000
            if facts.space_for_entry_station is False:
                hard_constraints.append("no_space_for_entry_station")
            if facts.operator_present is False and (facts.daily_traffic or 0) < 500:
                score += 1.0
            if facts.free_parking_minutes is not None and facts.free_parking_minutes >= 120:
                score -= .6 * objective.consumables
                less_suitable_when.append("Длительный бесплатный период может увеличить расход билетов без оплаты.")
        elif option == "guest_qr":
            score += (2.5 if "guest" in segments else .4) + 1.1 * objective.consumables
            strengths.append("QR-код может дополнять гостевой сценарий без постоянного физического носителя.")
            limitations.append("Нужно определить способ выдачи, доставки и проверки кода.")
        elif option == "radio_tag":
            score += (1.8 if segments & {"employee", "tenant", "resident"} else .3) + .8 * objective.speed
            strengths.append("Радиометка подходит для заранее известной группы пользователей.")
            limitations.append("Выданные метки требуют учёта.")
        elif option == "operator_assisted_access":
            score += .5 * objective.reliability
            strengths.append("Оператор может обработать исключение при наличии полномочий и регламента.")
            limitations.append("Сценарий зависит от доступности и действий персонала.")
            if facts.operator_present is not True:
                hard_constraints.append("operator_not_available")
        elif option == "hybrid_access":
            score += 2.0 * objective.reliability + .8 * objective.security
            strengths.append("Смешанная схема разделяет основной и резервный способы проезда.")
            limitations.append("Больше компонентов увеличивает сложность эксплуатации.")
            if facts.mandatory_fallback:
                score += 4.0
            if len(segments) >= 2:
                score += 2.5
            if facts.security_priority == "high":
                score += 1.5
        load = self.operations.assess(option, facts)
        tco = self.tco.factors(option, facts)
        risks = self.risks.assess(option, facts)
        return DecisionCard(
            option=option, score=round(score, 3), strengths=tuple(strengths), limitations=tuple(limitations),
            evidence_refs=tuple(dict.fromkeys(refs)), operational_load=load, tco_factors=tco, risks=risks,
            suitable_when=tuple(suitable_when), less_suitable_when=tuple(less_suitable_when),
            hard_constraints=tuple(hard_constraints),
            criterion_scores={
                "entry_speed": round(objective.speed if option in {"license_plate_recognition", "radio_tag"} else .5, 2),
                "exit_speed": round(.7 if option in {"parking_ticket", "guest_qr"} else .6, 2),
                "reliability": round(objective.reliability, 2),
            },
            evidence_required=tuple(() if refs else ("option_specific_evidence",)),
            resilience=self.risks.resilience(option, facts),
        )

    @staticmethod
    def _fallback(primary: str | None, ranked: list[DecisionCard], facts: ProjectFacts) -> str | None:
        """Архивный helper оставлен без оператора и не используется V1.1."""
        if primary is None:
            return None
        if facts.unknown_plate_policy == "deny" and primary == "license_plate_recognition":
            return None
        confirmed = []
        if facts.card_reader_present is True:
            confirmed.append("parking_card")
        if facts.rfid_reader_present is True:
            confirmed.append("radio_tag")
        if facts.qr_reader_present is True:
            confirmed.append("guest_qr")
        if facts.ticket_reader_present is True:
            confirmed.append("parking_ticket")
        return next((item for item in confirmed if item != primary), None)
