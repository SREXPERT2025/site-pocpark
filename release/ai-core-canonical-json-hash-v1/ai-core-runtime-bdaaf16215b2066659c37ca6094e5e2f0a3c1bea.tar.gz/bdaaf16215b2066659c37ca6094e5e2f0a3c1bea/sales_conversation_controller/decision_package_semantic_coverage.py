from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class SemanticCoverageResult:
    primary: str
    segments: str
    authorization: str
    assisted_recovery: str
    fallback_semantics: str
    tradeoffs: str
    unknown_conditionality: str
    next_question: str
    status: str
    reason_codes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["reason_codes"] = list(self.reason_codes)
        return value


def _normalize(value: str) -> str:
    return " ".join(str(value or "").casefold().replace("ё", "е").split())


def _exact_question_present(answer: str, question: str) -> bool:
    questions = [item.strip() for item in re.findall(r"[^.!?]*\?", answer) if item.strip()]
    normalize_question = lambda value: re.sub(r"\s+", " ", _normalize(value).strip(" .?!"))
    return len(questions) == 1 and normalize_question(questions[0]) == normalize_question(question)


def evaluate_semantic_coverage(
    answer: str,
    decision_package: dict[str, Any] | None,
    *,
    user_message: str = "",
) -> SemanticCoverageResult:
    """Проверяет полноту озвучивания решения, не принимая новое решение."""
    package = decision_package or {}
    if package.get("schema_version") != "1.2" or package.get("decision_type") != "access_identifier_selection":
        return SemanticCoverageResult(
            primary="not_applicable", segments="not_applicable", authorization="not_applicable",
            assisted_recovery="not_applicable", fallback_semantics="not_applicable",
            tradeoffs="not_applicable", unknown_conditionality="not_applicable",
            next_question="not_applicable", status="pass", reason_codes=(),
        )

    clean = _normalize(answer)
    message = _normalize(user_message)
    architecture = package.get("recommended_architecture") or {}
    plans = architecture.get("segments") or {}
    relevant_segments = tuple(plans)

    lpr_segments = [
        name for name, plan in plans.items()
        if (plan.get("primary_identifier") or {}).get("type") == "license_plate_recognition"
    ]
    primary_ok = not lpr_segments or bool(re.search(r"\b(?:распознаван\w*\s+номер|госномер|номер\w*)\b", clean))
    segment_terms = {
        "employees": r"сотрудник", "tenants": r"арендатор", "guests": r"гост",
        "walk_in_visitors": r"разов\w*\s+(?:клиент|посетител)", "service_vehicles": r"служебн\w*",
    }
    segments_ok = all(re.search(segment_terms.get(name, re.escape(name)), clean) for name in relevant_segments)

    guest_authorization_required = (
        (plans.get("guests", {}).get("authorization") or {}).get("type") == "guest_application"
    )
    authorization_ok = not guest_authorization_required or bool(
        re.search(r"гостев\w+\s+заявк\w*.{0,100}(?:прав\w*\s+доступ|разрешен\w*\s+на\s+въезд|авторизац)", clean)
        or re.search(r"(?:прав\w*\s+доступ|разрешен\w*\s+на\s+въезд|авторизац).{0,100}гостев\w+\s+заявк", clean)
    )

    assisted_required = any(
        (plan.get("assisted_recovery") or {}).get("usage") == "exception_only"
        for plan in plans.values()
    )
    assisted_ok = not assisted_required or bool(
        re.search(r"оператор.{0,100}(?:исключительн|ручн\w*\s+обработ|только\s+для)|"
                  r"(?:исключительн|ручн\w*\s+обработ|только\s+для).{0,100}оператор", clean)
    )

    pending_fallback = architecture.get("architecture_type") == "primary_with_pending_fallback"
    fallback_ok = not pending_fallback or bool(
        re.search(r"(?:резерв.{0,90}(?:не\s+выбран|нужно\s+(?:выбрать|определить)|зависит)|"
                  r"(?:считывател|инфраструктур).{0,100}не\s+подтвержден)", clean)
    )
    unknown_required = bool(
        package.get("candidate_credentials_requiring_confirmation")
        or "fallback_reader_infrastructure" in (package.get("missing_critical_facts") or [])
    )
    unknown_ok = not unknown_required or bool(
        re.search(r"(?:не\s+подтвержден|неизвест|нужно\s+подтвердить|после\s+проверки|зависит\s+от\s+наличия)", clean)
    )

    comparison_required = bool(re.search(r"карт", message) and re.search(r"билет", message))
    card_tradeoff = bool(re.search(r"карт\w*.{0,100}(?:выдач|возврат|учет|контрол\w*\s+состояни)", clean))
    ticket_tradeoff = bool(re.search(r"билет\w*.{0,100}(?:лент|механизм|обслужив)", clean))
    condition = bool(re.search(r"(?:зависит|в\s+зависимости|поток|эксплуатац)", clean))
    tradeoffs_ok = not comparison_required or (card_tradeoff and ticket_tradeoff and condition)

    next_question = str(package.get("next_question") or "").strip()
    question_ok = not next_question or _exact_question_present(answer, next_question)
    reasons: list[str] = []
    if not primary_ok:
        reasons.append("missing_primary_identifier")
    if not segments_ok:
        reasons.append("missing_required_segments")
    if not authorization_ok:
        reasons.append("missing_guest_authorization")
    if not assisted_ok:
        reasons.append("missing_assisted_recovery")
    if not fallback_ok:
        reasons.append("missing_fallback_semantics")
    if not tradeoffs_ok:
        reasons.append("missing_required_tradeoff")
    if not unknown_ok:
        reasons.append("missing_unknown_conditionality")
    if not question_ok:
        reasons.append("missing_or_wrong_next_question")
    return SemanticCoverageResult(
        primary="pass" if primary_ok else "missing",
        segments="pass" if segments_ok else "missing",
        authorization="pass" if authorization_ok else "missing",
        assisted_recovery="pass" if assisted_ok else "missing",
        fallback_semantics="pass" if fallback_ok else "missing",
        tradeoffs="pass" if tradeoffs_ok else "missing",
        unknown_conditionality="pass" if unknown_ok else "missing",
        next_question="pass" if question_ok else "missing",
        status="pass" if not reasons else "review_required",
        reason_codes=tuple(reasons),
    )
