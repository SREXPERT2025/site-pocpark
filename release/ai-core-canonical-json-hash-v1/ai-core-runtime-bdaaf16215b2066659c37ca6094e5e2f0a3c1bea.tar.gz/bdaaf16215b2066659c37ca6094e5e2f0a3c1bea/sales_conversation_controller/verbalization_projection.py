from __future__ import annotations

import math
import re
from typing import Any

from .site_contract_runtime_v1.canonical import (
    CANONICALIZATION_VERSION,
    canonical_json,
    canonical_sha256,
    sha256,
)


PROJECTION_VERSION = "1.0"
MODEL_PROMPT_SCHEMA_VERSION = "1.1"
FORBIDDEN_MODEL_PROMPT_PATTERNS = (
    r"\bexact_next_question\b",
    r"\bNEXT_QUESTION_PLACEHOLDER\b",
    r"\bdecision_package_hash\b",
    r"\bsource_decision_package_hash\b",
    r"\bprojection_hash\b",
    r"\b(?:mutation|state|fallback|authorization|identifier)_[a-z0-9_]+\b",
    r"\b[a-z]+(?:_[a-z0-9]+)+\b",
)
RELEVANT_FACT_FIELDS = (
    "object_type", "entrances_count", "exits_count", "daily_traffic",
    "user_segments", "operator_present", "speed_priority",
    "mandatory_automated_fallback",
)


def forbidden_internal_tokens(text: str) -> list[str]:
    found: list[str] = []
    for pattern in FORBIDDEN_MODEL_PROMPT_PATTERNS:
        found.extend(match.group(0) for match in re.finditer(pattern, str(text or ""), re.I))
    return list(dict.fromkeys(found))


def build_verbalization_projection(
    decision_package: dict[str, Any],
    *,
    current_message: str,
    confirmed_project_facts: list[dict[str, Any]],
    source_decision_package_hash: str,
    canonicalization_version: str,
) -> dict[str, Any]:
    if canonicalization_version != CANONICALIZATION_VERSION:
        raise ValueError("unsupported_projection_canonicalization_version")
    if not re.fullmatch(r"[a-f0-9]{64}", source_decision_package_hash):
        raise ValueError("invalid_projection_source_decision_package_hash")
    if source_decision_package_hash != canonical_sha256(decision_package):
        raise ValueError("projection_source_decision_package_hash_mismatch")
    architecture = decision_package.get("recommended_architecture") or {}
    segments = architecture.get("segments") or {}
    selected_facts = {
        item["field"]: item["value"]
        for item in confirmed_project_facts
        if item.get("field") in RELEVANT_FACT_FIELDS
    }
    projected_segments = {
        name: {
            "authorization": plan.get("authorization"),
            "primary_identifier": plan.get("primary_identifier"),
            "automated_fallback_credentials": plan.get("automated_fallback_credentials") or [],
            "assisted_recovery": plan.get("assisted_recovery"),
            "failure_policy": plan.get("failure_policy"),
        }
        for name, plan in sorted(segments.items())
    }
    has_confirmed_fallback = any(
        plan["automated_fallback_credentials"] for plan in projected_segments.values()
    )
    projection: dict[str, Any] = {
        "schema_version": PROJECTION_VERSION,
        "canonicalization_version": canonicalization_version,
        "source_decision_package_hash": source_decision_package_hash,
        "client_intent": {
            "decision_type": decision_package.get("decision_type"),
            "current_message": current_message,
        },
        "relevant_confirmed_facts": selected_facts,
        "required_primary_architecture": {
            "architecture_type": architecture.get("architecture_type"),
            "components": architecture.get("components") or [],
        },
        "segment_semantics": projected_segments,
        "fallback_status": "selected" if has_confirmed_fallback else (
            "pending_infrastructure_confirmation"
            if architecture.get("architecture_type") == "primary_with_pending_fallback"
            else "not_required_or_not_selected"
        ),
        "required_tradeoffs": list(decision_package.get("tradeoffs") or []),
        "unknown_prerequisite_constraints": {
            "missing_critical_facts": list(decision_package.get("missing_critical_facts") or []),
            "candidate_credentials_requiring_confirmation": list(
                decision_package.get("candidate_credentials_requiring_confirmation") or []
            ),
        },
        "must_not_claim": [
            "candidate_as_recommendation",
            "unknown_reader_as_confirmed",
            "operator_as_automated_fallback",
            "guest_application_as_lane_identifier",
            "new_engineering_decision",
            "different_next_question",
        ],
        "exact_next_question": decision_package.get("next_question"),
        "concise_evidence_refs": list(dict.fromkeys(decision_package.get("evidence_refs") or [])),
    }
    projection["projection_hash"] = sha256(projection)
    return projection


def projection_decision_drift(
    projection: dict[str, Any], decision_package: dict[str, Any], *,
    expected_source_decision_package_hash: str | None = None,
    expected_canonicalization_version: str = CANONICALIZATION_VERSION,
) -> list[str]:
    drift: list[str] = []
    if expected_canonicalization_version != CANONICALIZATION_VERSION:
        drift.append("expected_canonicalization_version")
    if projection.get("canonicalization_version") != expected_canonicalization_version:
        drift.append("canonicalization_version")
    canonical_package_hash = canonical_sha256(decision_package)
    expected_hash = expected_source_decision_package_hash or canonical_package_hash
    if expected_hash != canonical_package_hash:
        drift.append("decision_package_hash")
    if projection.get("source_decision_package_hash") != expected_hash:
        drift.append("source_decision_package_hash")
    architecture = decision_package.get("recommended_architecture") or {}
    projected_architecture = projection.get("required_primary_architecture") or {}
    if projected_architecture.get("architecture_type") != architecture.get("architecture_type"):
        drift.append("architecture_type")
    if projected_architecture.get("components") != (architecture.get("components") or []):
        drift.append("components")
    expected_segments = architecture.get("segments") or {}
    actual_segments = projection.get("segment_semantics") or {}
    for name, expected in expected_segments.items():
        actual = actual_segments.get(name) or {}
        for field in (
            "authorization", "primary_identifier", "automated_fallback_credentials",
            "assisted_recovery", "failure_policy",
        ):
            if actual.get(field) != (expected.get(field) or ([] if field == "automated_fallback_credentials" else None)):
                drift.append(f"segments.{name}.{field}")
    if projection.get("exact_next_question") != decision_package.get("next_question"):
        drift.append("next_question")
    return drift


def _fact_lines(facts: dict[str, Any]) -> list[str]:
    labels = {
        "object_type": "Тип объекта", "entrances_count": "Количество въездов",
        "exits_count": "Количество выездов", "daily_traffic": "Машин в день",
        "operator_present": "Оператор присутствует", "speed_priority": "Приоритет скорости",
        "mandatory_automated_fallback": "Автоматический резерв обязателен",
    }
    value_labels = {"business_center": "бизнес-центр", "high": "высокий", True: "да", False: "нет"}
    lines = [
        f"{labels[field]}: {value_labels.get(value, value)}"
        for field, value in sorted(facts.items()) if field in labels
    ]
    segments = facts.get("user_segments") or []
    segment_labels = {"employees": "сотрудники", "tenants": "арендаторы", "guests": "гости"}
    if segments:
        lines.append("Категории пользователей: " + ", ".join(segment_labels.get(item, item) for item in segments))
    return lines


def _segment_lines(segments: dict[str, Any]) -> list[str]:
    labels = {"employees": "Сотрудники", "tenants": "Арендаторы", "guests": "Гости"}
    lines: list[str] = []
    for name in ("employees", "tenants", "guests"):
        plan = segments.get(name) or {}
        primary = (plan.get("primary_identifier") or {}).get("type")
        authorization = (plan.get("authorization") or {}).get("type")
        if primary != "license_plate_recognition":
            continue
        if name == "guests" and authorization == "guest_application":
            lines.append(
                "Гости: гостевая заявка задаёт право доступа, а распознавание зарегистрированного номера идентифицирует автомобиль на полосе."
            )
        else:
            lines.append(f"{labels[name]}: право доступа задаёт реестр, основной способ идентификации — распознавание номеров.")
    return lines


def build_projection_prompt(projection: dict[str, Any]) -> tuple[str, dict[str, int | str]]:
    facts = projection.get("relevant_confirmed_facts") or {}
    tradeoffs = projection.get("required_tradeoffs") or []
    next_question = str(projection.get("exact_next_question") or "").strip()
    lines = [
        "Ты кратко и естественно объясняешь клиенту уже принятое инженерное решение РОСПАРК.",
        "Не принимай новое решение, не добавляй оборудование и не выбирай резервный способ.",
        "Не превращай неподтверждённый вариант в рекомендацию и не считай неизвестную инфраструктуру установленной.",
        "Оператор участвует только в ручной обработке исключительных ситуаций и не является автоматическим резервом.",
        "Вопрос клиента: " + str((projection.get("client_intent") or {}).get("current_message") or ""),
        "Подтверждённые данные:",
        *_fact_lines(facts),
        "Решение по категориям:",
        *_segment_lines(projection.get("segment_semantics") or {}),
    ]
    if projection.get("fallback_status") == "pending_infrastructure_confirmation":
        lines.append("Конкретный автоматический резерв пока не выбран: сначала нужно подтвердить инфраструктуру считывателей.")
    if tradeoffs:
        lines.append("Сравнение карт и билетов:")
        lines.extend(str(item) for item in tradeoffs)
    lines.extend((
        "Не добавляй других вопросов.",
        "Заверши ответ ровно этим вопросом: " + next_question,
    ))
    prompt = "\n".join(line for line in lines if line.strip())
    leaked = forbidden_internal_tokens(prompt)
    if leaked:
        raise ValueError("forbidden_internal_token_in_model_prompt:" + ",".join(leaked))
    characters = len(prompt)
    metrics: dict[str, int | str] = {
        "characters": characters,
        "bytes": len(prompt.encode("utf-8")),
        "word_count": len(prompt.split()),
        "estimated_tokens": math.ceil(characters / 4),
        "exact_tokens": "token_count_pending_real_probe",
    }
    return prompt, metrics


def build_model_prompt_contract(projection: dict[str, Any]) -> dict[str, Any]:
    prompt, metrics = build_projection_prompt(projection)
    return {
        "model_prompt_schema_version": MODEL_PROMPT_SCHEMA_VERSION,
        "canonicalization_version": projection.get("canonicalization_version"),
        "prompt_hash": sha256(prompt),
        "projection_hash": sha256(projection),
        "source_decision_package_hash": projection.get("source_decision_package_hash"),
        "serialized_prompt": prompt,
        "metrics": metrics,
        "forbidden_internal_tokens": [],
    }
