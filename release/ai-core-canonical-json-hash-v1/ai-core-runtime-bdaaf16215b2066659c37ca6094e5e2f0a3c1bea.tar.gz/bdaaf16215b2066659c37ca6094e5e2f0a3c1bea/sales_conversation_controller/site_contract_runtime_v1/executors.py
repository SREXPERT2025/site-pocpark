from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StubOutput:
    answer: str
    latency_ms: int
    cost_bucket: str


class StubExecutorError(RuntimeError):
    safe_error_code = "EXECUTOR_SAFE_ERROR"
    status = "safe_error"


class StubExecutorTimeout(StubExecutorError):
    safe_error_code = "EXECUTOR_TIMEOUT"
    status = "timeout"


class StubExecutorUnavailable(StubExecutorError):
    safe_error_code = "EXECUTOR_UNAVAILABLE"
    status = "unavailable"


def _engineering_answer(package: dict[str, Any]) -> str:
    question = str(package.get("next_question") or "").strip()
    parts = [
        "Для сотрудников и арендаторов предварительно можно рассматривать распознавание номеров как основной способ проезда.",
        "Для гостей право доступа может формироваться через гостевую заявку, а идентификация — по заранее зарегистрированному номеру либо другому подтверждённому носителю.",
        "Автоматический резерв определяется отдельно для каждой категории после проверки установленного оборудования; оператор используется только для исключительных ситуаций.",
        "Карты и билеты создают разные виды эксплуатационной нагрузки, поэтому их нужно сравнивать по потоку, бесплатному периоду, возврату карт и расходу билетной ленты.",
    ]
    if question:
        parts.append(question)
    return " ".join(parts)


def _deterministic_answer(context: dict[str, Any]) -> str:
    package = context["decision_package"]
    resolution = context["context_resolution"]
    message = context["current_message"]
    if package.get("decision_type") == "access_identifier_selection":
        return _engineering_answer(package)
    action = resolution.get("command_requirements", {}).get("action_type")
    if resolution.get("relation") == "answer_to_previous_question":
        facts = resolution.get("extracted_facts") or {}
        if "current_system" in facts:
            return "Понял: парковочная система у вас уже установлена."
        if facts:
            name = next(key for key in facts if not key.endswith("__fact_type"))
            return f"Понял и учёл: {facts[name]}."
        return "Понял ваш ответ на предыдущий вопрос."
    if action == "utility_request":
        return "2+2 = 4."
    if action == "remember_fact":
        facts = resolution.get("extracted_facts") or {}
        if "entry_price_rub" in facts:
            return (
                f"Зафиксировал: стоимость въезда — {facts['entry_price_rub']} рублей; "
                "шлагбаум открывается только после подтверждения оплаты."
            )
        if facts:
            name = next(key for key in facts if not key.endswith("__fact_type"))
            return f"Зафиксировал подтверждённое значение: {name} — {facts[name]}."
        return "Не удалось выделить подтверждённый факт из текущей реплики."
    if action == "ask_one_question":
        return str(package.get("next_question") or "Какой тип объекта планируется автоматизировать?")
    if action == "conversation_summary":
        return (
            "По истории разговора обсуждаются бизнес-центр, два въезда и два выезда, поток автомобилей, "
            "распознавание номеров, доступ гостей и резервный сценарий."
        )
    if action in {"recall_facts", "memory_conflict_resolution"}:
        facts = context.get("confirmed_project_facts") or []
        values = [f"{item['field']} — {item['value']}" for item in facts[:5]]
        answer = "Вы сообщали: " + "; ".join(values) + "."
        if context.get("fact_conflicts"):
            answer += " Есть открытое противоречие в ранее сообщённых данных; его нужно отдельно уточнить."
        return answer
    if action in {"provide_source", "provide_link"}:
        refs = context.get("evidence_refs") or []
        if refs:
            return f"Источник — раздел «Парковочный доступ»; безопасная ссылка на него: `{refs[0]}`."
        route = (resolution.get("retrieval") or {}).get("required_route")
        return f"Подтверждённый источник: `{route}`." if route else "Для ответа нужен подтверждённый источник."
    if action == "compare_options":
        return "Сравнение нужно выполнять по подтверждённым условиям объекта; неподтверждённые варианты остаются кандидатами."
    return f"Текущая реплика принята: {message}"


class QwenStub:
    executor = "qwen"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        return StubOutput(_deterministic_answer(context), 4, "local_low")


class CodexStub:
    executor = "codex"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        return StubOutput(_deterministic_answer(context), 5, "external_low")


class CodexTimeoutStub:
    executor = "codex"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        raise StubExecutorTimeout("safe_stub_timeout")


class CodexUnavailableStub:
    executor = "codex"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        raise StubExecutorUnavailable("safe_stub_unavailable")
