# AI Core Site Contract V1.1

Immutable offline contract artifact для будущего Site adapter Phase 2.

Contract V1.1 формализует единственное состояние и единственный Decision Package
для взаимозаменяемых Qwen/Codex executors. Он не подключает AI Core к сайту и
не разрешает model call, gateway change или production activation.

## Владение

- Site владеет transport idempotency, lifecycle state и применением mutations.
- AI Core владеет Context Resolution, Controller Decision, Decision Package,
  executor selection, Response Repair и Evaluation Integrity.
- Qwen/Codex только формулируют один и тот же Decision Package.
- State mutation возвращается как proposal и применяется Site только после ack.

## Схемы

- `request-v1.schema.json` — transport envelope и domain payload;
- `response-v1.schema.json` — успешный результат AI Core;
- `state-mutation-v1.schema.json` — предложение изменения state;
- `mutation-ack-v1.schema.json` — Site-owned acknowledgement;
- `error-envelope-v1.schema.json` — безопасная ошибка без exception/PII;
- `executor-policy-v1.schema.json` — planned assignment и один fallback;
- `executor-trace-v1.schema.json` — attempts/final executor/fallback;
- `telemetry-v1.schema.json` — operational telemetry без свободного текста.
- `CANONICAL_JSON_HASH_V1.md` — language-neutral byte contract для hash;
- `fixtures/canonical-json-hash-v1-golden.json` — единый golden corpus Python/JS;
- `fixtures/regression/failed-live-decision-package.json` — обезличенный
  regression первого production incident.

Decision Package V1.2 остаётся внешней immutable dependency AI Core и не
переопределяется этим transport package. Его hash обязан пересчитываться по
`CANONICAL_JSON_HASH_V1` и совпадать в response, каждом executor attempt и
Response Repair. Runtime hash не считается доверенным без Site recomputation.

## Инварианты

- current user turn имеет приоритет;
- page/demo/article context — hint, а не fact;
- candidate не является recommendation;
- unknown остаётся unknown;
- guest application — authorization, а не identifier;
- operator — exception recovery, а не automated fallback;
- LLM не меняет Decision Package;
- Response Repair не принимает инженерное решение;
- Evaluation Integrity оценивает final visible candidate;
- один thread имеет одно последовательное state независимо от executor;
- максимум один model fallback; части двух ответов не смешиваются.

Контракт не содержит сущности и значения контактного согласия, recovery
credential, CRM/lead/MAX payload или production secrets.
