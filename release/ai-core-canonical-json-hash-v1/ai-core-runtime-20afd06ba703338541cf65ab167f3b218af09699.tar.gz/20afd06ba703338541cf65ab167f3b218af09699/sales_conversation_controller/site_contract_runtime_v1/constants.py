from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
CONTRACT_ROOT = ROOT / "generated/contracts/AI_CORE_SITE_CONTRACT_V1_1"
CONTRACT_TARGET_SHA = "6cd71a5596346925ecdd2ffeb9d45262d881ee93"
CONTRACT_VERSION = "1.1"
CANONICALIZATION_VERSION = "CANONICAL_JSON_HASH_V1"
DECISION_PACKAGE_SCHEMA = "1.2"
RUNTIME_VERSION = "1.2.2"
REPAIR_REWRITE_REVIEW_THRESHOLD = 0.35
NON_ENGINEERING_DECISION_SCHEMA = (
    Path(__file__).with_name("schemas") / "decision-package-not-required-v1.schema.json"
)

BLOCKING_EVALUATION_REASON_CODES = frozenset({
    "command_assessment_failed",
    "context_assessment_failed",
    "current_command_not_fulfilled",
    "current_turn_ignored",
    "question_consistency_failed",
    "repair_rewrite_ratio_exceeded",
})

RUNTIME_ORDER = (
    "request_schema_validation",
    "current_turn_ingestion",
    "context_integrity",
    "command_relation_intent_resolution",
    "state_context_resolution",
    "sales_conversation_controller",
    "engineering_decision_laboratory",
    "question_planner",
    "decision_package_freeze_hash",
    "executor_selection",
    "executor_output",
    "response_repair",
    "evaluation_integrity",
    "state_mutation_proposals",
    "response_schema_validation",
)

COMPONENT_VERSIONS = {
    "context_integrity": "2.2",
    "sales_controller": "1",
    "engineering_lab": "1.2",
    "access_decision_ontology": "1.2",
    "question_planner": "1.2",
    "executor_adapter": "1",
    "response_repair": "1.0",
    "evaluation_integrity": "2.2.2",
    "engineering_knowledge": "2.2",
    "fast_route_context_gate": "not_invoked",
}
