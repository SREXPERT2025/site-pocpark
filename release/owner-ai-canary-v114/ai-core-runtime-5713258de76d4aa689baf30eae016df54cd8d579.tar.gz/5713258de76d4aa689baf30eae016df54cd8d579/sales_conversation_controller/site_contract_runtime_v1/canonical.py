from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256(value: Any) -> str:
    source = value if isinstance(value, str) else canonical_json(value)
    return hashlib.sha256(source.encode("utf-8")).hexdigest()
