from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .canonical import sha256
from .constants import CONTRACT_ROOT


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    errors: tuple[dict[str, Any], ...] = ()


class ContractSchemaValidator:
    """Проверяет payload по неизменным схемам Contract V1 через локальный Ajv."""

    def __init__(self, contract_root: Path = CONTRACT_ROOT) -> None:
        self.contract_root = contract_root
        self.bridge = Path(__file__).with_name("schema_validator.cjs")

    def verify_dependency(self) -> dict[str, Any]:
        manifest_path = self.contract_root / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        mismatches = []
        for relative, expected in manifest["artifacts_sha256"].items():
            path = self.contract_root / relative
            if not path.is_file() or sha256(path.read_text(encoding="utf-8")) != expected:
                # Манифест считает байты; отдельная ветка ниже исключает перевод строк.
                import hashlib
                actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
                if actual != expected:
                    mismatches.append(relative)
        return {
            "contract_version": manifest.get("contract_version"),
            "manifest_schema": manifest.get("schema_version"),
            "artifact_count": len(manifest.get("artifacts_sha256") or {}),
            "hash_mismatches": mismatches,
            "passed": not mismatches and manifest.get("contract_version") == "1.0",
        }

    def validate(self, schema_name: str, document: dict[str, Any]) -> ValidationResult:
        return self._run(schema_name, document)

    def validate_external(self, schema_path: Path, document: dict[str, Any]) -> ValidationResult:
        return self._run("external-runtime-schema.json", document, external_schema=schema_path)

    def _run(
        self, schema_name: str, document: dict[str, Any], *, external_schema: Path | None = None,
    ) -> ValidationResult:
        env = dict(os.environ)
        if not env.get("NODE_PATH"):
            local_node_modules = Path("/Volumes/POCPARK_AI_DATA/POCPARK_SITE_AI/repo/node_modules")
            if local_node_modules.is_dir():
                env["NODE_PATH"] = str(local_node_modules)
        command = ["node", str(self.bridge), str(self.contract_root), schema_name]
        if external_schema is not None:
            command.append(str(external_schema))
        completed = subprocess.run(
            command,
            input=json.dumps(document, ensure_ascii=False), text=True,
            capture_output=True, check=False, env=env, timeout=10,
        )
        try:
            result = json.loads(completed.stdout)
        except json.JSONDecodeError:
            return ValidationResult(False, ({"keyword": "validator_unavailable", "dataPath": ""},))
        return ValidationResult(bool(result.get("valid")), tuple(result.get("errors") or ()))
