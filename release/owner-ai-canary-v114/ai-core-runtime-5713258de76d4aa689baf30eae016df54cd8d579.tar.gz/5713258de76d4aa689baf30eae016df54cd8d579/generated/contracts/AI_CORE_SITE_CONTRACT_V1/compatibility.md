# Version compatibility and transport semantics

## Версии

Canonical contract version: `1.0`.

- additive optional field без изменения смысла — совместимый minor release;
- новое required field, удаление поля, изменение enum или семантики — новый major schema ID;
- неизвестный major или неизвестная component version — fail closed;
- `not_invoked` разрешён только для компонента, который действительно не участвовал;
- Site pin-ит schema package hash и не выводит версию из имени файла или branch.

## Idempotency

Site владеет idempotency store.

Ключ обработки:

```text
conversation_thread_id + message_id + idempotency_key
```

`request_payload_hash` — SHA-256 канонического JSON объекта `payload` с
сортированными ключами и компактными separators.

- повтор с тем же ключом и тем же payload hash возвращает byte-identical cached response;
- тот же ключ с другим payload hash возвращает safe error
  `IDEMPOTENCY_CONFLICT` и не вызывает AI Core;
- timeout не разрешает слепой повтор: сначала Site проверяет сохранённый response;
- `request_id`, `sent_at` и trace context не меняют identity domain payload;
- mutation ID применяется не более одного раза и получает deterministic ack.

## Executor и fallback

- planned assignment передаёт Site и AI Core его не изменяет;
- целевая цепочка: `codex → qwen`;
- разрешён максимум один model fallback;
- каждый attempt использует одинаковые `decision_package_hash` и `state_version`;
- fallback не меняет confirmed facts, next question или thread state;
- `final_executor` равен единственному successful attempt;
- текст ответа берётся целиком только от final executor;
- deterministic FAQ/safe response — route, а не executor reassignment.

## Mutations

AI Core возвращает proposal с `expected_state_version`. Site проверяет schema,
authority, privacy, version и conflict, затем возвращает `mutation-ack-v1`.
Предложенная версия должна быть ровно `expected_state_version + 1` для
последовательного применения. Hint с `unconfirmed` provenance нельзя применить
как confirmed fact. Decision Package не является mutation target.

## Ошибки

Error envelope содержит только стабильный code/category/retryable/stage и
safe message code. Raw exception, stack trace, свободный пользовательский текст,
PII и credential запрещены.

## Publication

Только final visible candidate с Evaluation Integrity `pass` может быть
кандидатом на публикацию. `review_required`, `fail` и `not_evaluable` не дают
автоматического разрешения. Настоящая production policy остаётся отдельным gate.

