#!/usr/bin/env node
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Ajv = require('ajv');

const ROOT = __dirname;
const load = (relative) => JSON.parse(
  fs.readFileSync(path.join(ROOT, relative), 'utf8'),
);

const ajv = new Ajv({allErrors: true, jsonPointers: true, schemaId: 'auto'});
for (const name of [
  'executor-policy-v1.schema.json',
  'state-mutation-v1.schema.json',
  'mutation-ack-v1.schema.json',
  'error-envelope-v1.schema.json',
  'executor-trace-v1.schema.json',
  'telemetry-v1.schema.json',
  'request-v1.schema.json',
  'response-v1.schema.json',
]) {
  ajv.addSchema(load(name), name);
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function accepts(value) {
  return ajv.validate('response-v1.schema.json', value) === true;
}

function patch(base, mutate) {
  const value = clone(base);
  mutate(value);
  return value;
}

const qwen = load('fixtures/valid/response-qwen.json');
const codex = load('fixtures/valid/response-codex.json');
const deterministic = load('fixtures/valid/response-deterministic-courtesy.json');

assert.strictEqual(accepts(qwen), true, 'model success qwen rejected');
assert.strictEqual(accepts(codex), true, 'model success codex rejected');
assert.strictEqual(accepts(deterministic), true, 'deterministic success rejected');
assert.strictEqual(deterministic.executor_trace.execution_mode, 'deterministic');
assert.deepStrictEqual(deterministic.executor_trace.attempts, []);
assert.strictEqual(deterministic.executor_trace.final_executor, null);
assert.strictEqual(deterministic.executor_trace.model_request_count, 0);
assert.strictEqual(deterministic.evaluation_result.status, 'pass');
assert.strictEqual(
  deterministic.telemetry.publication.candidate_status,
  'allowed',
);

assert.strictEqual(accepts(patch(deterministic, (value) => {
  value.executor_trace.attempts = clone(qwen.executor_trace.attempts);
})), false, 'deterministic plus model attempt accepted');
assert.strictEqual(accepts(patch(deterministic, (value) => {
  value.executor_trace.final_executor = 'qwen';
})), false, 'deterministic plus final executor accepted');
assert.strictEqual(accepts(patch(deterministic, (value) => {
  value.executor_trace.model_request_count = 1;
})), false, 'deterministic plus model request accepted');
assert.strictEqual(accepts(patch(qwen, (value) => {
  value.executor_trace.attempts = [];
})), false, 'model mode without attempts accepted');
assert.strictEqual(accepts(patch(qwen, (value) => {
  value.executor_trace.final_executor = null;
})), false, 'model mode without final executor accepted');

console.log(JSON.stringify({
  model_qwen: 'pass',
  model_codex: 'pass',
  deterministic_success: 'pass',
  attempts_empty: 'pass',
  final_executor_null: 'pass',
  model_request_count_zero: 'pass',
  deterministic_handler: 'pass',
  evaluation_integrity_required: true,
  publication_gate_required: true,
  site_validation_compatibility: 'pass',
  model_requests: 0,
  production_changes: 0,
}, null, 2));
