#!/usr/bin/env node
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Ajv = require('ajv');
const {
  CANONICALIZATION_VERSION,
  canonicalJson: canonical,
  canonicalSha256: sha256,
} = require('./reference/canonical-json-hash-v1.cjs');

const ROOT = __dirname;
const FIXTURES = path.join(ROOT, 'fixtures');
const SCHEMAS = [
  'executor-policy-v1.schema.json',
  'state-mutation-v1.schema.json',
  'mutation-ack-v1.schema.json',
  'error-envelope-v1.schema.json',
  'executor-trace-v1.schema.json',
  'telemetry-v1.schema.json',
  'request-v1.schema.json',
  'response-v1.schema.json',
];
const FORBIDDEN_KEYS = new Set([
  'contact', 'phone', 'email', 'consent', 'recovery_credential',
  'crm_owner', 'max_identity', 'utm_raw', 'raw_exception', 'stack_trace',
]);
const DETERMINISTIC_HANDLERS = new Set([
  'courtesy', 'utility', 'assistant_identity', 'assistant_capabilities',
  'executor_identity_policy', 'safe_response',
]);

function load(relative) {
  return JSON.parse(fs.readFileSync(path.join(ROOT, relative), 'utf8'));
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function pointerParent(document, pointer) {
  const parts = pointer.split('/').slice(1).map((part) => part.replace(/~1/g, '/').replace(/~0/g, '~'));
  const key = parts.pop();
  let current = document;
  for (const part of parts) current = current[Array.isArray(current) ? Number(part) : part];
  return [current, key];
}

function applyPatch(document, patches) {
  const result = deepClone(document);
  for (const patch of patches) {
    const [parent, key] = pointerParent(result, patch.path);
    if (patch.op === 'replace') parent[Array.isArray(parent) ? Number(key) : key] = deepClone(patch.value);
    else if (patch.op === 'append') parent[key].push(deepClone(patch.value));
    else throw new Error(`unsupported_patch:${patch.op}`);
  }
  return result;
}

function scanForbidden(value, location = '$') {
  if (Array.isArray(value)) return value.flatMap((item, index) => scanForbidden(item, `${location}[${index}]`));
  if (!value || typeof value !== 'object') return [];
  const findings = [];
  for (const [key, item] of Object.entries(value)) {
    if (FORBIDDEN_KEYS.has(key)) findings.push(`${location}.${key}`);
    findings.push(...scanForbidden(item, `${location}.${key}`));
  }
  return findings;
}

function mutationSemantics(mutation) {
  if (mutation.proposed_state_version !== mutation.expected_state_version + 1) return false;
  if (mutation.field.startsWith('decision_package')) return false;
  if (mutation.operation === 'set_confirmed_fact') {
    if (mutation.provenance.confirmation_status !== 'confirmed') return false;
    if (!['user_message', 'authorized_system_ref'].includes(mutation.provenance.source_type)) return false;
  }
  return true;
}

function responseSemantics(response) {
  const trace = response.executor_trace;
  const hashes = [
    response.decision_package_hash,
    trace.decision_package_hash,
    response.repair_result.decision_package_hash,
    ...trace.attempts.map((attempt) => attempt.decision_package_hash),
  ];
  if (new Set(hashes).size !== 1) return false;
  if (sha256(response.decision_package) !== response.decision_package_hash) return false;
  if (trace.attempts.some((attempt, index) => attempt.attempt_index !== index + 1)) return false;
  if (trace.attempts.some((attempt) => attempt.state_version !== trace.state_version)) return false;
  if (trace.state_version !== response.state_version_before) return false;
  if (trace.model_request_count !== trace.attempts.length) return false;
  if (trace.execution_mode === 'model') {
    if (trace.deterministic_handler !== null || trace.attempts.length < 1) return false;
    if (trace.attempts[0].executor !== trace.planned_executor) return false;
    const successful = trace.attempts.filter((attempt) => attempt.status === 'success');
    if (successful.length !== 1 || successful[0].executor !== trace.final_executor) return false;
    if (trace.attempts.length === 1 && trace.fallback_reason !== 'none') return false;
    if (trace.attempts.length === 2) {
      if (trace.planned_executor !== 'codex') return false;
      if (trace.attempts[0].executor !== 'codex' || trace.attempts[0].status === 'success') return false;
      if (trace.attempts[1].executor !== 'qwen' || trace.attempts[1].status !== 'success') return false;
      if (trace.fallback_reason === 'none') return false;
    }
  } else if (trace.execution_mode === 'deterministic') {
    if (trace.attempts.length !== 0 || trace.model_request_count !== 0) return false;
    if (trace.planned_executor !== null || trace.final_executor !== null) return false;
    if (trace.fallback_reason !== 'none') return false;
    if (!DETERMINISTIC_HANDLERS.has(trace.deterministic_handler)) return false;
  } else {
    return false;
  }
  if (JSON.stringify(response.component_versions) !== JSON.stringify(response.telemetry.component_versions)) return false;
  if (response.telemetry.executor.execution_mode !== trace.execution_mode) return false;
  if (response.telemetry.executor.model_request_count !== trace.model_request_count) return false;
  if (response.telemetry.executor.deterministic_handler !== trace.deterministic_handler) return false;
  if (response.telemetry.executor.attempt_count !== trace.attempts.length) return false;
  if (response.telemetry.executor.planned !== trace.planned_executor) return false;
  if (response.telemetry.executor.final !== trace.final_executor) return false;
  if (response.telemetry.executor.fallback_used !== (trace.attempts.length === 2)) return false;
  if (response.telemetry.publication.candidate_status === 'allowed'
      && response.evaluation_result.status !== 'pass') return false;
  if ((response.decision_package.next_question ?? null) !== response.next_question) return false;
  if (response.state_mutations.some((mutation) => !mutationSemantics(mutation))) return false;
  if (response.state_mutations.length === 0 && response.state_version_after !== response.state_version_before) return false;
  return true;
}

const ajv = new Ajv({allErrors: true, jsonPointers: true, schemaId: 'auto'});
const schemaDocuments = new Map();
for (const name of SCHEMAS) {
  const schema = load(name);
  assert.strictEqual(ajv.validateSchema(schema), true, `schema invalid: ${name}`);
  schemaDocuments.set(name, schema);
  ajv.addSchema(schema, name);
}

function schemaAccepts(schemaName, document) {
  const valid = ajv.validate(schemaName, document);
  return {valid, errors: ajv.errors || []};
}

const validFixtures = [
  ['request-v1.schema.json', 'fixtures/valid/request-qwen.json'],
  ['request-v1.schema.json', 'fixtures/valid/request-codex.json'],
  ['response-v1.schema.json', 'fixtures/valid/response-qwen.json'],
  ['response-v1.schema.json', 'fixtures/valid/response-codex.json'],
  ['response-v1.schema.json', 'fixtures/valid/response-codex-timeout-qwen.json'],
  ['response-v1.schema.json', 'fixtures/valid/response-codex-unavailable-qwen.json'],
  ['response-v1.schema.json', 'fixtures/valid/response-deterministic-courtesy.json'],
  ['state-mutation-v1.schema.json', 'fixtures/valid/state-mutation.json'],
  ['mutation-ack-v1.schema.json', 'fixtures/valid/mutation-ack.json'],
  ['error-envelope-v1.schema.json', 'fixtures/valid/safe-error.json'],
];

for (const [schema, fixture] of validFixtures) {
  const document = load(fixture);
  const result = schemaAccepts(schema, document);
  assert.strictEqual(result.valid, true, `${fixture}: ${JSON.stringify(result.errors)}`);
  assert.deepStrictEqual(scanForbidden(document), [], `forbidden fields: ${fixture}`);
  if ('contract_version' in document) {
    assert.strictEqual(document.contract_version, '1.2', `contract version: ${fixture}`);
    assert.strictEqual(document.canonicalization_version, CANONICALIZATION_VERSION, `canonicalization version: ${fixture}`);
  }
  if (schema === 'request-v1.schema.json') assert.strictEqual(sha256(document.payload), document.request_payload_hash, `payload hash: ${fixture}`);
  if (schema === 'response-v1.schema.json') assert.strictEqual(responseSemantics(document), true, `response semantics: ${fixture}`);
  if (schema === 'state-mutation-v1.schema.json') assert.strictEqual(mutationSemantics(document), true, `mutation semantics: ${fixture}`);
}

const invalidPatchFixtures = [
  'fixtures/invalid/request-invalid-schema.json',
  'fixtures/invalid/response-unknown-component-version.json',
  'fixtures/invalid/response-decision-package-mutation-attempt.json',
  'fixtures/invalid/executor-trace-second-fallback.json',
  'fixtures/invalid/deterministic-with-model-attempt.json',
  'fixtures/invalid/deterministic-with-final-executor.json',
  'fixtures/invalid/model-with-empty-attempts.json',
  'fixtures/invalid/model-with-null-final-executor.json',
  'fixtures/invalid/deterministic-with-model-request.json',
  'fixtures/invalid/response-deterministic-handler-null.json',
  'fixtures/invalid/response-deterministic-handler-unknown.json',
  'fixtures/invalid/response-model-request-count-zero.json',
  'fixtures/invalid/response-model-deterministic-handler.json',
];
for (const fixture of invalidPatchFixtures) {
  const spec = load(fixture);
  const document = applyPatch(load(`fixtures/${spec.base_fixture}`), spec.patch);
  const schema = schemaAccepts(spec.schema, document);
  const semanticValid = spec.schema === 'response-v1.schema.json' ? responseSemantics(document) : true;
  assert.strictEqual(schema.valid && semanticValid, false, `invalid fixture accepted: ${fixture}`);
}

const invalidMutation = load('fixtures/invalid/state-mutation-invalid.json');
assert.strictEqual(schemaAccepts('state-mutation-v1.schema.json', invalidMutation).valid, true);
assert.strictEqual(mutationSemantics(invalidMutation), false, 'invalid state version accepted');

const promotedHint = load('fixtures/invalid/state-mutation-hint-promoted.json');
assert.strictEqual(schemaAccepts('state-mutation-v1.schema.json', promotedHint).valid, false, 'hint promoted to fact');

const unsafeError = load('fixtures/invalid/error-envelope-raw-exception.json');
assert.strictEqual(schemaAccepts('error-envelope-v1.schema.json', unsafeError).valid, false, 'raw exception accepted');

const retrySpec = load('fixtures/scenarios/idempotent-retry.json');
const first = load(`fixtures/${retrySpec.first_request}`);
const retry = load(`fixtures/${retrySpec.retry_request}`);
assert.strictEqual(first.idempotency_key, retry.idempotency_key);
assert.strictEqual(first.request_payload_hash, retry.request_payload_hash);
assert.strictEqual(canonical(first.payload), canonical(retry.payload));
const idempotencyStore = new Map();
const cachedResponse = load('fixtures/valid/response-qwen.json');
idempotencyStore.set(first.idempotency_key, {payloadHash: first.request_payload_hash, response: cachedResponse});
const cached = idempotencyStore.get(retry.idempotency_key);
assert.strictEqual(cached.payloadHash, retry.request_payload_hash);
assert.strictEqual(canonical(cached.response), canonical(cachedResponse));
assert.strictEqual(retrySpec.expected_model_calls_on_retry, 0);

const conflictSpec = load('fixtures/scenarios/idempotency-conflict.json');
const conflict = applyPatch(load(`fixtures/${conflictSpec.base_request}`), conflictSpec.patch);
const changedHash = sha256(conflict.payload);
assert.strictEqual(conflict.idempotency_key, first.idempotency_key);
assert.notStrictEqual(changedHash, first.request_payload_hash);
assert.strictEqual(conflictSpec.expected, 'IDEMPOTENCY_CONFLICT');
assert.strictEqual(conflictSpec.expected_model_calls, 0);

const golden = load('fixtures/canonical-json-hash-v1-golden.json');
assert.strictEqual(golden.canonicalization_version, CANONICALIZATION_VERSION);
for (const vector of golden.valid_vectors) {
  const value = JSON.parse(vector.semantic_json);
  assert.strictEqual(canonical(value), vector.expected_canonical_utf8, `canonical bytes: ${vector.id}`);
  assert.strictEqual(sha256(value), vector.expected_sha256, `canonical hash: ${vector.id}`);
}
const rejectionValues = new Map([
  ['NaN', Number.NaN],
  ['Infinity', Number.POSITIVE_INFINITY],
  ['-Infinity', Number.NEGATIVE_INFINITY],
  ['9007199254740992', 9007199254740992],
  ['unpaired_high_surrogate', '\ud800'],
]);
for (const vector of golden.rejection_vectors) {
  assert.throws(
    () => canonical(rejectionValues.get(vector.runtime_value)),
    (error) => error instanceof Error && error.message === vector.expected_error,
    `rejection: ${vector.id}`,
  );
}

const incident = load('fixtures/regression/failed-live-decision-package.json');
assert.strictEqual(incident.integral_float_count, 57);
assert.strictEqual(
  sha256(incident.decision_package),
  incident.expected_canonical_sha256,
  'failed live Decision Package regression',
);

const source = fs.readFileSync(__filename, 'utf8');
const forbiddenSourceFragments = [
  'child_' + 'process',
  'require(' + "'http'",
  'require(' + "'https'",
  'require(' + "'net'",
  'require(' + "'tls'",
  'fe' + 'tch(',
];
assert.strictEqual(forbiddenSourceFragments.some((fragment) => source.includes(fragment)), false, 'external side-effect primitive found');

console.log(JSON.stringify({
  schemas: SCHEMAS.length,
  valid_fixtures: validFixtures.length,
  invalid_fixtures: 16,
  scenario_fixtures: 2,
  canonicalization_version: CANONICALIZATION_VERSION,
  golden_vectors: golden.valid_vectors.length,
  rejection_vectors: golden.rejection_vectors.length,
  incident_regression: 'pass',
  decision_package_immutable: true,
  fallback_state_preserved: true,
  codex_primary_qwen_fallback: true,
  model_success_compatible: true,
  deterministic_success: true,
  deterministic_attempts_empty: true,
  deterministic_final_executor_null: true,
  deterministic_model_request_count_zero: true,
  model_requests: 0,
  external_side_effects: 0,
  result: 'pass'
}, null, 2));
