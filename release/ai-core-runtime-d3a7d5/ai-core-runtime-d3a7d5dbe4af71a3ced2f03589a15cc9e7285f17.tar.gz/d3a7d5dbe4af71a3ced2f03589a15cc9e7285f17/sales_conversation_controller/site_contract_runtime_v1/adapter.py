from __future__ import annotations

import copy
import re
from dataclasses import asdict, replace
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from typing import Any

from ..context_integrity_v22 import ContextIntentIntegrityLayerV22, IntegrityState
from ..contracts import ControllerInput, LeadCard
from ..controller import SalesConversationController
from ..decision_package_semantic_coverage import evaluate_semantic_coverage
from ..engineering_decision_lab import EngineeringDecisionEngine
from ..engineering_decision_lab.models import ALLOWED_FACT_FIELDS
from ..engineering_decision_lab.offline_replay import validate_decision_package
from ..evaluation_integrity_v222 import evaluate_business_status_v222
from ..postprocess import AnswerPostProcessor
from ..non_engineering_evaluation import BUSINESS_OPENER_ACTION, CONVERSATIONAL_COURTESY_ACTION
from ..verbalization_projection import (
    build_model_prompt_contract,
    build_verbalization_projection,
    internal_instruction_leaks,
    projection_decision_drift,
)
from ..verbalization_fidelity import evaluate_verbalization_fidelity
from .canonical import CanonicalizationError, canonical_json, sha256
from .constants import (
    BLOCKING_EVALUATION_REASON_CODES,
    CANONICALIZATION_VERSION,
    COMPONENT_VERSIONS,
    CONTRACT_VERSION,
    CONTRACT_TARGET_SHA,
    DECISION_PACKAGE_SCHEMA,
    NON_ENGINEERING_DECISION_SCHEMA,
    REPAIR_REWRITE_REVIEW_THRESHOLD,
    RUNTIME_ORDER,
    RUNTIME_VERSION,
)
from .executors import (
    CodexStub,
    QwenStub,
    StubExecutorError,
    StubExecutorTimeout,
    StubExecutorUnavailable,
)
from .schema_validation import ContractSchemaValidator
from .restricted_forensic import build_blocked_turn_forensic


class OfflineRuntimeAdapterV1:
    """Единый офлайн-конвейер Site Contract V1 без модельных вызовов."""

    contract_target_sha = CONTRACT_TARGET_SHA
    contract_version = CONTRACT_VERSION
    canonicalization_version = CANONICALIZATION_VERSION
    runtime_version = RUNTIME_VERSION

    def __init__(
        self,
        *,
        qwen_executor: Any | None = None,
        codex_executor: Any | None = None,
        validator: ContractSchemaValidator | None = None,
    ) -> None:
        self.validator = validator or ContractSchemaValidator()
        self.executors = {
            "qwen": qwen_executor or QwenStub(),
            "codex": codex_executor or CodexStub(),
        }
        self.idempotency_store: dict[tuple[str, str, str], dict[str, Any]] = {}
        self.last_trace: dict[str, Any] = {}
        self.last_restricted_forensic_evidence: dict[str, Any] | None = None

    def process(self, request: dict[str, Any]) -> dict[str, Any]:
        trace: dict[str, Any] = {
            "runtime_order": [],
            "contract_target_sha": CONTRACT_TARGET_SHA,
            "canonicalization_version": CANONICALIZATION_VERSION,
            "model_requests": 0,
            "external_side_effects": 0,
            "raw_answer": None,
            "final_answer": None,
        }
        self.last_trace = trace
        self.last_restricted_forensic_evidence = None
        validation = self.validator.validate("request-v1.schema.json", request)
        trace["runtime_order"].append("request_schema_validation")
        if not validation.valid:
            return self._error(request, "VALIDATION_ERROR", "validation", "validation")

        try:
            payload_hash = sha256(request["payload"])
        except CanonicalizationError:
            return self._error(request, "VALIDATION_ERROR", "validation", "transport")
        if payload_hash != request["request_payload_hash"]:
            return self._error(request, "VALIDATION_ERROR", "validation", "transport")

        idem = (
            request["payload"]["conversation_thread_id"],
            request["payload"]["message_id"],
            request["idempotency_key"],
        )
        cached = self.idempotency_store.get(idem)
        if cached:
            if cached["request_payload_hash"] != payload_hash:
                return self._error(request, "IDEMPOTENCY_CONFLICT", "idempotency", "transport")
            trace["idempotent_cache_hit"] = True
            trace["runtime_order"] = list(cached["runtime_order"])
            self.last_restricted_forensic_evidence = copy.deepcopy(
                cached.get("restricted_forensic_evidence")
            )
            return copy.deepcopy(cached["response"])

        try:
            response = self._run(request, trace)
        except StubExecutorError as error:
            return self._error(
                request,
                "EXECUTOR_TIMEOUT" if error.status == "timeout" else "EXECUTOR_UNAVAILABLE",
                "executor",
                "executor",
            )
        except (KeyError, TypeError, ValueError):
            return self._error(request, "INTERNAL_ERROR", "internal", "controller")

        response_validation = self.validator.validate("response-v1.schema.json", response)
        trace["runtime_order"].append("response_schema_validation")
        trace["response_schema_valid"] = response_validation.valid
        if not response_validation.valid:
            trace["response_schema_errors"] = list(response_validation.errors)
            return self._error(request, "INTERNAL_ERROR", "internal", "validation")
        self.idempotency_store[idem] = {
            "request_payload_hash": payload_hash,
            "response": copy.deepcopy(response),
            "runtime_order": list(trace["runtime_order"]),
            "restricted_forensic_evidence": copy.deepcopy(
                self.last_restricted_forensic_evidence
            ),
        }
        return response

    def _run(self, request: dict[str, Any], trace: dict[str, Any]) -> dict[str, Any]:
        payload = request["payload"]
        state = self._integrity_state(payload)
        state_before = copy.deepcopy(state.to_dict())
        semantic_history, history_trust = self._semantic_history(
            payload["recent_messages"]
        )
        trace["history_hygiene"] = {
            "items": history_trust,
            "trusted_count": sum(item["trusted_for_context"] for item in history_trust),
            "excluded_count": sum(not item["trusted_for_context"] for item in history_trust),
        }
        layer = ContextIntentIntegrityLayerV22()
        resolution = layer.process(
            conversation_id=payload["conversation_id"],
            message_id=payload["message_id"],
            raw_text=payload["current_message"],
            state=state,
            recent_messages=semantic_history,
            timestamp=payload["timestamp"],
        )
        trace["runtime_order"].extend((
            "current_turn_ingestion",
            "context_integrity",
            "command_relation_intent_resolution",
            "state_context_resolution",
        ))
        if not resolution.ingestion.ingested or resolution.ingestion.message_id != payload["message_id"]:
            raise ValueError("current_turn_not_ingested")

        effective_fact_records = self._effective_fact_records(payload, state)
        trace["ingestion_observability"] = {
            "resolved_intent": resolution.intent,
            "resolved_action": resolution.command_requirements.get("action_type"),
            "extracted_current_turn_facts": copy.deepcopy(resolution.extracted_facts),
            "request_local_effective_facts": {
                item["field"]: copy.deepcopy(item["value"])
                for item in effective_fact_records
            },
            "controller_input_facts": {
                item["field"]: copy.deepcopy(item["value"])
                for item in effective_fact_records
            },
            "engineering_lab_input_facts": None,
            "durable_confirmed_facts_before": {
                item["field"]: copy.deepcopy(item["value"])
                for item in payload["confirmed_project_facts"]
            },
        }
        controller_input = self._controller_input(
            payload, resolution, state_before, effective_fact_records,
            semantic_history,
        )
        controller_decision = SalesConversationController().decide(controller_input)
        controller_decision = layer.apply_to_decision(controller_decision, resolution)
        if (
            resolution.command_requirements.get("action_type")
            == CONVERSATIONAL_COURTESY_ACTION
        ):
            controller_decision = replace(
                controller_decision,
                next_best_action="answer_and_ask",
                answer_required=True,
                should_ask_question=True,
                question_goal="",
                should_offer_next_step=False,
                should_request_contact=False,
                should_use_loop=False,
            )
        trace["runtime_order"].append("sales_conversation_controller")

        engineering_required = (
            resolution.resolved_topic == "access_identifier_selection"
            or resolution.command_requirements.get("action_type") == "recommend_solution"
            and bool(re.search(r"номер|карт|билет|qr|rfid", payload["current_message"], re.I))
        )
        if engineering_required:
            facts = self._project_facts(effective_fact_records, state.conflicts)
            trace["ingestion_observability"]["engineering_lab_input_facts"] = copy.deepcopy(facts)
            decision_package = EngineeringDecisionEngine(schema_version="1.2").decide(
                facts,
                asked_questions=self._asked_question_texts(semantic_history),
            ).to_dict()
            if validate_decision_package(decision_package):
                raise ValueError("decision_package_schema_invalid")
            trace["engineering_decision_lab"] = copy.deepcopy(decision_package)
            trace["runtime_order"].extend(("engineering_decision_laboratory", "question_planner"))
        else:
            next_question = self._non_engineering_question(resolution)
            decision_package = {
                "schema_version": DECISION_PACKAGE_SCHEMA,
                "decision_type": "not_required",
                "next_question": next_question,
            }
            trace["runtime_order"].extend(("engineering_decision_laboratory", "question_planner"))
            trace["engineering_decision_laboratory"] = "not_invoked"
            validation = self.validator.validate_external(
                NON_ENGINEERING_DECISION_SCHEMA, decision_package,
            )
            if not validation.valid:
                raise ValueError("non_engineering_decision_package_schema_invalid")

        next_question = str(decision_package.get("next_question") or "").strip()
        if next_question and resolution.question_allowed:
            controller_decision = replace(
                controller_decision,
                next_best_action="answer_and_ask",
                should_ask_question=True,
                question_goal=next_question,
            )
        trace["controller_decision"] = controller_decision.to_dict()

        frozen_package = copy.deepcopy(decision_package)
        package_hash = sha256(frozen_package)
        trace["runtime_order"].append("decision_package_freeze_hash")
        trace["decision_package_hash"] = package_hash

        verbalization_projection = build_verbalization_projection(
            frozen_package,
            current_message=payload["current_message"],
            confirmed_project_facts=effective_fact_records,
            source_decision_package_hash=package_hash,
            canonicalization_version=CANONICALIZATION_VERSION,
        )
        projection_drift = projection_decision_drift(
            verbalization_projection,
            frozen_package,
            expected_source_decision_package_hash=package_hash,
            expected_canonicalization_version=CANONICALIZATION_VERSION,
        )
        if projection_drift:
            raise ValueError("verbalization_projection_decision_drift")
        trace["verbalization_projection"] = copy.deepcopy(verbalization_projection)
        trace["projection_decision_drift"] = list(projection_drift)
        model_prompt_contract = build_model_prompt_contract(verbalization_projection)
        trace["model_prompt_contract"] = copy.deepcopy(model_prompt_contract)

        policy = payload["executor_policy"]
        trace["runtime_order"].append("executor_selection")
        executor_context = {
            "current_message": payload["current_message"],
            "context_resolution": resolution.to_dict(),
            "controller_decision": controller_decision.to_dict(),
            "decision_package": copy.deepcopy(frozen_package),
            "confirmed_project_facts": copy.deepcopy(effective_fact_records),
            "fact_conflicts": copy.deepcopy(state.conflicts),
            "recent_messages": copy.deepcopy(semantic_history),
            "evidence_refs": copy.deepcopy(payload["consent_safe_context_refs"]),
            "state_version": payload["state_version"],
            "verbalization_projection": copy.deepcopy(verbalization_projection),
            "model_prompt_contract": copy.deepcopy(model_prompt_contract),
        }
        raw_answer, executor_trace = self._execute(policy, executor_context, package_hash, payload)
        trace["runtime_order"].append("executor_output")
        trace["raw_answer"] = raw_answer
        trace["executor_trace"] = copy.deepcopy(executor_trace)
        trace["raw_semantic_coverage"] = evaluate_semantic_coverage(
            raw_answer, frozen_package, user_message=payload["current_message"],
        ).to_dict()
        trace["raw_verbalization_fidelity"] = evaluate_verbalization_fidelity(
            raw_answer, frozen_package,
        ).to_dict()

        executor_package_hash = sha256(executor_context["decision_package"])
        if (
            frozen_package != decision_package
            or sha256(frozen_package) != package_hash
            or executor_package_hash != package_hash
        ):
            raise ValueError("decision_package_mutated")
        trace["decision_package_hashes"] = {
            "before_executor": package_hash,
            "after_executor": executor_package_hash,
        }

        post = AnswerPostProcessor().check(
            raw_answer,
            controller_decision,
            confirmed_claims=self._confirmed_claim_texts(effective_fact_records),
            asked_question_texts=self._asked_question_texts(semantic_history),
            user_message=payload["current_message"],
            allow_llm_repair=False,
            decision_package=frozen_package,
        )
        courtesy_turn = resolution.command_requirements.get("action_type") in {
            CONVERSATIONAL_COURTESY_ACTION,
            BUSINESS_OPENER_ACTION,
        }
        final_answer = self._enforce_next_question(
            post.answer,
            next_question,
            allow_optional_question=courtesy_turn,
        )
        rewrite_ratio = round(1 - SequenceMatcher(None, raw_answer, final_answer).ratio(), 6)
        trace["runtime_order"].append("response_repair")
        trace["final_answer"] = final_answer
        trace["final_semantic_coverage"] = evaluate_semantic_coverage(
            final_answer, frozen_package, user_message=payload["current_message"],
        ).to_dict()
        trace["final_verbalization_fidelity"] = evaluate_verbalization_fidelity(
            final_answer, frozen_package,
        ).to_dict()

        raw_integrity = layer.final_check(
            raw_answer, resolution, state, frozen_package if engineering_required else None,
        ).to_dict()
        final_integrity = layer.final_check(
            final_answer, resolution, state, frozen_package if engineering_required else None,
        ).to_dict()
        raw_status, raw_reasons = self._evaluation_status(
            raw_integrity, payload["current_message"], raw_answer,
            history_before=semantic_history,
            evidence_refs=payload["consent_safe_context_refs"],
            accepted_open_question_answer=self._open_question_answer_pass(resolution, raw_answer),
        )
        final_status, final_reasons = self._evaluation_status(
            final_integrity, payload["current_message"], final_answer,
            history_before=semantic_history,
            evidence_refs=payload["consent_safe_context_refs"],
            accepted_open_question_answer=self._open_question_answer_pass(resolution, final_answer),
        )
        final_reasons.update(post.remaining_flags)
        question_consistent = self._question_consistent(
            final_answer,
            next_question,
            allow_optional_question=courtesy_turn,
        )
        if not question_consistent:
            final_reasons.add("question_consistency_failed")
            final_status = "fail"
        if rewrite_ratio > REPAIR_REWRITE_REVIEW_THRESHOLD:
            final_reasons.add("repair_rewrite_ratio_exceeded")
            if final_status == "pass":
                final_status = "review_required"
        if final_status == "pass" and final_reasons & BLOCKING_EVALUATION_REASON_CODES:
            final_status = "fail"
        trace["runtime_order"].append("evaluation_integrity")
        trace["raw_evaluation"] = raw_integrity
        trace["final_evaluation"] = final_integrity

        trace["evaluator_context"] = {
            "history_before": copy.deepcopy(semantic_history),
            "evidence_refs": copy.deepcopy(payload["consent_safe_context_refs"]),
            "confirmed_fact_provenance": [
                {
                    "field": item["field"],
                    "source_message_id": item["source_message_id"],
                    "confirmed_at": item["confirmed_at"],
                }
                for item in effective_fact_records
            ],
            "active_question": copy.deepcopy(payload.get("active_question")),
        }

        mutations = self._state_mutations(
            payload, state_before, state, resolution, frozen_package,
            final_answer=final_answer,
            final_answer_hash=sha256(final_answer),
            question_consistent=question_consistent,
        )
        for mutation in mutations:
            if mutation["target"] != "thread_state" or mutation["field"].startswith("decision_package"):
                raise ValueError("decision_package_mutation_target")
            if not self.validator.validate("state-mutation-v1.schema.json", mutation).valid:
                raise ValueError("state_mutation_schema_invalid")
        after_repair_hash = sha256(frozen_package)
        after_mutations_hash = sha256(frozen_package)
        trace["decision_package_hashes"].update({
            "after_repair": after_repair_hash,
            "after_mutation_proposals": after_mutations_hash,
        })
        if len(set(trace["decision_package_hashes"].values())) != 1:
            raise ValueError("decision_package_mutated")
        state_after_version = payload["state_version"] + (1 if mutations else 0)
        trace["runtime_order"].append("state_mutation_proposals")
        trace["state_mutations"] = copy.deepcopy(mutations)
        trace["ingestion_observability"].update({
            "proposed_mutation_summary": [
                {
                    "operation": item["operation"],
                    "field": item["field"],
                    "source_message_id": item["source_message_id"],
                }
                for item in mutations
            ],
            "raw_evaluation_status": raw_status,
            "final_evaluation_status": final_status,
            "semantic_coverage": copy.deepcopy(trace["final_semantic_coverage"]),
            "projection_hash": model_prompt_contract["projection_hash"],
        })

        components = dict(COMPONENT_VERSIONS)
        if not engineering_required:
            components.update(
                engineering_lab="not_invoked",
                access_decision_ontology="not_invoked",
                question_planner="not_invoked",
            )
        attempt_latency = sum(item["latency_ms"] for item in executor_trace["attempts"])
        publication = "allowed" if final_status == "pass" else "owner_review" if final_status == "review_required" else "blocked"
        telemetry = {
            "trace_id": request["trace_context"]["trace_id"],
            "request_id": request["request_id"],
            "canonicalization_version": CANONICALIZATION_VERSION,
            "route": "ai_core",
            "component_versions": components,
            "latency": {"total_ms": attempt_latency + 7, "executor_ms": attempt_latency},
            "executor": {
                "planned": executor_trace["planned_executor"],
                "final": executor_trace["final_executor"],
                "attempt_count": len(executor_trace["attempts"]),
                "fallback_used": len(executor_trace["attempts"]) == 2,
                "cost_bucket": executor_trace["attempts"][-1]["cost_bucket"],
            },
            "repair": {
                "applied": post.repair_applied,
                "method": "deterministic" if post.repair_applied else "none",
                "rewrite_ratio": rewrite_ratio,
            },
            "evaluation": {"raw_status": raw_status, "final_status": final_status},
            "publication": {"candidate_status": publication, "published": False},
        }
        trace["runtime_observability"] = {
            "evaluation": {
                "status": final_status,
                "reason_codes": sorted(final_reasons),
            },
            "publication": {"candidate_status": publication},
            "repair": {
                "applied": post.repair_applied,
                "reason_codes": sorted(set((*post.flags, *post.remaining_flags))),
            },
            "semantic_coverage": copy.deepcopy(trace["final_semantic_coverage"]),
            "decision_package_hash": package_hash,
            "projection_hash": model_prompt_contract["projection_hash"],
            "executor": executor_trace["final_executor"],
            "executor_request_count": len(executor_trace["attempts"]),
            "canonicalization_version": CANONICALIZATION_VERSION,
        }
        raw_instruction_leaks = internal_instruction_leaks(raw_answer)
        final_instruction_leaks = internal_instruction_leaks(final_answer)
        trace["instruction_leak_detection"] = {
            "raw": {
                "detected": bool(raw_instruction_leaks),
                "matches": raw_instruction_leaks,
            },
            "final": {
                "detected": bool(final_instruction_leaks),
                "matches": final_instruction_leaks,
            },
            "reason_code": (
                "internal_instruction_leak"
                if raw_instruction_leaks or final_instruction_leaks else None
            ),
        }
        trace["projection_directive"] = {
            "question_instruction_present": bool(next_question),
            "next_question_present": bool(next_question),
        }
        if publication != "allowed":
            effective_facts = trace["ingestion_observability"][
                "request_local_effective_facts"
            ]
            self.last_restricted_forensic_evidence = build_blocked_turn_forensic(
                request_id=request["request_id"],
                resolution=resolution,
                effective_current_turn_facts=effective_facts,
                controller_decision=controller_decision.to_dict(),
                decision_package=frozen_package,
                decision_package_sha=package_hash,
                projection_sha=model_prompt_contract["projection_hash"],
                raw_semantic_coverage=trace["raw_semantic_coverage"],
                final_semantic_coverage=trace["final_semantic_coverage"],
                raw_answer=raw_answer,
                repaired_answer=final_answer,
                repair_applied=post.repair_applied,
                repair_method="deterministic" if post.repair_applied else "none",
                repair_reason_codes=(*post.flags, *post.remaining_flags),
                raw_evaluation_status=raw_status,
                raw_evaluation_reason_codes=raw_reasons,
                final_evaluation_status=final_status,
                final_evaluation_reason_codes=final_reasons,
                state_mutations=mutations,
                publication_candidate_status=publication,
                executor_name=executor_trace["final_executor"],
                executor_request_count=len(executor_trace["attempts"]),
            )
            trace["restricted_forensic_evidence"] = copy.deepcopy(
                self.last_restricted_forensic_evidence
            )
        return {
            "contract_version": CONTRACT_VERSION,
            "canonicalization_version": CANONICALIZATION_VERSION,
            "success": True,
            "request_id": request["request_id"],
            "response_id": f"response:{sha256(request['request_id'])[:16]}",
            "idempotency_key": request["idempotency_key"],
            "request_payload_hash": request["request_payload_hash"],
            "state_version_before": payload["state_version"],
            "state_version_after": state_after_version,
            "context_resolution": resolution.to_dict(),
            "controller_decision": controller_decision.to_dict(),
            "decision_package_schema": DECISION_PACKAGE_SCHEMA,
            "decision_package": frozen_package,
            "decision_package_hash": package_hash,
            "executor_trace": executor_trace,
            "raw_answer_reference": f"rawref:{sha256(request['request_id'] + raw_answer)[:16]}",
            "answer": final_answer,
            "repair_result": {
                "applied": post.repair_applied,
                "method": "deterministic" if post.repair_applied else "none",
                "rewrite_ratio": rewrite_ratio,
                "decision_package_hash": package_hash,
            },
            "evaluation_result": {
                "evaluated_candidate": "final_visible_candidate",
                "status": final_status,
                "reason_codes": sorted(final_reasons),
            },
            "state_mutations": mutations,
            "next_question": frozen_package.get("next_question"),
            "component_versions": components,
            "telemetry": telemetry,
        }

    def _execute(
        self, policy: dict[str, Any], context: dict[str, Any], package_hash: str,
        payload: dict[str, Any],
    ) -> tuple[str, dict[str, Any]]:
        planned = policy["planned_executor"]
        attempts: list[dict[str, Any]] = []
        final_executor: str | None = None
        answer: str | None = None
        fallback_reason = "none"
        base_time = self._parse_time(payload["timestamp"])
        for index, executor_name in enumerate(policy["fallback_order"], start=1):
            if index > 1 and (planned != "codex" or policy["max_model_fallbacks"] != 1):
                raise ValueError("fallback_limit_exceeded")
            started = base_time + timedelta(milliseconds=sum(item["latency_ms"] for item in attempts))
            try:
                output = self.executors[executor_name].execute(context)
                status, safe_error = "success", None
                latency, cost = output.latency_ms, output.cost_bucket
                answer, final_executor = output.answer, executor_name
            except StubExecutorError as error:
                status, safe_error = error.status, error.safe_error_code
                latency = policy["attempt_timeout_ms"] if isinstance(error, StubExecutorTimeout) else 1
                cost = "external_low" if executor_name == "codex" else "local_low"
                if index == 1:
                    fallback_reason = "timeout" if isinstance(error, StubExecutorTimeout) else "unavailable"
            finished = started + timedelta(milliseconds=latency)
            attempts.append({
                "attempt_index": index,
                "executor": executor_name,
                "started_at": self._format_time(started),
                "finished_at": self._format_time(finished),
                "status": status,
                "safe_error_code": safe_error,
                "latency_ms": latency,
                "cost_bucket": cost,
                "decision_package_hash": package_hash,
                "state_version": payload["state_version"],
            })
            if status == "success":
                break
        if answer is None or final_executor is None:
            raise StubExecutorUnavailable("all_stub_executors_failed")
        return answer, {
            "planned_executor": planned,
            "attempts": attempts,
            "final_executor": final_executor,
            "fallback_reason": fallback_reason,
            "decision_package_hash": package_hash,
            "state_version": payload["state_version"],
        }

    @staticmethod
    def _integrity_state(payload: dict[str, Any]) -> IntegrityState:
        confirmed = {
            item["field"]: {
                "value": copy.deepcopy(item["value"]),
                "source_message_id": item["source_message_id"],
                "confirmed_at": item["confirmed_at"],
                "version": item["version"],
                "conflict_state": item["conflict_state"],
            }
            for item in payload["confirmed_project_facts"]
        }
        open_questions = []
        active = payload.get("active_question")
        if active:
            fields = active["expected_fields"]
            first = fields[0]
            expected_type = "count" if first in {"entrances_count", "exits_count"} else "object_type" if first == "object_type" else "free_text"
            open_questions.append({
                "question_id": active["question_id"],
                "question_goal": active["goal"],
                "question_text": active["goal"].replace("_", " "),
                "expected_answer_type": expected_type,
                "allowed_values": [],
                "asked_at_message_id": active["asked_at_message_id"],
                "status": "active",
                "answer_message_id": None,
                "closed_reason": None,
            })
        return IntegrityState(
            confirmed_facts=confirmed,
            candidate_facts=copy.deepcopy(payload["candidate_facts"]),
            open_questions=open_questions,
            conflicts=copy.deepcopy(payload["fact_conflicts"]),
            ingested_message_ids=[item["message_id"] for item in payload["recent_messages"] if item["role"] == "user"],
        )

    @staticmethod
    def _controller_input(
        payload: dict[str, Any], resolution: Any, state_before: dict[str, Any],
        effective_fact_records: list[dict[str, Any]],
        semantic_history: list[dict[str, Any]],
    ) -> ControllerInput:
        facts = {item["field"]: item["value"] for item in effective_fact_records}
        lead_fields = set(LeadCard.__dataclass_fields__)
        lead_values = {key: value for key, value in facts.items() if key in lead_fields}
        lead_values.update(conversation_id=payload["conversation_id"], channel=payload["channel"])
        asked = [payload["active_question"]["goal"]] if payload.get("active_question") else []
        return ControllerInput(
            user_message=payload["current_message"],
            conversation_id=payload["conversation_id"],
            channel=payload["channel"],
            recent_messages=copy.deepcopy(semantic_history),
            lead_card=LeadCard(**lead_values),
            asked_questions=asked,
            known_facts=facts,
            current_stage=str(state_before.get("last_topic") or "initial"),
            ready_for_next_step=len(facts) >= 4,
        )

    @staticmethod
    def _project_facts(
        effective_fact_records: list[dict[str, Any]],
        conflicts: list[dict[str, Any]],
    ) -> dict[str, Any]:
        aliases = {
            "mandatory_automated_fallback": "mandatory_fallback",
            "current_system": "existing_system",
        }
        result: dict[str, Any] = {}
        for item in effective_fact_records:
            field = aliases.get(item["field"], item["field"])
            if field in ALLOWED_FACT_FIELDS:
                result[field] = copy.deepcopy(item["value"])
        if conflicts:
            result["conflicts"] = {
                str(item.get("field") or "unknown"): copy.deepcopy(item)
                for item in conflicts
            }
        return result

    @staticmethod
    def _effective_fact_records(
        payload: dict[str, Any], state: IntegrityState,
    ) -> list[dict[str, Any]]:
        durable_by_field = {
            item["field"]: item for item in payload["confirmed_project_facts"]
        }
        records: list[dict[str, Any]] = []
        for field, record in state.confirmed_facts.items():
            durable = durable_by_field.get(field)
            records.append({
                "fact_id": (
                    durable["fact_id"] if durable
                    else f"fact_{sha256(payload['message_id'] + field)[:16]}"
                ),
                "field": field,
                "value": copy.deepcopy(record.get("value")),
                "source_message_id": str(
                    record.get("source_message_id") or payload["message_id"]
                ),
                "confirmed_at": str(
                    record.get("confirmed_at") or payload["timestamp"]
                ),
                "version": int(record.get("version") or payload["state_version"] + 1),
                "conflict_state": str(record.get("conflict_state") or "none"),
            })
        return records

    @staticmethod
    def _asked_question_texts(history: list[dict[str, Any]]) -> list[str]:
        return [
            item["content"]
            for item in history
            if item["role"] == "assistant" and "?" in item["content"]
        ]

    @staticmethod
    def _semantic_history(
        history: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        trusted: list[dict[str, Any]] = []
        statuses: list[dict[str, Any]] = []
        for item in history:
            leaks = (
                internal_instruction_leaks(str(item.get("content") or ""))
                if item.get("role") == "assistant" else []
            )
            is_trusted = not leaks
            statuses.append({
                "message_id": str(item.get("message_id") or "unknown"),
                "role": str(item.get("role") or "unknown"),
                "trusted_for_context": is_trusted,
                "reason_code": None if is_trusted else "internal_instruction_leak",
            })
            if is_trusted:
                trusted.append(copy.deepcopy(item))
        return trusted, statuses

    @staticmethod
    def _confirmed_claim_texts(fact_records: list[dict[str, Any]]) -> list[str]:
        return [f"{item['field']}: {item['value']}" for item in fact_records]

    @staticmethod
    def _non_engineering_question(resolution: Any) -> str | None:
        if resolution.command_requirements.get("action_type") == "ask_one_question":
            return "Какой тип объекта планируется автоматизировать?"
        return None

    @staticmethod
    def _evaluation_status(
        integrity: dict[str, Any], message: str, answer: str, *,
        history_before: list[dict[str, Any]], evidence_refs: list[str],
        accepted_open_question_answer: bool = False,
    ) -> tuple[str, set[str]]:
        status = integrity.get("evaluation_status")
        mapped = "not_evaluable" if status == "insufficient_evidence" else status
        business_result = evaluate_business_status_v222(
            integrity,
            customer_message=message,
            final_answer=answer,
            history_before=history_before,
            evidence_refs=evidence_refs,
        )
        rank = {"pass": 0, "review_required": 1, "not_evaluable": 2, "fail": 3}
        reasons = set(integrity.get("violations") or ())
        reasons.update(integrity.get("v22_reason_codes") or ())
        reasons.update(business_result.reason_codes)
        action = str(integrity.get("action_type") or "")
        runtime_reconciled_actions = {
            "conversation_summary", "recall_facts", "memory_conflict_resolution",
            "provide_source", "provide_link",
        }
        assessments = {
            name: integrity.get(f"{name}_assessment") or {}
            for name in integrity.get("required_assessments") or ()
        }
        if (
            action in runtime_reconciled_actions
            and assessments
            and all(item.get("result") == "pass" for item in assessments.values())
        ):
            false_negative_codes = {
                "command_assessment_failed", "context_assessment_failed",
                "topic_assessment_failed", "source_assessment_failed",
                "link_assessment_failed", "confirmed_facts_missing",
                "recommendation_missing", "recommendation_basis_missing",
                "conditionality_not_handled", "current_command_not_fulfilled",
            }
            reasons.difference_update(false_negative_codes)
            mapped = "pass"
            business_result = evaluate_business_status_v222(
                {**integrity, "evaluation_status": "pass", "violations": []},
                customer_message=message,
                final_answer=answer,
                history_before=history_before,
                evidence_refs=evidence_refs,
            )
        if accepted_open_question_answer:
            false_negative_codes = {
                "command_assessment_failed", "command_not_fulfilled",
                "saved_facts_not_confirmed_to_client", "current_command_not_fulfilled",
                "context_assessment_failed", "current_turn_ignored",
            }
            reasons.difference_update(false_negative_codes)
            return "pass", reasons
        return max((mapped, business_result.status), key=lambda value: rank.get(str(value), 3)), reasons

    @staticmethod
    def _open_question_answer_pass(resolution: Any, answer: str) -> bool:
        if resolution.relation != "answer_to_previous_question":
            return False
        facts = resolution.extracted_facts or {}
        clean = " ".join(answer.casefold().split())
        if "current_system" in facts:
            value = str(facts["current_system"]).casefold()
            if value in {"установлена", "installed", "existing"}:
                return "систем" in clean and "установ" in clean
        return bool(facts) and bool(re.search(r"\b(?:понял|уч[её]л|зафиксировал|принял)\b", clean))

    @staticmethod
    def _state_mutations(
        payload: dict[str, Any], state_before: dict[str, Any], state: IntegrityState,
        resolution: Any, decision_package: dict[str, Any], *, final_answer: str,
        final_answer_hash: str, question_consistent: bool,
    ) -> list[dict[str, Any]]:
        mutations: list[dict[str, Any]] = []
        before_facts = state_before.get("confirmed_facts") or {}
        for field, record in state.confirmed_facts.items():
            if field in before_facts and before_facts[field].get("value") == record.get("value"):
                continue
            mutations.append({
                "mutation_id": f"mutation:{sha256(payload['message_id'] + field)[:16]}",
                "target": "thread_state",
                "operation": "set_confirmed_fact",
                "field": field,
                "value": copy.deepcopy(record.get("value")),
                "expected_state_version": payload["state_version"],
                "proposed_state_version": payload["state_version"] + 1,
                "source_message_id": payload["message_id"],
                "provenance": {
                    "source_type": "user_message",
                    "source_ref": payload["message_id"],
                    "confirmation_status": "confirmed",
                },
                "conflict_policy": "record_conflict",
            })
        existing_conflicts = {
            (item.get("field"), item.get("candidate_id"), item.get("status"))
            for item in state_before.get("conflicts") or []
        }
        for conflict in state.conflicts:
            identity = (conflict.get("field"), conflict.get("candidate_id"), conflict.get("status"))
            if identity in existing_conflicts:
                continue
            field = str(conflict.get("field") or "fact_conflict")
            mutations.append({
                "mutation_id": f"mutation:{sha256(payload['message_id'] + field + 'conflict')[:16]}",
                "target": "thread_state",
                "operation": "record_conflict",
                "field": field,
                "value": copy.deepcopy(conflict),
                "expected_state_version": payload["state_version"],
                "proposed_state_version": payload["state_version"] + 1,
                "source_message_id": payload["message_id"],
                "provenance": {
                    "source_type": "user_message",
                    "source_ref": payload["message_id"],
                    "confirmation_status": "not_applicable",
                },
                "conflict_policy": "record_conflict",
            })
        if question_consistent and decision_package.get("next_question"):
            expected_question = str(decision_package["next_question"]).strip()
            mutations.append({
                "mutation_id": f"mutation:{sha256(payload['message_id'] + 'question')[:16]}",
                "target": "thread_state",
                "operation": "add_asked_question",
                "field": "asked_questions",
                "value": {
                    "question_text": expected_question,
                    "question_goal": expected_question,
                    "expected_fields": OfflineRuntimeAdapterV1._expected_question_fields(expected_question),
                    "final_answer_hash": final_answer_hash,
                },
                "expected_state_version": payload["state_version"],
                "proposed_state_version": payload["state_version"] + 1,
                "source_message_id": payload["message_id"],
                "provenance": {
                    "source_type": "derived_state",
                    "source_ref": payload["message_id"],
                    "confirmation_status": "not_applicable",
                },
                "conflict_policy": "reject_on_conflict",
            })
        return mutations

    @staticmethod
    def _expected_question_fields(question: str) -> list[str]:
        clean = question.casefold()
        if "установлен" in clean or "с нуля" in clean:
            return ["current_system"]
        if "тип объекта" in clean:
            return ["object_type"]
        return ["clarification"]

    @staticmethod
    def _question_consistent(
        answer: str,
        expected_question: str,
        *,
        allow_optional_question: bool = False,
    ) -> bool:
        questions = [item.strip() for item in re.findall(r"[^.!?]*\?", answer) if item.strip()]
        if not expected_question:
            return len(questions) <= (1 if allow_optional_question else 0)
        normalize = lambda value: re.sub(r"\s+", " ", value.casefold().strip(" .?!"))
        return len(questions) == 1 and normalize(questions[0]) == normalize(expected_question)

    @staticmethod
    def _enforce_next_question(
        answer: str,
        expected_question: str,
        *,
        allow_optional_question: bool = False,
    ) -> str:
        parts = [part.strip() for part in re.split(r"(?<=[.!?])\s+", answer) if part.strip()]
        body = " ".join(part for part in parts if "?" not in part).strip()
        if not expected_question:
            if allow_optional_question:
                return " ".join(str(answer or "").split())
            return body
        return f"{body} {expected_question}".strip()

    def _error(self, request: dict[str, Any], code: str, category: str, stage: str) -> dict[str, Any]:
        raw_request_id = request.get("request_id")
        request_id = raw_request_id if isinstance(raw_request_id, str) and re.fullmatch(r"[a-zA-Z0-9_-]{8,128}", raw_request_id) else None
        raw_trace_id = ((request.get("trace_context") or {}).get("trace_id") if isinstance(request.get("trace_context"), dict) else None)
        trace_id = raw_trace_id if isinstance(raw_trace_id, str) and re.fullmatch(r"[a-zA-Z0-9:_-]{1,160}", raw_trace_id) else None
        envelope = {
            "contract_version": CONTRACT_VERSION,
            "canonicalization_version": CANONICALIZATION_VERSION,
            "success": False,
            "request_id": request_id,
            "error": {
                "code": code,
                "category": category,
                "retryable": code in {"EXECUTOR_TIMEOUT", "EXECUTOR_UNAVAILABLE"},
                "safe_message_code": code,
                "stage": stage,
            },
            "trace_id": trace_id,
        }
        validation = self.validator.validate("error-envelope-v1.schema.json", envelope)
        if not validation.valid:
            raise RuntimeError("safe_error_envelope_invalid")
        self.last_trace["safe_error"] = copy.deepcopy(envelope)
        return envelope

    @staticmethod
    def _parse_time(value: str) -> datetime:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)

    @staticmethod
    def _format_time(value: datetime) -> str:
        return value.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def apply_mutation_ack(
    next_request: dict[str, Any], previous_response: dict[str, Any], acknowledgement: dict[str, Any],
    *, validator: ContractSchemaValidator | None = None,
) -> dict[str, Any]:
    """Применяет только подтверждённые Site mutations к следующему офлайн-запросу."""
    return apply_mutation_ack_v11(
        next_request, previous_response, acknowledgement, validator=validator,
    )["next_request"]


def apply_mutation_ack_v11(
    next_request: dict[str, Any], previous_response: dict[str, Any], acknowledgement: dict[str, Any],
    *, validator: ContractSchemaValidator | None = None,
    publication_confirmed: bool = False,
    applied_mutation_ids: set[str] | None = None,
) -> dict[str, Any]:
    """Атомарно применяет подтверждения Site и возвращает исход каждого предложения."""
    schema_validator = validator or ContractSchemaValidator()
    if not schema_validator.validate("mutation-ack-v1.schema.json", acknowledgement).valid:
        raise ValueError("mutation_ack_schema_invalid")
    result = copy.deepcopy(next_request)
    seen_applied = set(applied_mutation_ids or ())
    proposals = {
        item["mutation_id"]: item for item in previous_response.get("state_mutations") or []
    }
    facts = {item["field"]: item for item in result["payload"]["confirmed_project_facts"]}
    conflicts = {
        str(item.get("conflict_id")): item for item in result["payload"]["fact_conflicts"]
    }
    base_version = result["payload"]["state_version"]
    resulting_version = base_version
    outcomes: list[dict[str, Any]] = []
    for acknowledgement_item in acknowledgement["acknowledgements"]:
        mutation_id = acknowledgement_item["mutation_id"]
        mutation = proposals.get(mutation_id)
        status = "rejected"
        reason = acknowledgement_item["reason_code"]
        if acknowledgement_item["status"] != "applied":
            outcomes.append({
                "mutation_id": mutation_id, "status": status, "reason": reason,
                "expected_state_version": base_version,
                "resulting_state_version": resulting_version,
            })
            continue
        if not mutation:
            reason = "proposal_not_found"
        elif mutation_id in seen_applied:
            status, reason = "applied", "idempotent_replay"
        elif mutation["expected_state_version"] != base_version:
            reason = "version_conflict"
        elif mutation["target"] != "thread_state" or mutation["field"].startswith("decision_package"):
            reason = "decision_package_immutable"
        elif mutation["operation"] == "add_asked_question" and not publication_confirmed:
            reason = "publication_not_confirmed"
        else:
            status, reason = "applied", "applied"
        if mutation is None:
            outcomes.append({
                "mutation_id": mutation_id, "status": status, "reason": reason,
                "expected_state_version": base_version,
                "resulting_state_version": resulting_version,
            })
            continue
        if mutation["operation"] == "set_confirmed_fact":
            if status == "applied" and reason != "idempotent_replay":
                facts[mutation["field"]] = {
                    "fact_id": f"fact_{sha256(mutation_id)[:16]}",
                    "field": mutation["field"],
                    "value": copy.deepcopy(mutation["value"]),
                    "source_message_id": mutation["source_message_id"],
                    "confirmed_at": acknowledgement["acknowledged_at"],
                    "version": max(1, mutation["proposed_state_version"]),
                    "conflict_state": "none",
                }
        elif mutation["operation"] == "record_conflict" and status == "applied":
            conflict_id = f"conflict_{sha256(mutation_id)[:16]}"
            if conflict_id not in conflicts:
                existing = next(
                    (item for item in facts.values() if item["field"] == mutation["field"]), None,
                )
                conflicts[conflict_id] = {
                    "conflict_id": conflict_id,
                    "field": mutation["field"],
                    "existing_fact_id": existing["fact_id"] if existing else f"fact_{sha256(mutation['field'])[:16]}",
                    "candidate_id": f"candidate_{sha256(mutation_id)[:16]}",
                    "status": "open",
                }
        elif mutation["operation"] == "add_asked_question" and status == "applied":
            value = mutation["value"]
            result["payload"]["active_question"] = {
                "question_id": f"question_{sha256(mutation_id)[:16]}",
                "goal": value["question_goal"],
                "expected_fields": copy.deepcopy(value["expected_fields"]),
                "asked_at_message_id": mutation["source_message_id"],
            }
        if status == "applied":
            seen_applied.add(mutation_id)
            resulting_version = max(resulting_version, mutation["proposed_state_version"])
        outcomes.append({
            "mutation_id": mutation_id, "status": status, "reason": reason,
            "expected_state_version": mutation["expected_state_version"] if mutation else base_version,
            "resulting_state_version": resulting_version,
        })
    result["payload"]["confirmed_project_facts"] = list(facts.values())
    result["payload"]["fact_conflicts"] = list(conflicts.values())
    result["payload"]["state_version"] = resulting_version
    result["request_payload_hash"] = sha256(result["payload"])
    return {
        "next_request": result,
        "outcomes": outcomes,
        "resulting_state_version": resulting_version,
        "applied_mutation_ids": sorted(seen_applied),
    }
