from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .enums import ConversationMode, NextBestAction, SalesComponent


@dataclass
class LeadCard:
    lead_id: str = ""
    conversation_id: str = ""
    channel: str = "website"
    company: str | None = None
    person_name: str | None = None
    person_role: str | None = None
    object_type: str | None = None
    location: str | None = None
    entrances_count: int | None = None
    exits_count: int | None = None
    current_system: str | None = None
    current_problem: list[str] = field(default_factory=list)
    desired_outcome: list[str] = field(default_factory=list)
    required_features: list[str] = field(default_factory=list)
    integrations: list[str] = field(default_factory=list)
    decision_makers: list[str] = field(default_factory=list)
    project_stage: str | None = None
    timeline: str | None = None
    budget_status: str = "unknown"
    competitors: list[str] = field(default_factory=list)
    objections: list[str] = field(default_factory=list)
    interest_level: str = "unknown"
    trust_level: str = "unknown"
    next_step: str | None = None
    contact_permission: bool = False
    facts_source_messages: dict[str, str] = field(default_factory=dict)
    inference_confidence: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ControllerInput:
    user_message: str
    conversation_id: str = ""
    channel: str = "website"
    recent_messages: list[dict[str, str]] = field(default_factory=list)
    conversation_summary: str = ""
    lead_card: LeadCard = field(default_factory=LeadCard)
    asked_questions: list[str] = field(default_factory=list)
    known_facts: dict[str, Any] = field(default_factory=dict)
    relevant_knowledge: list[dict[str, Any]] = field(default_factory=list)
    current_stage: str = "initial"
    loop_count: int = 0
    irritation_detected: bool = False
    ready_for_next_step: bool = False


@dataclass(frozen=True)
class ControllerDecision:
    conversation_mode: str
    customer_intent: str
    current_stage: str
    next_best_action: str
    answer_required: bool
    answer_priority: str
    should_ask_question: bool
    question_goal: str
    should_offer_next_step: bool
    should_request_contact: bool
    should_use_straight_line: bool
    straight_line_component: str
    should_use_loop: bool
    loop_count: int
    pressure_risk: str
    executor_preference: str
    required_knowledge: tuple[str, ...]
    forbidden_actions: tuple[str, ...]
    stage_after: str

    def __post_init__(self) -> None:
        ConversationMode(self.conversation_mode)
        NextBestAction(self.next_best_action)
        if self.straight_line_component:
            SalesComponent(self.straight_line_component)
        if self.loop_count < 0 or self.loop_count > 2:
            raise ValueError("loop_count_out_of_range")
        if self.should_use_loop and not self.should_use_straight_line:
            raise ValueError("loop_requires_straight_line")
        if self.should_request_contact and not self.should_offer_next_step:
            raise ValueError("contact_requires_value")

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["required_knowledge"] = list(self.required_knowledge)
        payload["forbidden_actions"] = list(self.forbidden_actions)
        return payload
