"""Модель-независимый управляющий слой диалогов продаж РОСПАРК."""

from .contracts import ControllerDecision, ControllerInput, LeadCard
from .controller import SalesConversationController

__all__ = [
    "ControllerDecision",
    "ControllerInput",
    "LeadCard",
    "SalesConversationController",
]
