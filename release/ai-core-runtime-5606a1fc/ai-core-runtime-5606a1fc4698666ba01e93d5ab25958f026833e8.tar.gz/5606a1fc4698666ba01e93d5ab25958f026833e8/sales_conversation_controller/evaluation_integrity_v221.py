from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Iterable


BUSINESS_STATUSES = ("pass", "review_required", "fail", "not_evaluable")
RATING_TO_STATUS = {
    "good": "pass", "controversial": "review_required",
    "bad": "fail", "not_evaluable": "not_evaluable",
}
REVIEW_REASON_CODES = {
    "summary_does_not_cover_conversation",
    "corporate_practice_not_verified",
    "corporate_practice_contradicted",
}


COMPARATIVE_TERMS_RE = re.compile(
    r"\b(?:дешевле|дороже|быстрее|медленнее|над[её]жнее|долговечнее|"
    r"выгоднее|удобнее|одинаков(?:о|ы)|лучше|хуже)\b",
    re.I,
)


def normalize_content(value: Any) -> Any:
    if isinstance(value, str):
        return " ".join(value.casefold().split())
    if isinstance(value, list):
        return [normalize_content(item) for item in value]
    if isinstance(value, dict):
        return {key: normalize_content(value[key]) for key in sorted(value)}
    return value


def content_similarity_hash(history: list[dict[str, Any]], message: str, final_answer: str) -> str:
    payload = {"history": history, "message": message, "final_answer": final_answer}
    raw = json.dumps(normalize_content(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def manual_business_status(rating: str | None) -> str | None:
    return RATING_TO_STATUS.get(str(rating or ""))


def automatic_business_status(final_v22: dict[str, Any]) -> str:
    if not final_v22.get("context_complete", True):
        return "not_evaluable"
    evaluation = final_v22.get("evaluation_status")
    reasons = set(final_v22.get("v22_reason_codes") or [])
    if evaluation == "pass":
        return "pass"
    if reasons & REVIEW_REASON_CODES or evaluation == "insufficient_evidence":
        return "review_required"
    return "fail"


def repair_business_effect(raw_rating: str | None, final_rating: str | None, applied: bool) -> str:
    if not applied or not raw_rating or not final_rating:
        return "not_applied"
    if raw_rating == final_rating:
        return "unchanged"
    order = {"bad": 0, "controversial": 1, "good": 2}
    if raw_rating not in order or final_rating not in order:
        return "unchanged"
    return "improved" if order[final_rating] > order[raw_rating] else "degraded"


def ratio(numerator: float, denominator: float) -> float | None:
    return numerator / denominator if denominator else None


def classification_metrics(rows: Iterable[dict[str, Any]], *, weighted: bool = False) -> dict[str, Any]:
    usable = [row for row in rows if row.get("manual_business_status") in BUSINESS_STATUSES]

    def weight(row: dict[str, Any]) -> float:
        return float(row.get("independent_calibration_weight", 1)) if weighted else 1.0

    def metric(status: str) -> tuple[float | None, float | None, float, float]:
        predicted = sum(weight(row) for row in usable if row["automatic_business_status"] == status)
        actual = sum(weight(row) for row in usable if row["manual_business_status"] == status)
        correct = sum(weight(row) for row in usable if row["automatic_business_status"] == status == row["manual_business_status"])
        return ratio(correct, predicted), ratio(correct, actual), predicted, actual

    publish_precision, publish_recall, publish_predicted, publish_actual = metric("pass")
    fail_precision, fail_recall, fail_predicted, fail_actual = metric("fail")
    review_precision, review_recall, review_predicted, review_actual = metric("review_required")
    ne_precision, ne_recall, ne_predicted, ne_actual = metric("not_evaluable")
    non_good_actual = sum(weight(row) for row in usable if row["manual_business_status"] in {"review_required", "fail"})
    non_good_detected = sum(
        weight(row) for row in usable
        if row["manual_business_status"] in {"review_required", "fail"}
        and row["automatic_business_status"] in {"review_required", "fail"}
    )
    return {
        "evaluated_weight": sum(weight(row) for row in usable),
        "publish_gate_precision": publish_precision,
        "publish_gate_recall": publish_recall,
        "publish_gate_predicted_weight": publish_predicted,
        "publish_gate_actual_weight": publish_actual,
        "hard_fail_precision": fail_precision,
        "hard_fail_recall": fail_recall,
        "hard_fail_predicted_weight": fail_predicted,
        "hard_fail_actual_weight": fail_actual,
        "review_required_precision": review_precision,
        "review_required_recall": review_recall,
        "review_required_predicted_weight": review_predicted,
        "review_required_actual_weight": review_actual,
        "non_good_detection_recall": ratio(non_good_detected, non_good_actual),
        "not_evaluable_accuracy": ne_recall,
        "not_evaluable_precision": ne_precision,
        "not_evaluable_predicted_weight": ne_predicted,
        "not_evaluable_actual_weight": ne_actual,
    }


@dataclass(frozen=True)
class DeduplicationResult:
    scenario_group_id: str
    duplicate_of_case_id: str | None
    content_similarity_hash: str
    independent_calibration_weight: int


def assign_scenario_groups(rows: list[dict[str, Any]]) -> dict[str, DeduplicationResult]:
    first_by_hash: dict[str, str] = {}
    groups: dict[str, DeduplicationResult] = {}
    for row in rows:
        digest = content_similarity_hash(row.get("history_before") or [], row["customer_message"], row["checked_answer_v21"])
        primary = first_by_hash.setdefault(digest, row["message_id"])
        groups[row["message_id"]] = DeduplicationResult(
            scenario_group_id=f"scenario-{digest[:16]}",
            duplicate_of_case_id=None if primary == row["message_id"] else primary,
            content_similarity_hash=digest,
            independent_calibration_weight=1 if primary == row["message_id"] else 0,
        )
    return groups
