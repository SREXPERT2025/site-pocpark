from __future__ import annotations

import re
from dataclasses import asdict, dataclass

from .verbalization_semantics import recommendation_present


CONVERSATIONAL_COURTESY_ACTION = "conversational_courtesy"
BUSINESS_OPENER_ACTION = "business_opener"

_TURN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("greeting", re.compile(
        r"(?:привет(?:ствую)?|здравств(?:уй|уйте)|доброе\s+утро|добрый\s+(?:день|вечер))",
        re.I,
    )),
    ("thanks", re.compile(r"(?:спасибо|благодарю|большое\s+спасибо)", re.I)),
    ("acknowledgement", re.compile(r"(?:понял(?:а)?|понятно|хорошо|ладно|принято)", re.I)),
    ("farewell", re.compile(r"(?:до\s+свидания|всего\s+доброго|до\s+встречи|пока)", re.I)),
    ("small_talk", re.compile(r"(?:как\s+дела|рад(?:а)?\s+вас\s+видеть|приятно\s+познакомиться)", re.I)),
)

_RESPONSE_PATTERNS = {
    "greeting": re.compile(r"\b(?:привет|здравств(?:уй|уйте)|доброе\s+утро|добрый\s+(?:день|вечер)|рад\w*\s+приветствовать)\b", re.I),
    "thanks": re.compile(r"\b(?:пожалуйста|рад\w*\s+помочь|обращайтесь|спасибо)\b", re.I),
    "acknowledgement": re.compile(r"\b(?:понял|принял|хорошо|обращайтесь|рад\w*\s+помочь)\b", re.I),
    "farewell": re.compile(r"\b(?:до\s+свидания|всего\s+доброго|до\s+встречи|хорошего\s+дня|обращайтесь|пока)\b", re.I),
    "small_talk": re.compile(r"\b(?:спасибо|хорошо|рад\w*|помочь|чем\s+могу)\b", re.I),
    "business_opener": re.compile(r"\b(?:парковк\w*|автоматизац\w*|автоматизир\w*|шлагбаум\w*)\b", re.I),
}

_ENGINEERING_TERM_RE = re.compile(
    r"\b(?:распознаван\w*\s+номер\w*|госномер\w*|rfid|qr|карт\w*|билет\w*|"
    r"шлагбаум|считывател\w*|контроллер\w*)\b",
    re.I,
)
_UNREQUESTED_ENGINEERING_FINALITY_RE = re.compile(
    r"\b(?:финальн\w+\s+инженерн\w+\s+решени\w*|"
    r"(?:решени\w*|архитектур\w*)\s+(?:по\s+категори\w+\s+)?"
    r"(?:уже\s+)?(?:принят\w*|зафиксирован\w*|утвержд[её]н\w*))\b",
    re.I,
)
_UNREQUESTED_ENGINEERING_POLICY_RE = re.compile(
    r"\b(?:оператор\w*.{0,100}(?:автоматическ\w+\s+резерв\w*|"
    r"ручн\w+\s+обработк\w+\s+исключительн\w+\s+ситуац\w*)|"
    r"(?:нов\w+\s+)?оборудован\w+.{0,80}(?:не\s+добавля\w*|не\s+требу\w*)|"
    r"неподтвержд[её]нн\w+\s+инфраструктур\w*|"
    r"резервн\w+\s+способ\w*.{0,80}не\s+рассматрива\w*)\b",
    re.I,
)
_UNSUPPORTED_PROJECT_FACT_RE = re.compile(
    r"\b(?:для\s+ваш\w+|на\s+ваш\w+|у\s+вас)\s+"
    r"(?:бизнес[- ]?центр|торгов\w+\s+центр|жил\w+\s+комплекс|склад|"
    r"\d+\s+(?:въезд|выезд|машин|автомобил))\w*",
    re.I,
)
_UNSUPPORTED_COMPANY_CLAIM_RE = re.compile(
    r"\b(?:в|для)\s+роспарк\b.{0,80}\b(?:чаще\s+всего|обычно|всегда|гарантированно|стандартно)\b",
    re.I,
)
_PRESSURE_RE = re.compile(
    r"\b(?:оставьте\s+контакт\s+прямо\s+сейчас|решайте\s+сейчас|"
    r"вам\s+обязательно\s+нужно|нужно\s+срочно|последний\s+шанс)\b",
    re.I,
)
_UNSAFE_RE = re.compile(
    r"\b(?:отключите\s+защит\w*|обойдите\s+систем\w+\s+безопасност|"
    r"замкните\s+контакт\w*)\b",
    re.I,
)


@dataclass(frozen=True)
class NonEngineeringEvaluation:
    turn_type: str
    current_turn_acknowledged: bool
    relevant: bool
    unsupported_claims: int
    contradiction_detected: bool
    unrequested_engineering_decisions: int
    unsafe_content: bool
    pressure_detected: bool
    question_count: int
    semantically_complete: bool
    status: str
    reason_codes: tuple[str, ...]

    def to_dict(self) -> dict:
        value = asdict(self)
        value["reason_codes"] = list(self.reason_codes)
        return value


def classify_conversational_courtesy(text: str) -> str | None:
    """Возвращает тип только для чистого conversational turn, не для mixed intent."""
    normalized = " ".join(str(text or "").casefold().replace("ё", "е").split())
    normalized = normalized.strip(" \t\r\n.!?,;:—-")
    for turn_type, pattern in _TURN_PATTERNS:
        if pattern.fullmatch(normalized):
            return turn_type
    return None


def classify_business_opener(text: str) -> bool:
    """Выделяет намерение начать проект, не перехватывая recommendation/engineering request."""
    normalized = " ".join(str(text or "").casefold().replace("ё", "е").split())
    if re.search(r"\b(?:что\s+лучше|что\s+выбрать|сравни|порекоменду|посоветуй)\w*", normalized):
        return False
    desire = bool(re.search(r"\b(?:хочу|нужно|планирую|интересует|хотим|нужна)\b", normalized))
    domain = bool(re.search(r"\b(?:автоматизир\w*|автоматизац\w*|парковк\w*|шлагбаум\w*)\b", normalized))
    return desire and domain


def assess_conversational_courtesy(
    answer: str,
    *,
    turn_type: str,
    contradiction_detected: bool = False,
) -> NonEngineeringEvaluation:
    clean = " ".join(str(answer or "").split())
    acknowledgement = bool(_RESPONSE_PATTERNS.get(turn_type, _RESPONSE_PATTERNS["small_talk"]).search(clean))
    question_count = len([item for item in re.findall(r"[^.!?]*\?", clean) if item.strip()])
    unsupported_claims = int(bool(_UNSUPPORTED_PROJECT_FACT_RE.search(clean))) + int(
        bool(_UNSUPPORTED_COMPANY_CLAIM_RE.search(clean))
    )
    explicit_engineering_recommendation = bool(
        _ENGINEERING_TERM_RE.search(clean) and recommendation_present(clean)
    )
    engineering_decisions = int(bool(
        explicit_engineering_recommendation
        or _UNREQUESTED_ENGINEERING_FINALITY_RE.search(clean)
        or _UNREQUESTED_ENGINEERING_POLICY_RE.search(clean)
    ))
    unsafe = bool(_UNSAFE_RE.search(clean))
    pressure = bool(_PRESSURE_RE.search(clean))
    complete = bool(clean) and acknowledgement
    reasons: list[str] = []
    if not acknowledgement:
        reasons.append("courtesy_turn_not_acknowledged")
    if unsupported_claims:
        reasons.append("unsupported_non_engineering_claim")
    if contradiction_detected:
        reasons.append("confirmed_context_contradicted")
    if engineering_decisions:
        reasons.append("unrequested_engineering_decision")
    if unsafe:
        reasons.append("unsafe_non_engineering_content")
    if pressure:
        reasons.append("courtesy_pressure_pattern")
    if question_count > 1:
        reasons.append("courtesy_question_limit_exceeded")
    if not complete and "courtesy_turn_not_acknowledged" not in reasons:
        reasons.append("courtesy_response_incomplete")
    relevant = acknowledgement and not engineering_decisions
    return NonEngineeringEvaluation(
        turn_type=turn_type,
        current_turn_acknowledged=acknowledgement,
        relevant=relevant,
        unsupported_claims=unsupported_claims,
        contradiction_detected=contradiction_detected,
        unrequested_engineering_decisions=engineering_decisions,
        unsafe_content=unsafe,
        pressure_detected=pressure,
        question_count=question_count,
        semantically_complete=complete,
        status="pass" if not reasons else "fail",
        reason_codes=tuple(reasons),
    )
