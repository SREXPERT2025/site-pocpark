from __future__ import annotations

from enum import StrEnum


class ConversationMode(StrEnum):
    CONSULTING = "consulting"
    DISCOVERY = "discovery"
    QUALIFICATION = "qualification"
    SOLUTION_SELECTION = "solution_selection"
    OBJECTION_HANDLING = "objection_handling"
    NEXT_STEP = "next_step"
    SUPPORT = "support"
    COMPLAINT = "complaint"
    NEUTRAL = "neutral"
    DISENGAGED = "disengaged"


class NextBestAction(StrEnum):
    ANSWER_ONLY = "answer_only"
    ANSWER_AND_ASK = "answer_and_ask"
    ASK_CLARIFYING_QUESTION = "ask_clarifying_question"
    CONFIRM_UNDERSTANDING = "confirm_understanding"
    PROVIDE_RECOMMENDATION = "provide_recommendation"
    COMPARE_OPTIONS = "compare_options"
    SHOW_RELEVANT_CASE = "show_relevant_case"
    HANDLE_OBJECTION = "handle_objection"
    SUMMARIZE_REQUIREMENTS = "summarize_requirements"
    OFFER_CALCULATION = "offer_calculation"
    OFFER_DEMO = "offer_demo"
    OFFER_HUMAN_CONTACT = "offer_human_contact"
    REQUEST_CONTACT = "request_contact"
    PREPARE_HANDOFF = "prepare_handoff"
    PAUSE_SALES_MOTION = "pause_sales_motion"
    END_CONVERSATION = "end_conversation"


class SalesComponent(StrEnum):
    NONE = ""
    DIRECT_ANSWER = "direct_answer"
    SOFT_DISCOVERY = "soft_discovery"
    RAPPORT = "rapport"
    QUALIFICATION = "qualification"
    VALUE_EXPLANATION = "value_explanation"
    OBJECTION_CLARIFICATION = "objection_clarification"
    LOOPING = "looping"
    NEXT_STEP = "next_step"
    CONTACT_TRANSITION = "contact_transition"
    DISENGAGEMENT = "disengagement"


class RuntimeMode(StrEnum):
    OFF = "off"
    SHADOW = "shadow"
    ASSIST_LOCAL = "assist_local"
    LOCAL_ONLY = "local_only"
    SAFE_LOCAL = "safe_local"
    CODEX_CANARY = "codex_canary"
    FULL_HYBRID = "full_hybrid"


class ExecutorName(StrEnum):
    CODEX = "codex"
    LOCAL_MODEL = "local_model"
    FAQ = "faq"
    SAFE_FALLBACK = "safe_fallback"


class CircuitState(StrEnum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class FailureReason(StrEnum):
    TIMEOUT = "timeout"
    AUTHORIZATION_FAILURE = "authorization_failure"
    INVALID_OUTPUT = "invalid_output"
    PROCESS_FAILURE = "process_failure"
    QUEUE_OVERFLOW = "queue_overflow"
    FACT_CHECK_FAILURE = "fact_check_failure"
    EMPTY_OUTPUT = "empty_output"
    LOCAL_MODEL_UNAVAILABLE = "local_model_unavailable"


class ExecutorReason(StrEnum):
    MODE_LOCAL_ONLY = "mode_local_only"
    MODE_ASSIST_LOCAL = "mode_assist_local"
    MODE_SAFE_LOCAL = "mode_safe_local"
    MODE_SHADOW_PRIMARY = "mode_shadow_primary"
    SIMPLE_FAQ = "simple_faq"
    SHORT_TECHNICAL = "short_technical"
    SALES_DIALOGUE_HIGH_VALUE = "sales_dialogue_high_value"
    LONG_CONTEXT = "long_context"
    STRAIGHT_LINE_REQUIRED = "straight_line_required"
    CODEX_DISABLED = "codex_disabled"
    CODEX_WORKER_UNAVAILABLE = "codex_worker_unavailable"
    CODEX_AUTH_INVALID = "codex_auth_invalid"
    CODEX_QUEUE_FULL = "codex_queue_full"
    CODEX_CONCURRENCY_LIMIT = "codex_concurrency_limit"
    CODEX_LATENCY_HIGH = "codex_latency_high"
    CIRCUIT_OPEN = "circuit_open"
    CANARY_NOT_SELECTED = "canary_not_selected"
    LOCAL_FALLBACK = "local_fallback"
    FAQ_FALLBACK = "faq_fallback"
    SAFE_FALLBACK = "safe_fallback"
