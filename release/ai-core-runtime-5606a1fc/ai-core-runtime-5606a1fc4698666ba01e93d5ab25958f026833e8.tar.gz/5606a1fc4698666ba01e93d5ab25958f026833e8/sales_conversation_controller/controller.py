from __future__ import annotations

import re

from .contracts import ControllerDecision, ControllerInput
from .enums import ConversationMode as Mode
from .enums import NextBestAction as Action
from .enums import SalesComponent as Component


SUPPORT_RE = re.compile(
    r"\b(не работает|сломал|ошибк|авари|не открыва|не закрыва|завис(?:ла|ло|ает|ают)|поддержк|ремонт)\w*",
    re.I,
)
COMPLAINT_RE = re.compile(r"\b(жалоб|возмущ|ужас|безобраз|недоволен|претензи)\w*", re.I)
IRRITATION_RE = re.compile(r"\b(хватит|достал|не давите|отстаньте|раздражает)\b", re.I)
DISENGAGED_RE = re.compile(
    r"\b(не интересно|не нужно|не хочу продолжать|не пишите|не звоните|до свидания)\b",
    re.I,
)
PRICE_RE = re.compile(r"\b(цен[аыуе]?|стоимост|сколько стоит|прайс|бюджет)\w*", re.I)
QUOTE_RE = re.compile(r"\b(коммерческ\w+ предложен|\bкп\b|расч[её]т|смет)\w*", re.I)
DEMO_RE = re.compile(r"\b(демо|демонстрац|показать систему|презентац)\w*", re.I)
COMPARE_RE = re.compile(r"\b(сравн|отлич|вместо|конкурент|аналог)\w*", re.I)
OBJECTION_RE = re.compile(
    r"\b(дорого|надо подумать|нет бюджета|сомнева|не уверен|у конкурента дешевле)\b",
    re.I,
)
CONTACT_RE = re.compile(
    r"\b(оставлю контакт|можете позвонить|свяжитесь|напишите в телеграм|готов оставить)\b",
    re.I,
)
TECH_RE = re.compile(
    r"\b(работает|поддерживает|интеграц|шлагбаум|распознаван|rfid|qr|оплат|контроллер|въезд|выезд)\w*",
    re.I,
)


class SalesConversationController:
    """Выбирает одну стратегическую микрозадачу, но не пишет ответ клиенту."""

    def decide(self, value: ControllerInput) -> ControllerDecision:
        message = " ".join(value.user_message.lower().split())
        loop_count = min(max(int(value.loop_count), 0), 2)
        irritated = value.irritation_detected or bool(IRRITATION_RE.search(message))
        explicit_stop = bool(DISENGAGED_RE.search(message))
        complaint = bool(COMPLAINT_RE.search(message))
        support = bool(SUPPORT_RE.search(message))

        base_forbidden = [
            "invent_exact_price",
            "promise_timeline",
            "invent_availability",
            "claim_unverified_compatibility",
            "offer_discount",
            "repeat_known_question",
            "ask_multiple_questions",
            "expose_executor",
        ]

        if explicit_stop or irritated:
            return self._decision(
                mode=Mode.DISENGAGED,
                intent="disengagement",
                stage=value.current_stage,
                action=Action.END_CONVERSATION,
                answer_required=True,
                component=Component.DISENGAGEMENT,
                pressure="high",
                loop_count=loop_count,
                forbidden=base_forbidden + ["request_contact", "continue_selling", "use_loop"],
                stage_after="closed",
            )

        if complaint:
            return self._decision(
                mode=Mode.COMPLAINT,
                intent="complaint",
                stage=value.current_stage,
                action=Action.PAUSE_SALES_MOTION,
                answer_required=True,
                pressure="high",
                executor="either",
                knowledge=("support_procedure", "escalation_rules"),
                loop_count=loop_count,
                forbidden=base_forbidden + ["request_contact_for_sales", "use_loop", "upsell"],
                stage_after="complaint_resolution",
            )

        if support:
            return self._decision(
                mode=Mode.SUPPORT,
                intent="support_request",
                stage=value.current_stage,
                action=Action.ANSWER_ONLY,
                answer_required=True,
                pressure="low",
                executor="either",
                knowledge=("support_procedure", "technical_knowledge"),
                loop_count=loop_count,
                forbidden=base_forbidden + ["request_contact_for_sales", "use_loop", "upsell"],
                stage_after="support",
            )

        if CONTACT_RE.search(message):
            return self._decision(
                mode=Mode.NEXT_STEP,
                intent="contact_permission",
                stage=value.current_stage,
                action=Action.REQUEST_CONTACT,
                answer_required=True,
                offer=True,
                request_contact=True,
                component=Component.CONTACT_TRANSITION,
                executor="codex",
                knowledge=("handoff_rules",),
                loop_count=loop_count,
                forbidden=base_forbidden + ["require_single_contact_channel"],
                stage_after="handoff",
            )

        if QUOTE_RE.search(message):
            question = self._next_missing_question(value)
            return self._decision(
                mode=Mode.NEXT_STEP,
                intent="commercial_proposal_request" if "кп" in message or "предлож" in message else "calculation_request",
                stage=value.current_stage,
                action=Action.PREPARE_HANDOFF if not question else Action.ANSWER_AND_ASK,
                answer_required=True,
                ask=bool(question),
                question_goal=question,
                offer=True,
                request_contact=value.lead_card.contact_permission,
                component=Component.NEXT_STEP,
                executor="codex",
                knowledge=("system_configuration", "pricing_factors", "handoff_rules"),
                loop_count=loop_count,
                forbidden=base_forbidden + ["send_proposal_without_review", "confirm_engineering_calculation"],
                stage_after="next_step",
            )

        if DEMO_RE.search(message):
            return self._decision(
                mode=Mode.NEXT_STEP,
                intent="demo_request",
                stage=value.current_stage,
                action=Action.OFFER_DEMO,
                answer_required=True,
                offer=True,
                component=Component.NEXT_STEP,
                executor="codex",
                knowledge=("demo_scope", "handoff_rules"),
                loop_count=loop_count,
                forbidden=base_forbidden + ["confirm_demo_time"],
                stage_after="next_step",
            )

        if OBJECTION_RE.search(message):
            can_loop = loop_count < 2
            return self._decision(
                mode=Mode.OBJECTION_HANDLING,
                intent=self._objection_intent(message),
                stage=value.current_stage,
                action=Action.HANDLE_OBJECTION,
                answer_required=True,
                ask=True,
                question_goal="identify_real_objection",
                component=Component.OBJECTION_CLARIFICATION if loop_count == 0 else Component.LOOPING,
                use_loop=loop_count > 0 and can_loop,
                executor="codex",
                knowledge=("value_arguments", "objection_rules"),
                loop_count=loop_count,
                forbidden=base_forbidden + (["third_loop"] if loop_count >= 1 else []),
                stage_after="objection_handling",
            )

        if PRICE_RE.search(message):
            question = self._next_missing_question(value)
            return self._decision(
                mode=Mode.CONSULTING,
                intent="price_request",
                stage=value.current_stage,
                action=Action.ANSWER_AND_ASK if question else Action.ANSWER_ONLY,
                answer_required=True,
                ask=bool(question),
                question_goal=question,
                component=Component.SOFT_DISCOVERY if question else Component.DIRECT_ANSWER,
                executor="either",
                knowledge=("pricing_factors", "system_configuration"),
                loop_count=loop_count,
                forbidden=base_forbidden + ["request_phone_immediately"],
                stage_after="context_discovery" if question else "qualification",
            )

        if COMPARE_RE.search(message):
            return self._decision(
                mode=Mode.SOLUTION_SELECTION,
                intent="comparison_request",
                stage=value.current_stage,
                action=Action.COMPARE_OPTIONS,
                answer_required=True,
                component=Component.VALUE_EXPLANATION,
                executor="codex",
                knowledge=("verified_capabilities", "competitor_facts"),
                loop_count=loop_count,
                forbidden=base_forbidden + ["disparage_competitor"],
                stage_after="solution_selection",
            )

        if TECH_RE.search(message) or "?" in message:
            question = ""
            if value.ready_for_next_step:
                question = self._next_missing_question(value)
            return self._decision(
                mode=Mode.CONSULTING,
                intent="technical_question",
                stage=value.current_stage,
                action=Action.ANSWER_AND_ASK if question else Action.ANSWER_ONLY,
                answer_required=True,
                ask=bool(question),
                question_goal=question,
                component=Component.DIRECT_ANSWER,
                executor="either",
                knowledge=("technical_knowledge", "verified_capabilities"),
                loop_count=loop_count,
                forbidden=base_forbidden,
                stage_after=value.current_stage,
            )

        question = self._next_missing_question(value)
        qualification = bool(question and value.lead_card.object_type)
        return self._decision(
            mode=Mode.QUALIFICATION if qualification else Mode.DISCOVERY if question else Mode.NEUTRAL,
            intent="general_interest" if question else "neutral",
            stage=value.current_stage,
            action=Action.ASK_CLARIFYING_QUESTION if question else Action.ANSWER_ONLY,
            answer_required=not bool(question),
            ask=bool(question),
            question_goal=question,
            component=Component.QUALIFICATION if qualification else Component.SOFT_DISCOVERY if question else Component.DIRECT_ANSWER,
            executor="either",
            knowledge=("verified_capabilities",),
            loop_count=loop_count,
            forbidden=base_forbidden,
            stage_after="qualification" if qualification else "discovery" if question else value.current_stage,
        )

    @staticmethod
    def _objection_intent(message: str) -> str:
        if "дорого" in message or "дешевле" in message:
            return "price_objection"
        if "бюджет" in message:
            return "budget_objection"
        if "подумать" in message:
            return "need_to_think"
        return "uncertainty"

    @staticmethod
    def _next_missing_question(value: ControllerInput) -> str:
        candidates = (
            ("identify_object_type", value.lead_card.object_type),
            ("identify_entrances_count", value.lead_card.entrances_count),
            ("identify_current_system", value.lead_card.current_system),
            ("identify_current_problem", value.lead_card.current_problem),
            ("identify_desired_outcome", value.lead_card.desired_outcome),
        )
        asked = set(value.asked_questions)
        for goal, known in candidates:
            if not known and goal not in asked:
                return goal
        return ""

    @staticmethod
    def _decision(
        *,
        mode: Mode,
        intent: str,
        stage: str,
        action: Action,
        answer_required: bool,
        ask: bool = False,
        question_goal: str = "",
        offer: bool = False,
        request_contact: bool = False,
        component: Component = Component.NONE,
        use_loop: bool = False,
        pressure: str = "low",
        executor: str = "either",
        knowledge: tuple[str, ...] = (),
        loop_count: int = 0,
        forbidden: list[str],
        stage_after: str,
    ) -> ControllerDecision:
        return ControllerDecision(
            conversation_mode=mode.value,
            customer_intent=intent,
            current_stage=stage,
            next_best_action=action.value,
            answer_required=answer_required,
            answer_priority="direct",
            should_ask_question=ask,
            question_goal=question_goal if ask else "",
            should_offer_next_step=offer,
            should_request_contact=request_contact,
            should_use_straight_line=bool(component.value),
            straight_line_component=component.value,
            should_use_loop=use_loop,
            loop_count=loop_count,
            pressure_risk=pressure,
            executor_preference=executor,
            required_knowledge=knowledge,
            forbidden_actions=tuple(dict.fromkeys(forbidden)),
            stage_after=stage_after,
        )
