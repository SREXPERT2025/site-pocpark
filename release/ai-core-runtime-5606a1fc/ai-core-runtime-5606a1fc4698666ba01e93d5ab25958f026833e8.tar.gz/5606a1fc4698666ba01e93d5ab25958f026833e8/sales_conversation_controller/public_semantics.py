from __future__ import annotations

from typing import Any


PUBLIC_ENUM_LABELS: dict[str, dict[Any, str]] = {
    "object_type": {
        "business_center": "бизнес-центр",
        "shopping_center": "торговый центр",
        "residential_complex": "жилой комплекс",
        "warehouse": "складской объект",
    },
    "user_segments": {
        "employees": "сотрудники",
        "employee": "сотрудники",
        "tenants": "арендаторы",
        "tenant": "арендаторы",
        "guests": "гости",
        "guest": "гости",
        "permanent": "постоянные пользователи",
        "one_time": "разовые посетители",
        "walk_in_visitors": "разовые посетители",
        "service_vehicles": "служебный транспорт",
    },
    "current_system": {
        "new_build": "проектируется с нуля",
        "installed": "уже установлена",
        "existing": "уже установлена",
    },
    "modernization_or_new_build": {
        "new_build": "новое строительство",
        "modernization": "модернизация существующей системы",
    },
    "existing_system": {
        "none": "существующей системы нет",
        "new_build": "существующей системы нет",
        "installed": "система установлена",
    },
    "speed_priority": {"high": "высокий", "balanced": "сбалансированный"},
    "primary_identifier": {
        "license_plate_recognition": "распознавание номеров",
        "parking_card": "парковочная карта",
        "parking_ticket": "парковочный билет",
        "guest_qr": "гостевой QR-код",
        "radio_tag": "радиометка",
    },
}


def public_semantic_value(field: str, value: Any) -> Any:
    """Project a canonical value into public language without weakening token gates."""
    labels = PUBLIC_ENUM_LABELS.get(field, {})
    if isinstance(value, (list, tuple)):
        return [labels.get(item, item) for item in value]
    return labels.get(value, value)


def public_boolean(value: Any, *, positive: str, negative: str) -> str:
    return positive if value is True else negative


OBJECT_CARD_PUBLIC_FIELD_REGISTRY: dict[str, dict[str, Any]] = {
    "object_type": {"label": "тип объекта", "kind": "enum"},
    "entrances_count": {"label": "въезды", "kind": "scalar"},
    "exits_count": {"label": "выезды", "kind": "scalar"},
    "daily_traffic": {"label": "суточный поток", "kind": "daily_traffic"},
    "user_segments": {"label": "группы пользователей", "kind": "list_enum"},
    "operator_present": {"label": "оператор", "kind": "operator"},
    "entry_price_rub": {"label": "стоимость въезда", "kind": "rubles"},
    "gate_requires_payment_confirmation": {
        "label": "открытие шлагбаума",
        "kind": "payment_gate",
    },
    "speed_priority": {"label": "приоритет скорости", "kind": "enum"},
    "mandatory_automated_fallback": {
        "label": "автоматический резерв",
        "kind": "mandatory_fallback",
    },
    "current_system": {"label": "система", "kind": "enum"},
}

OBJECT_CARD_DOCUMENTED_EXCLUSIONS: dict[str, str] = {
    "daily_traffic_certainty": "rendered_as_daily_traffic_modifier",
}


def project_object_card(facts: list[dict[str, Any]]) -> dict[str, Any]:
    values = {
        str(item.get("field") or ""): item.get("value")
        for item in facts
        if item.get("field") and item.get("conflict_state", "none") == "none"
    }
    rendered_fields: list[str] = []
    parts: list[str] = []
    for field, spec in OBJECT_CARD_PUBLIC_FIELD_REGISTRY.items():
        if field not in values:
            continue
        value = values[field]
        kind = spec["kind"]
        label = spec["label"]
        if kind == "enum":
            rendered = f"{label} — {public_semantic_value(field, value)}"
        elif kind == "list_enum":
            rendered = f"{label} — " + ", ".join(public_semantic_value(field, value))
        elif kind == "daily_traffic":
            qualifier = "около " if values.get("daily_traffic_certainty") == "approximate" else ""
            rendered = f"{label} — {qualifier}{value} автомобилей"
        elif kind == "operator":
            rendered = f"{label} — {public_boolean(value, positive='есть', negative='нет')}"
        elif kind == "rubles":
            rendered = f"{label} — {value} рублей"
        elif kind == "payment_gate":
            rendered = f"{label} — " + public_boolean(
                value, positive="после подтверждения оплаты", negative="не зависит от подтверждения оплаты",
            )
        elif kind == "mandatory_fallback":
            rendered = f"{label} — " + public_boolean(
                value, positive="обязателен", negative="не обязателен",
            )
        else:
            rendered = f"{label} — {value}"
        rendered_fields.append(field)
        parts.append(rendered)

    excluded_fields = [
        {"field": field, "reason": OBJECT_CARD_DOCUMENTED_EXCLUSIONS[field]}
        for field in values
        if field not in OBJECT_CARD_PUBLIC_FIELD_REGISTRY
        and field in OBJECT_CARD_DOCUMENTED_EXCLUSIONS
    ]
    unsupported_fields = sorted(
        field for field in values
        if field not in OBJECT_CARD_PUBLIC_FIELD_REGISTRY
        and field not in OBJECT_CARD_DOCUMENTED_EXCLUSIONS
    )
    answer = (
        "В карточке объекта подтверждено: " + "; ".join(parts) + "."
        if parts else "В карточке объекта пока нет подтверждённых данных."
    )
    return {
        "answer": answer,
        "rendered_fields": rendered_fields,
        "excluded_fields": excluded_fields,
        "unsupported_fields": unsupported_fields,
    }
