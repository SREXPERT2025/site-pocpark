from __future__ import annotations

import hashlib
import math
import struct
from typing import Any


CANONICALIZATION_VERSION = "CANONICAL_JSON_HASH_V1"
MAX_INTEROPERABLE_INTEGER = 9_007_199_254_740_991


class CanonicalizationError(ValueError):
    pass


def _canonical_string(value: str) -> str:
    output: list[str] = ['"']
    for character in value:
        codepoint = ord(character)
        if 0xD800 <= codepoint <= 0xDFFF:
            raise CanonicalizationError("CANONICAL_JSON_INVALID_UNICODE")
        if character == '"':
            output.append('\\"')
        elif character == "\\":
            output.append("\\\\")
        elif codepoint <= 0x1F:
            output.append(f"\\u{codepoint:04x}")
        else:
            output.append(character)
    output.append('"')
    return "".join(output)


def _canonical_number(value: float) -> str:
    if not math.isfinite(value):
        raise CanonicalizationError("CANONICAL_JSON_NON_FINITE_NUMBER")
    if value == 0:
        return "0"
    negative = value < 0
    bits = struct.unpack(">Q", struct.pack(">d", abs(value)))[0]
    exponent_bits = (bits >> 52) & 0x7FF
    fraction = bits & ((1 << 52) - 1)
    if exponent_bits == 0:
        mantissa = fraction
        exponent = -1074
    else:
        mantissa = (1 << 52) | fraction
        exponent = exponent_bits - 1023 - 52
    if exponent >= 0:
        rendered = str(mantissa << exponent)
    else:
        scale = -exponent
        digits = str(mantissa * (5 ** scale))
        if len(digits) <= scale:
            rendered = "0." + ("0" * (scale - len(digits))) + digits
        else:
            rendered = digits[:-scale] + "." + digits[-scale:]
        rendered = rendered.rstrip("0").rstrip(".")
    if "." not in rendered and int(rendered) > MAX_INTEROPERABLE_INTEGER:
        raise CanonicalizationError("CANONICAL_JSON_UNSAFE_INTEGER")
    return ("-" if negative else "") + rendered


def canonical_json(value: Any) -> str:
    active: set[int] = set()

    def encode(item: Any) -> str:
        if item is None:
            return "null"
        if item is True:
            return "true"
        if item is False:
            return "false"
        if isinstance(item, str):
            return _canonical_string(item)
        if isinstance(item, int):
            if abs(item) > MAX_INTEROPERABLE_INTEGER:
                raise CanonicalizationError("CANONICAL_JSON_UNSAFE_INTEGER")
            return str(item)
        if isinstance(item, float):
            return _canonical_number(item)
        if isinstance(item, list):
            identity = id(item)
            if identity in active:
                raise CanonicalizationError("CANONICAL_JSON_CYCLE")
            active.add(identity)
            try:
                return "[" + ",".join(encode(entry) for entry in item) + "]"
            finally:
                active.remove(identity)
        if isinstance(item, dict):
            if any(not isinstance(key, str) for key in item):
                raise CanonicalizationError("CANONICAL_JSON_NON_STRING_KEY")
            identity = id(item)
            if identity in active:
                raise CanonicalizationError("CANONICAL_JSON_CYCLE")
            active.add(identity)
            try:
                return "{" + ",".join(
                    f"{_canonical_string(key)}:{encode(item[key])}"
                    for key in sorted(item)
                ) + "}"
            finally:
                active.remove(identity)
        raise CanonicalizationError("CANONICAL_JSON_UNSUPPORTED_TYPE")

    return encode(value)


def canonical_utf8(value: Any) -> bytes:
    return canonical_json(value).encode("utf-8", errors="strict")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_utf8(value)).hexdigest()


def sha256(value: Any) -> str:
    """Preserve raw-text identifiers; canonicalize every structured JSON hash."""
    if isinstance(value, str):
        return hashlib.sha256(value.encode("utf-8", errors="strict")).hexdigest()
    return canonical_sha256(value)
