from __future__ import annotations

import copy
import re
from difflib import ndiff
from typing import Any

from .canonical import sha256
from .constants import CANONICALIZATION_VERSION, CONTRACT_TARGET_SHA, RUNTIME_VERSION


TRACE_SCHEMA_VERSION = "AI_CORE_RUNTIME_TRACE_V1"
MAX_TEXT_CHARS = 32_000

_SECRET_VALUE = re.compile(
    r"(?:\bBearer\s+[A-Za-z0-9._~+/=-]+|\bsk-[A-Za-z0-9_-]{12,}|"
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:password|secret|token|credential)\s*=)",
    re.IGNORECASE,
)
_FORBIDDEN_KEYS = frozenset({
    "cookie", "cookies", "credential", "credentials", "password", "secret",
    "token", "tokens", "api_key", "authorization", "environment", "env",
    "chain_of_thought", "reasoning", "hidden_reasoning",
})
_INSTRUCTION_MARKERS = (
    "заверши ответ",
    "ответь следующим",
    "обязательно включи",
    "финальное инженерное решение",
    "оператор участвует только",
    "не добавляем новое оборудование",
    "неподтверждённой инфраструктуры",
    "system instruction",
    "developer instruction",
    "prompt",
    "reason code",
    "exact_next_question",
    "next_question_placeholder",
)


def _redact_string(value: str) -> str:
    normalized = value.replace("\x00", "")
    if _SECRET_VALUE.search(normalized):
        return "[REDACTED_SECRET]"
    if len(normalized) > MAX_TEXT_CHARS:
        return normalized[:MAX_TEXT_CHARS] + "…[TRUNCATED]"
    return normalized


def sanitize_trace_value(value: Any, *, depth: int = 0) -> Any:
    """Return a bounded, secret-free copy of observable execution evidence."""
    if depth > 16:
        return "[TRUNCATED_DEPTH]"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return _redact_string(value)
    if isinstance(value, (list, tuple)):
        return [sanitize_trace_value(item, depth=depth + 1) for item in value[:300]]
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for raw_key, item in list(value.items())[:500]:
            key = str(raw_key)
            if key.casefold() in _FORBIDDEN_KEYS:
                result[key] = "[REDACTED]"
            else:
                result[key] = sanitize_trace_value(item, depth=depth + 1)
        return result
    return _redact_string(str(value))


def _collect_evidence_refs(value: Any, found: set[str] | None = None) -> list[str]:
    refs = found if found is not None else set()
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"evidence_refs", "concise_evidence_refs"} and isinstance(item, list):
                refs.update(str(ref).strip() for ref in item if str(ref).strip())
            else:
                _collect_evidence_refs(item, refs)
    elif isinstance(value, list):
        for item in value:
            _collect_evidence_refs(item, refs)
    return sorted(refs)


def _source_type(ref: str) -> str:
    clean = ref.casefold()
    if "engineering" in clean or "parking_" in clean:
        return "engineering_card"
    if clean.startswith("ctxref:knowledge") or "knowledge_base" in clean:
        return "company_knowledge"
    if "policy" in clean:
        return "policy"
    return "evidence"


def _text_fragments(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.casefold()
    if isinstance(value, (list, tuple)):
        return "\n".join(_text_fragments(item) for item in value)
    if isinstance(value, dict):
        return "\n".join(_text_fragments(item) for item in value.values())
    return str(value).casefold()


def _first_appearance(
    *, request: dict[str, Any], trace: dict[str, Any], response: dict[str, Any],
) -> dict[str, Any]:
    payload = request.get("payload") if isinstance(request.get("payload"), dict) else {}
    projection = trace.get("verbalization_projection")
    prompt = trace.get("model_prompt_contract")
    raw = trace.get("raw_answer")
    repaired = trace.get("final_answer")
    visible = response.get("answer") if response.get("success") is True else None
    sources = [
        ("client_message", payload.get("current_message")),
        ("conversation_memory", payload.get("recent_messages")),
        ("decision_package", response.get("decision_package")),
        ("verbalization_projection", projection),
        ("model_input", prompt),
        ("raw_executor_output", raw),
        ("repaired_answer", repaired),
        ("visible_candidate", visible),
    ]
    findings: list[dict[str, Any]] = []
    for marker in _INSTRUCTION_MARKERS:
        present = [name for name, value in sources if marker in _text_fragments(value)]
        if not present:
            continue
        findings.append({
            "fragment": marker,
            "first_stage": present[0],
            "present_stages": present,
            "visible": "visible_candidate" in present,
            "warning_code": (
                "POSSIBLE_INTERNAL_INSTRUCTION_LEAK"
                if "visible_candidate" in present
                and present[0] in {
                    "verbalization_projection", "model_input",
                    "raw_executor_output", "repaired_answer",
                }
                else None
            ),
        })
    return {
        "status": "warn" if any(item["warning_code"] for item in findings) else "pass",
        "findings": findings,
    }


def _repair_diff(raw: str, final: str) -> dict[str, Any]:
    if raw == final:
        return {"changed": False, "lines": []}
    return {
        "changed": True,
        "lines": list(ndiff(raw.splitlines(), final.splitlines()))[:400],
    }


def _stage(
    name: str, status: str, *, summary: str, input_value: Any = None,
    output_value: Any = None, reason_codes: Any = None, latency_ms: int | None = None,
) -> dict[str, Any]:
    return {
        "name": name,
        "status": status,
        "summary": summary,
        "input": sanitize_trace_value(input_value),
        "output": sanitize_trace_value(output_value),
        "reason_codes": sorted({str(item) for item in (reason_codes or [])}),
        "latency_ms": latency_ms,
    }


def _timeline(trace: dict[str, Any]) -> list[dict[str, Any]]:
    events = trace.get("timeline")
    if not isinstance(events, list):
        events = []
    return [sanitize_trace_value(item) for item in events]


def build_runtime_observability_trace(
    request: dict[str, Any], trace: dict[str, Any], response: dict[str, Any],
) -> dict[str, Any]:
    """Build additive evidence. It is not part of the business response contract."""
    payload = request.get("payload") if isinstance(request.get("payload"), dict) else {}
    success = response.get("success") is True
    safe_error = response.get("error") if isinstance(response.get("error"), dict) else {}
    context = response.get("context_resolution") if success else None
    controller = (
        response.get("controller_decision") if success
        else trace.get("controller_decision")
    )
    package = (
        response.get("decision_package") if success
        else trace.get("decision_package")
    )
    projection = trace.get("verbalization_projection")
    prompt = trace.get("model_prompt_contract")
    executor = trace.get("executor_trace") if isinstance(trace.get("executor_trace"), dict) else {}
    attempts = executor.get("attempts") if isinstance(executor.get("attempts"), list) else []
    raw_answer = str(trace.get("raw_answer") or "")
    final_answer = str(trace.get("final_answer") or "")
    runtime_observability = (
        trace.get("runtime_observability")
        if isinstance(trace.get("runtime_observability"), dict) else {}
    )
    publication = (
        runtime_observability.get("publication")
        if isinstance(runtime_observability.get("publication"), dict) else {}
    )
    publication_status = (
        str(publication.get("candidate_status") or "error") if success else "error"
    )
    raw_evaluation = trace.get("raw_evaluation")
    final_evaluation = trace.get("final_evaluation")
    raw_status = trace.get("raw_evaluation_status")
    raw_reasons = trace.get("raw_evaluation_reason_codes") or []
    final_status = trace.get("final_evaluation_status")
    final_reasons = (
        response.get("evaluation_result", {}).get("reason_codes", [])
        if isinstance(response.get("evaluation_result"), dict)
        else trace.get("final_evaluation_reason_codes") or []
    )
    repair = (
        trace.get("repair_result")
        if isinstance(trace.get("repair_result"), dict)
        else response.get("repair_result")
        if isinstance(response.get("repair_result"), dict)
        else {}
    )
    evaluation_policy = (
        trace.get("evaluation_policy")
        if isinstance(trace.get("evaluation_policy"), dict) else {}
    )
    history_hygiene = (
        trace.get("history_hygiene")
        if isinstance(trace.get("history_hygiene"), dict) else {}
    )
    ingestion = (
        trace.get("ingestion_observability")
        if isinstance(trace.get("ingestion_observability"), dict) else {}
    )
    state_mutations = (
        response.get("state_mutations") if success
        else trace.get("state_mutations") or []
    )
    if not isinstance(state_mutations, list):
        state_mutations = []
    evidence_refs = _collect_evidence_refs(package)
    request_refs = payload.get("consent_safe_context_refs")
    if isinstance(request_refs, list):
        evidence_refs = sorted(set(evidence_refs).union(map(str, request_refs)))

    failed_stage = str(safe_error.get("stage") or "") if safe_error else None
    stages = [
        _stage(
            "client_message", "pass" if payload.get("current_message") else "error",
            summary="Current message and exact recent history accepted by Runtime.",
            input_value={
                "current_message": payload.get("current_message"),
                "recent_messages": payload.get("recent_messages") or [],
                "source_page": payload.get("source_page"),
            },
            output_value={"message_id": payload.get("message_id")},
        ),
        _stage(
            "context_integrity",
            "pass" if context or ingestion
            else ("error" if failed_stage in {"controller", "validation"} else "not_reached"),
            summary="Intent, action, current-turn facts, conflicts and context relation.",
            input_value={
                "current_message": payload.get("current_message"),
                "durable_facts": payload.get("confirmed_project_facts") or [],
                "active_question": payload.get("active_question"),
                "recent_messages": payload.get("recent_messages") or [],
            },
            output_value={
                "resolution": context or ingestion,
                "history_hygiene": history_hygiene,
            },
        ),
        _stage(
            "project_memory",
            "pass" if ingestion else "not_reached",
            summary="Durable state before, request-local effective facts, and proposals.",
            input_value={
                "state_version": payload.get("state_version"),
                "confirmed_project_facts": payload.get("confirmed_project_facts") or [],
                "candidate_facts": payload.get("candidate_facts") or [],
                "fact_conflicts": payload.get("fact_conflicts") or [],
            },
            output_value={
                "durable_before": ingestion.get("durable_confirmed_facts_before"),
                "request_local_effective": ingestion.get("request_local_effective_facts"),
                "proposed_mutations": state_mutations,
            },
        ),
        _stage(
            "sales_controller", "pass" if controller else "not_reached",
            summary="Sales Controller observable decision.",
            input_value={
                "facts": ingestion.get("controller_input_facts"),
                "resolved_intent": ingestion.get("resolved_intent"),
                "resolved_action": ingestion.get("resolved_action"),
            },
            output_value=controller,
        ),
        _stage(
            "engineering_lab",
            "not_used" if trace.get("engineering_decision_laboratory") == "not_invoked"
            else "pass" if package else "not_reached",
            summary=("Engineering Decision Lab was not needed."
                     if trace.get("engineering_decision_laboratory") == "not_invoked"
                     else "Engineering Decision Lab input and output."),
            input_value=ingestion.get("engineering_lab_input_facts"),
            output_value=trace.get("engineering_decision_lab") or package,
        ),
        _stage(
            "decision_package", "pass" if package else "not_reached",
            summary="Immutable structured decision package.",
            input_value=package,
            output_value={
                "decision_package": package,
                "sha256": response.get("decision_package_hash")
                or trace.get("decision_package_hash"),
            },
        ),
        _stage(
            "knowledge_sources", "pass" if evidence_refs else "not_used",
            summary=(f"{len(evidence_refs)} evidence source(s) selected."
                     if evidence_refs else "No knowledge source was used."),
            output_value=[{
                "source_type": _source_type(ref),
                "source_id": ref,
                "title": ref.rsplit("/", 1)[-1],
                "version": "as_referenced",
                "retrieved": True,
                "selected": True,
                "used_in_decision": ref in _collect_evidence_refs(package),
            } for ref in evidence_refs],
        ),
        _stage(
            "verbalization_projection", "pass" if projection else "not_reached",
            summary="Exact structured projection supplied to the verbalizer.",
            input_value=package,
            output_value={
                "projection": projection,
                "sha256": (
                    prompt.get("projection_hash")
                    if isinstance(prompt, dict) else None
                ),
            },
        ),
        _stage(
            "executor", "pass" if raw_answer else ("error" if failed_stage == "executor" else "not_reached"),
            summary="Sanitized exact executor input and raw output.",
            input_value={
                "transport_messages": ([{
                    "role": "user",
                    "content": prompt.get("serialized_prompt"),
                }] if isinstance(prompt, dict) and prompt.get("serialized_prompt") else []),
                "policy": payload.get("executor_policy"),
                "decision_projection": projection,
                "conversation_context": payload.get("recent_messages") or [],
                "current_user_message": payload.get("current_message"),
            },
            output_value={"raw_answer": raw_answer or None, "executor_trace": executor},
            latency_ms=sum(int(item.get("latency_ms") or 0) for item in attempts if isinstance(item, dict)),
        ),
        _stage(
            "evaluator_raw",
            "pass" if raw_status == "pass"
            else "blocked" if raw_status in {"fail", "review_required"}
            else "pass" if raw_evaluation else "not_reached",
            summary="Raw answer evaluation before deterministic repair.",
            input_value={"decision_package": package, "projection": projection, "raw_answer": raw_answer},
            output_value={
                "evaluation": raw_evaluation,
                "semantic_coverage": trace.get("raw_semantic_coverage"),
                "status": raw_status or ingestion.get("raw_evaluation_status"),
                "reason_codes": raw_reasons,
                "evaluation_profile": evaluation_policy.get("name")
                or runtime_observability.get("evaluation_profile"),
                "applied_rule_groups": evaluation_policy.get("applied_rule_groups")
                or runtime_observability.get("rule_application", {}).get("applied", []),
                "skipped_rule_groups": evaluation_policy.get("skipped_rule_groups")
                or runtime_observability.get("rule_application", {}).get("skipped", []),
            },
            reason_codes=raw_reasons,
        ),
        _stage(
            "repair", (
                "blocked" if repair.get("applied") and repair.get("success") is False
                else "pass" if repair.get("applied")
                else "not_used" if success else "not_reached"
            ),
            summary="Deterministic repair before/after evidence.",
            input_value={"answer": raw_answer},
            output_value={
                "answer": final_answer or None,
                "repair": repair,
                "reason_codes": repair.get("reason_codes", []),
                "diff": _repair_diff(raw_answer, final_answer),
            },
            reason_codes=repair.get("reason_codes", []),
        ),
        _stage(
            "evaluator_final",
            "pass" if publication_status == "allowed" else "blocked" if success else "not_reached",
            summary="Final candidate evaluation and publication recommendation.",
            input_value={"answer": final_answer, "decision_package": package, "projection": projection},
            output_value={
                "evaluation": final_evaluation,
                "semantic_coverage": trace.get("final_semantic_coverage"),
                "status": final_status or ingestion.get("final_evaluation_status"),
                "reason_codes": final_reasons,
            },
            reason_codes=final_reasons,
        ),
        _stage(
            "runtime_publication",
            "pass" if publication_status == "allowed" else "blocked" if success else "error",
            summary=f"Runtime publication candidate status: {publication_status}.",
            output_value={"candidate_status": publication_status, "published": False},
            reason_codes=final_reasons,
        ),
    ]
    first_failure = next(
        (item["name"] for item in stages if item["status"] in {"error", "blocked"}),
        None,
    )
    result = {
        "schema_version": TRACE_SCHEMA_VERSION,
        "identity": {
            "ai_core_request_id": request.get("request_id"),
            "conversation_thread_id": payload.get("conversation_thread_id"),
            "message_id": payload.get("message_id"),
            "parent_message_id": payload.get("parent_message_id"),
            "timestamp": payload.get("timestamp") or request.get("sent_at"),
            "contract_sha": CONTRACT_TARGET_SHA,
            "contract_version": request.get("contract_version"),
            "runtime_version": RUNTIME_VERSION,
            "canonicalization_version": CANONICALIZATION_VERSION,
        },
        "routing": {
            "route": "ai_core",
            "executor": executor.get("final_executor") or payload.get("executor_policy", {}).get("planned_executor"),
            "executor_request_count": len(attempts),
            "retries": max(0, len(attempts) - 1),
            "fallbacks": 0 if executor.get("fallback_reason") in {None, "none"} else 1,
            "evaluation_profile": evaluation_policy.get("name")
            or runtime_observability.get("evaluation_profile"),
        },
        "state": {
            "version_before": payload.get("state_version"),
            "version_after_proposed": response.get("state_version_after") if success else payload.get("state_version"),
            "durable_before": payload.get("confirmed_project_facts") or [],
            "request_local_effective": ingestion.get("request_local_effective_facts") or {},
            "proposed_mutations": state_mutations,
            "committed_mutations": [],
        },
        "pipeline": stages,
        "timeline": _timeline(trace),
        "diagnostics": {
            "first_failure_stage": first_failure,
            "first_appearance": _first_appearance(request=request, trace=trace, response=response),
            "history_hygiene": sanitize_trace_value(history_hygiene),
            "evaluation_policy": sanitize_trace_value(evaluation_policy),
            "projection_drift": sanitize_trace_value(trace.get("projection_decision_drift") or []),
            "runtime_total_ms": (
                response.get("telemetry", {}).get("latency", {}).get("total_ms")
                if isinstance(response.get("telemetry"), dict)
                and isinstance(response.get("telemetry", {}).get("latency"), dict)
                else None
            ),
        },
        "runtime_error": sanitize_trace_value(safe_error) if safe_error else None,
    }
    safe = sanitize_trace_value(result)
    safe["trace_sha256"] = sha256(safe)
    return safe
