#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const Ajv = require('ajv');

const contractRoot = process.argv[2];
const schemaName = process.argv[3];
const externalSchemaPath = process.argv[4] || null;
const schemaNames = [
  'executor-policy-v1.schema.json',
  'state-mutation-v1.schema.json',
  'mutation-ack-v1.schema.json',
  'error-envelope-v1.schema.json',
  'executor-trace-v1.schema.json',
  'telemetry-v1.schema.json',
  'request-v1.schema.json',
  'response-v1.schema.json',
];

function load(name) {
  return JSON.parse(fs.readFileSync(path.join(contractRoot, name), 'utf8'));
}

let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (part) => { input += part; });
process.stdin.on('end', () => {
  try {
    const ajv = new Ajv({allErrors: true, jsonPointers: true, schemaId: 'auto'});
    for (const name of schemaNames) ajv.addSchema(load(name), name);
    let targetSchema = schemaName;
    if (externalSchemaPath) {
      targetSchema = 'external-runtime-schema.json';
      ajv.addSchema(JSON.parse(fs.readFileSync(externalSchemaPath, 'utf8')), targetSchema);
    }
    const document = JSON.parse(input);
    const valid = ajv.validate(targetSchema, document);
    process.stdout.write(JSON.stringify({valid, errors: ajv.errors || []}));
    process.exitCode = valid ? 0 : 2;
  } catch (_error) {
    process.stdout.write(JSON.stringify({
      valid: false,
      errors: [{keyword: 'validator_internal_error', dataPath: '', message: 'schema validation unavailable'}],
    }));
    process.exitCode = 3;
  }
});
