from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..public_semantics import public_semantic_value


@dataclass(frozen=True)
class StubOutput:
    answer: str
    latency_ms: int
    cost_bucket: str


class StubExecutorError(RuntimeError):
    safe_error_code = "EXECUTOR_SAFE_ERROR"
    status = "safe_error"


class StubExecutorTimeout(StubExecutorError):
    safe_error_code = "EXECUTOR_TIMEOUT"
    status = "timeout"


class StubExecutorUnavailable(StubExecutorError):
    safe_error_code = "EXECUTOR_UNAVAILABLE"
    status = "unavailable"


def _engineering_answer(package: dict[str, Any]) -> str:
    question = str(package.get("next_question") or "").strip()
    if package.get("decision_status") == "comparison_only":
        scope = set(package.get("comparison_scope") or ())
        parts = []
        if "license_plate" in scope:
            parts.append(
                "Распознавание номеров подходит для быстрого бесконтактного потока, но требует заранее предусмотренного автоматического резерва на случай ошибки распознавания."
            )
        if "card" in scope:
            parts.append(
                "Карты удобны для повторного проезда постоянных пользователей, но требуют организовать выдачу, возврат и контроль состояния носителей."
            )
        if "ticket" in scope:
            parts.append(
                "Билеты подходят для разовых посетителей без возврата носителя, но создают постоянный расход ленты и нагрузку по обслуживанию механизма выдачи."
            )
        parts.append(
            "По известным данным безусловного победителя пока нет: выбор зависит от состава потока, подтверждённых считывателей и организации эксплуатации."
        )
        if question:
            parts.append(question)
        return " ".join(parts)
    if package.get("decision_status") == "fallback_decision_pending":
        parts = [
            "Если номер не распознан, должен использоваться заранее предусмотренный автоматический резервный способ проезда.",
            "Конкретный резерв пока не выбран: он зависит от подтверждённой инфраструктуры объекта.",
            "Оператор может подключаться только для исключительной ручной помощи и не заменяет автоматический резерв.",
            "Как именно водитель получит инструкцию, можно определить только после подтверждения оборудования и интерфейса на полосе.",
        ]
        if question:
            parts.append(question)
        return " ".join(parts)
    parts = [
        "Для сотрудников и арендаторов предварительно можно рассматривать распознавание номеров как основной способ проезда.",
        "Для гостей право доступа может формироваться через гостевую заявку, а идентификация — по заранее зарегистрированному номеру либо другому подтверждённому носителю.",
        "Автоматический резерв определяется отдельно для каждой категории после проверки установленного оборудования; оператор используется только для исключительных ситуаций.",
        "Карты и билеты создают разные виды эксплуатационной нагрузки, поэтому их нужно сравнивать по потоку, бесплатному периоду, возврату карт и расходу билетной ленты.",
    ]
    if question:
        parts.append(question)
    return " ".join(parts)


def _deterministic_answer(context: dict[str, Any]) -> str:
    package = context["decision_package"]
    resolution = context["context_resolution"]
    message = context["current_message"]
    verified = context.get("verified_knowledge_package") or []
    technical = verified[0] if verified and isinstance(verified[0], dict) else None
    knowledge_id = str((technical or {}).get("knowledge_id") or "")
    safe_summary = str((technical or {}).get("safe_summary") or "").strip()
    question = str(package.get("next_question") or "").strip()
    if knowledge_id == "identifier_comparison_by_segment":
        return _engineering_answer(package)
    if knowledge_id in {
        "guest_application_authorization_workflow",
        "card_dispenser_capacity_boundary",
        "ticket_roll_yield_calculation",
        "payment_confirmation_capability_boundary",
    }:
        parts = [safe_summary]
        facts = {
            item.get("field"): item.get("value")
            for item in context.get("confirmed_project_facts") or []
        }
        if knowledge_id == "payment_confirmation_capability_boundary" and "entry_price_rub" in facts:
            parts.append(f"Стоимость въезда по требованию объекта — {facts['entry_price_rub']} рублей.")
        if question:
            parts.append(question)
        return " ".join(item for item in parts if item)
    if knowledge_id == "provisional_engineering_solution_boundary":
        facts = {
            item.get("field"): public_semantic_value(
                str(item.get("field") or ""), item.get("value")
            )
            for item in context.get("confirmed_project_facts") or []
        }
        fact_parts = [
            f"тип объекта — {facts['object_type']}" if "object_type" in facts else "",
            f"въезды/выезды — {facts.get('entrances_count')}/{facts.get('exits_count')}" if "entrances_count" in facts and "exits_count" in facts else "",
            f"поток — {facts['daily_traffic']} автомобилей в сутки" if "daily_traffic" in facts else "",
            f"доля постоянных пользователей — {facts['permanent_user_share_percent']}%" if "permanent_user_share_percent" in facts else "",
            f"система — {facts['current_system']}" if "current_system" in facts else "",
            f"стоимость въезда — {facts['entry_price_rub']} рублей" if "entry_price_rub" in facts else "",
            "открытие после подтверждения оплаты" if facts.get("gate_requires_payment_confirmation") is True else "",
            f"приоритет скорости — {facts['speed_priority']}" if "speed_priority" in facts else "",
            "автоматический резерв обязателен" if facts.get("mandatory_automated_fallback") is True else "",
        ]
        parts = [
            "Предварительная рекомендация по подтверждённой карточке объекта.",
            "Учтено: " + "; ".join(item for item in fact_parts if item) + ".",
            safe_summary,
            _engineering_answer({**package, "next_question": None}),
        ]
        if facts.get("mandatory_automated_fallback") is True:
            parts.append(
                "Конкретный автоматический резерв пока не выбран: его нужно определить после подтверждения инфраструктуры считывателей для каждой категории пользователей."
            )
        if question:
            parts.append(question)
        return " ".join(item for item in parts if item)
    if package.get("decision_type") == "access_identifier_selection":
        return _engineering_answer(package)
    action = resolution.get("command_requirements", {}).get("action_type")
    if resolution.get("relation") == "answer_to_previous_question":
        facts = resolution.get("extracted_facts") or {}
        if "current_system" in facts:
            return "Понял: парковочная система у вас уже установлена."
        if facts:
            name = next(key for key in facts if not key.endswith("__fact_type"))
            return f"Понял и учёл: {facts[name]}."
        return "Понял ваш ответ на предыдущий вопрос."
    if action == "utility_request":
        return "2+2 = 4."
    if action == "remember_fact":
        facts = resolution.get("extracted_facts") or {}
        if "entry_price_rub" in facts:
            return (
                f"Зафиксировал: стоимость въезда — {facts['entry_price_rub']} рублей; "
                "шлагбаум открывается только после подтверждения оплаты."
            )
        if facts:
            name = next(key for key in facts if not key.endswith("__fact_type"))
            return f"Зафиксировал подтверждённое значение: {name} — {facts[name]}."
        return "Не удалось выделить подтверждённый факт из текущей реплики."
    if action == "ask_one_question":
        return str(package.get("next_question") or "Какой тип объекта планируется автоматизировать?")
    if action == "conversation_summary":
        return (
            "По истории разговора обсуждаются бизнес-центр, два въезда и два выезда, поток автомобилей, "
            "распознавание номеров, доступ гостей и резервный сценарий."
        )
    if action in {"recall_facts", "memory_conflict_resolution"}:
        facts = context.get("confirmed_project_facts") or []
        values = [f"{item['field']} — {item['value']}" for item in facts[:5]]
        answer = "Вы сообщали: " + "; ".join(values) + "."
        if context.get("fact_conflicts"):
            answer += " Есть открытое противоречие в ранее сообщённых данных; его нужно отдельно уточнить."
        return answer
    if action in {"provide_source", "provide_link"}:
        refs = context.get("evidence_refs") or []
        if refs:
            return f"Источник — раздел «Парковочный доступ»; безопасная ссылка на него: `{refs[0]}`."
        route = (resolution.get("retrieval") or {}).get("required_route")
        return f"Подтверждённый источник: `{route}`." if route else "Для ответа нужен подтверждённый источник."
    if action == "compare_options":
        return "Сравнение нужно выполнять по подтверждённым условиям объекта; неподтверждённые варианты остаются кандидатами."
    return f"Текущая реплика принята: {message}"


class QwenStub:
    executor = "qwen"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        return StubOutput(_deterministic_answer(context), 4, "local_low")


class CodexStub:
    executor = "codex"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        return StubOutput(_deterministic_answer(context), 5, "external_low")


class CodexTimeoutStub:
    executor = "codex"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        raise StubExecutorTimeout("safe_stub_timeout")


class CodexUnavailableStub:
    executor = "codex"

    def execute(self, context: dict[str, Any]) -> StubOutput:
        raise StubExecutorUnavailable("safe_stub_unavailable")
