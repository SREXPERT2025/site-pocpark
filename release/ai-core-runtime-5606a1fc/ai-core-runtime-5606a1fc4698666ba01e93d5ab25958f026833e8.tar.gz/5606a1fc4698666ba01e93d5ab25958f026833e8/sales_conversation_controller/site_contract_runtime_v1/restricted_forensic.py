from __future__ import annotations

import copy
import re
from typing import Any

from .canonical import sha256
from .constants import CANONICALIZATION_VERSION, CONTRACT_TARGET_SHA, RUNTIME_VERSION


RESTRICTED_FORENSIC_SCHEMA_VERSION = "OWNER_CANARY_BLOCKED_FORENSIC_V1"
MAX_ANSWER_CHARS = 8_000

_CODE = re.compile(r"^[a-z][a-z0-9_]{0,100}$")
_SECRET_VALUE = re.compile(
    r"(?:\bBearer\s+[A-Za-z0-9._~+/=-]+|\bsk-[A-Za-z0-9_-]{12,}|"
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:password|secret|token)\s*=)",
    re.IGNORECASE,
)
_FORBIDDEN_KEYS = frozenset({
    "cookie", "credential", "credentials", "password", "secret", "token",
    "user_message", "current_message", "raw_user_text",
})


def _safe_text(value: Any, *, maximum: int = 240) -> str:
    text = " ".join(str(value or "").replace("\x00", "").split())
    if not text or len(text) > maximum or _SECRET_VALUE.search(text):
        raise ValueError("restricted_forensic_unsafe_text")
    return text


def _safe_answer(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("restricted_forensic_answer_invalid")
    if (not value.strip() or len(value) > MAX_ANSWER_CHARS or "\x00" in value
            or _SECRET_VALUE.search(value)):
        raise ValueError("restricted_forensic_answer_unsafe")
    return value


def _safe_code(value: Any) -> str:
    code = _safe_text(value, maximum=101)
    if not _CODE.fullmatch(code):
        raise ValueError("restricted_forensic_invalid_code")
    return code


def _safe_codes(values: Any) -> list[str]:
    if not isinstance(values, (list, tuple, set, frozenset)):
        raise ValueError("restricted_forensic_invalid_reason_codes")
    ordered = sorted(values, key=str) if isinstance(values, (set, frozenset)) else values
    result: list[str] = []
    seen: set[str] = set()
    for item in ordered:
        code = _safe_code(item)
        if code not in seen:
            result.append(code)
            seen.add(code)
    return result


def _safe_fact_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("restricted_forensic_non_finite_fact")
        return value
    if isinstance(value, str):
        return _safe_text(value)
    if isinstance(value, (list, tuple)):
        if len(value) > 20:
            raise ValueError("restricted_forensic_fact_list_too_large")
        return [_safe_fact_value(item) for item in value]
    return {"value_kind": type(value).__name__.lower(), "value_sha256": sha256(value)}


def _fact_summary(effective_facts: Any) -> list[dict[str, Any]]:
    if not isinstance(effective_facts, dict):
        return []
    return [
        {
            "field": _safe_code(field),
            "value_summary": _safe_fact_value(value),
            "source": "current_turn_extraction",
        }
        for field, value in sorted(effective_facts.items())
    ]


def _identifier_summary(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict) or not value.get("type"):
        return None
    result: dict[str, Any] = {"type": _safe_code(value["type"])}
    if value.get("status"):
        result["status"] = _safe_code(value["status"])
    return result


def _decision_package_summary(package: dict[str, Any]) -> dict[str, Any]:
    architecture = package.get("recommended_architecture")
    architecture = architecture if isinstance(architecture, dict) else {}
    segments = architecture.get("segments")
    segments = segments if isinstance(segments, dict) else {}
    segment_summary: dict[str, Any] = {}
    for name, raw_plan in sorted(segments.items()):
        plan = raw_plan if isinstance(raw_plan, dict) else {}
        recovery = plan.get("assisted_recovery")
        recovery = recovery if isinstance(recovery, dict) else {}
        fallback = plan.get("automated_fallback_credentials")
        fallback = fallback if isinstance(fallback, list) else []
        authorization = plan.get("authorization")
        authorization = authorization if isinstance(authorization, dict) else {}
        segment_summary[_safe_code(name)] = {
            "authorization_type": _safe_code(authorization["type"]) if authorization.get("type") else None,
            "primary_identifier": _identifier_summary(plan.get("primary_identifier")),
            "automated_fallback_types": [
                _safe_code(item["type"])
                for item in fallback
                if isinstance(item, dict) and item.get("type")
            ],
            "assisted_recovery_method": _safe_code(recovery["method"]) if recovery.get("method") else None,
        }
    options = package.get("primitive_option_assessments")
    options = options if isinstance(options, list) else []
    return {
        "schema_version": _safe_text(package.get("schema_version"), maximum=32),
        "decision_type": _safe_code(package.get("decision_type")),
        "architecture_type": _safe_code(architecture["architecture_type"]) if architecture.get("architecture_type") else None,
        "segments": segment_summary,
        "option_rankings": [
            {"option": _safe_code(item["option"]), "ordinal_rating": _safe_code(item["ordinal_rating"])}
            for item in options
            if isinstance(item, dict) and item.get("option") and item.get("ordinal_rating")
        ],
        "missing_critical_facts": _safe_codes(package.get("missing_critical_facts") or []),
        "reason_codes": _safe_codes(package.get("reason_codes") or []),
        "next_question": _safe_text(package["next_question"], maximum=1_000) if package.get("next_question") else None,
    }


def _mutation_summary(mutations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "mutation_id": _safe_text(item.get("mutation_id"), maximum=160),
            "target": _safe_code(item.get("target")),
            "operation": _safe_code(item.get("operation")),
            "field": _safe_code(item.get("field")),
            "value_kind": type(item.get("value")).__name__.lower(),
            "expected_state_version": int(item.get("expected_state_version", 0)),
            "proposed_state_version": int(item.get("proposed_state_version", 0)),
        }
        for item in mutations
    ]


def _assert_no_forbidden_material(value: Any, path: tuple[str, ...] = ()) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = str(key).casefold()
            if normalized in _FORBIDDEN_KEYS:
                raise ValueError(f"restricted_forensic_forbidden_key:{'.'.join((*path, normalized))}")
            _assert_no_forbidden_material(item, (*path, normalized))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            _assert_no_forbidden_material(item, (*path, str(index)))
    elif isinstance(value, str) and _SECRET_VALUE.search(value):
        raise ValueError("restricted_forensic_secret_material")


def build_blocked_turn_forensic(
    *, request_id: str, resolution: Any, effective_current_turn_facts: dict[str, Any],
    controller_decision: dict[str, Any], decision_package: dict[str, Any],
    decision_package_sha: str, projection_sha: str,
    raw_semantic_coverage: dict[str, Any], final_semantic_coverage: dict[str, Any],
    raw_answer: str, repaired_answer: str, repair_applied: bool,
    repair_method: str, repair_reason_codes: Any,
    raw_evaluation_status: str, raw_evaluation_reason_codes: Any,
    final_evaluation_status: str, final_evaluation_reason_codes: Any,
    state_mutations: list[dict[str, Any]], publication_candidate_status: str,
    executor_name: str, executor_request_count: int,
) -> dict[str, Any]:
    if publication_candidate_status == "allowed":
        raise ValueError("restricted_forensic_requires_blocked_candidate")
    if executor_name != "qwen" or executor_request_count != 1:
        raise ValueError("restricted_forensic_executor_contract_mismatch")
    requirements = getattr(resolution, "command_requirements", {}) or {}
    evidence = {
        "schema_version": RESTRICTED_FORENSIC_SCHEMA_VERSION,
        "ai_core_request_id": _safe_text(request_id, maximum=128),
        "runtime": {
            "version": RUNTIME_VERSION,
            "contract_sha": CONTRACT_TARGET_SHA,
            "canonicalization_version": CANONICALIZATION_VERSION,
        },
        "resolved": {
            "intent": _safe_code(getattr(resolution, "intent", "unknown")),
            "action": _safe_code(requirements.get("action_type") or "unknown"),
            "current_turn_facts_summary": _fact_summary(effective_current_turn_facts),
        },
        "controller": {
            "action": _safe_code(controller_decision.get("next_best_action") or "unknown"),
            "answer_required": bool(controller_decision.get("answer_required")),
            "question_required": bool(controller_decision.get("should_ask_question")),
        },
        "lab": {
            "decision_package_summary": _decision_package_summary(decision_package),
            "decision_package_sha": _safe_text(decision_package_sha, maximum=64),
        },
        "projection": {"sha": _safe_text(projection_sha, maximum=64)},
        "semantic_coverage": {
            "raw": copy.deepcopy(raw_semantic_coverage),
            "final": copy.deepcopy(final_semantic_coverage),
        },
        "executor": {
            "name": _safe_code(executor_name),
            "raw_answer": _safe_answer(raw_answer),
            "request_count": int(executor_request_count),
        },
        "repair": {
            "applied": bool(repair_applied),
            "method": _safe_code(repair_method),
            "repaired_answer": _safe_answer(repaired_answer),
            "reason_codes": _safe_codes(repair_reason_codes),
        },
        "evaluation": {
            "raw": {"status": _safe_code(raw_evaluation_status), "reason_codes": _safe_codes(raw_evaluation_reason_codes)},
            "final": {"status": _safe_code(final_evaluation_status), "reason_codes": _safe_codes(final_evaluation_reason_codes)},
        },
        "mutation": {"proposed": bool(state_mutations), "summary": _mutation_summary(state_mutations)},
        "publication": {
            "candidate_status": _safe_code(publication_candidate_status),
            "blocking_predicate": (
                "final_evaluation_status_must_equal_pass"
                if final_evaluation_status != "pass"
                else "publication_candidate_status_must_equal_allowed"
            ),
        },
    }
    _assert_no_forbidden_material(evidence)
    return evidence


def bind_runtime_release_identity(evidence: dict[str, Any], runtime_sha: str) -> dict[str, Any]:
    bound = copy.deepcopy(evidence)
    runtime = bound.get("runtime")
    if not isinstance(runtime, dict):
        raise ValueError("restricted_forensic_runtime_metadata_missing")
    if not re.fullmatch(r"[a-f0-9]{40}", runtime_sha):
        raise ValueError("restricted_forensic_runtime_sha_invalid")
    runtime["sha"] = runtime_sha
    bound["evidence_sha256"] = sha256(bound)
    _assert_no_forbidden_material(bound)
    return bound
