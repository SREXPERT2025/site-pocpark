from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Any

from .evaluation_integrity_v221 import COMPARATIVE_TERMS_RE
from .verbalization_semantics import (
    is_candidate_recommendation_context,
    operator_exception_only_preserved,
    recommendation_basis_present,
    recommendation_present,
)
from .site_contract_runtime_v1.canonical import canonical_sha256
from .non_engineering_evaluation import BUSINESS_OPENER_ACTION, CONVERSATIONAL_COURTESY_ACTION


V222_REASON_CODES = {
    "comparative_claim_requires_evidence",
    "comparative_claim_missing_conditions",
    "decision_relevant_claim_not_verified",
    "current_turn_ignored",
    "command_not_fulfilled",
    "unsatisfied_intent_not_recovered",
    "partially_useful",
    "too_generic",
    "reviewable_source_gap",
    "manual_recovery_misclassified_as_fallback_identifier",
    "fallback_not_segment_specific", "fallback_requires_unconfirmed_reader",
    "universal_operational_claim", "mixed_tradeoff_categories",
    "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
    "authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated",
    "evaluation_input_stage_mismatch",
}

OPTION_RE = re.compile(r"\b(?:госномер\w*|номер\w*|распознаван\w*|карт\w*|билет\w*|qr|радиомет\w*)\b", re.I)
CHOICE_RE = re.compile(r"\b(?:что|какой|какую)\s+(?:лучше\s+)?выбрать|\bчто\s+подойдет|\bпорекоменду", re.I)
COMPARISON_COMMAND_RE = re.compile(r"\b(?:сравни|отличи|разниц|чем\s+отлич)\w*", re.I)
ACK_RE = re.compile(r"\b(?:понимаю|согласен|спасибо|принял|справедлив|исправ|да[,!])\b", re.I)
NEGATIVE_FEEDBACK_RE = re.compile(r"\b(?:не\s+продажник|научил\w*\s+продавать|не\s+ответил|опять\s+не)\b", re.I)
CONDITION_RE = re.compile(r"\b(?:зависит|при\s+услов|если|обычно|может|в\s+зависимости|для\s+объект|при\s+поток)\b", re.I)
ADVISORY_BETTER_RE = re.compile(r"\b(?:лучше|выгоднее)\s+(?:рассматривать|проверить|уточнить)\b", re.I)
GENERIC_DEFERRAL_RE = re.compile(r"^(?:чтобы|для того чтобы|для)\s+ответить\s+точно.{0,120}(?:проверить|уточнить)", re.I)


@dataclass(frozen=True)
class BusinessEvaluationV222:
    status: str
    reason_codes: tuple[str, ...]
    decision_relevant_comparative_claims: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "automatic_business_status": self.status,
            "reason_codes": list(self.reason_codes),
            "decision_relevant_comparative_claims": list(self.decision_relevant_comparative_claims),
        }


def _sentences(text: str) -> list[str]:
    return [part.strip() for part in re.split(r"(?<=[.!?])\s+|\n+", text) if part.strip()]


def comparative_claims(answer: str) -> tuple[str, ...]:
    claims: list[str] = []
    for sentence in _sentences(answer):
        if not COMPARATIVE_TERMS_RE.search(sentence):
            continue
        if ADVISORY_BETTER_RE.search(sentence):
            continue
        if OPTION_RE.search(sentence) or re.search(r"функционально\s+это\s+одно\s+и\s+то\s+же", sentence, re.I):
            claims.append(sentence)
    return tuple(claims)


def _selection_requests(history: list[dict[str, Any]], message: str) -> int:
    messages = [str(item.get("content") or "") for item in history if item.get("role") == "user"]
    return sum(bool(CHOICE_RE.search(value)) for value in (*messages, message))


def _option_count(text: str) -> int:
    normalized: set[str] = set()
    for found in OPTION_RE.findall(text):
        value = found.casefold()
        if "карт" in value:
            normalized.add("card")
        elif "билет" in value:
            normalized.add("ticket")
        elif value == "qr":
            normalized.add("qr")
        elif "радиомет" in value:
            normalized.add("radio")
        else:
            normalized.add("lpr")
    return len(normalized)


def evaluate_business_status_v222(
    final_v22: dict[str, Any], *, customer_message: str, final_answer: str,
    history_before: list[dict[str, Any]] | None = None,
    evidence_refs: list[str] | tuple[str, ...] | None = None,
) -> BusinessEvaluationV222:
    """Четырёхстатусная бизнес-оценка без правил на идентификатор карточки."""
    history = list(history_before or [])
    message = " ".join(customer_message.casefold().split())
    answer = " ".join(final_answer.casefold().split())
    action = str(final_v22.get("action_type") or "answer_question")
    v22_reasons = set(final_v22.get("v22_reason_codes") or [])
    reasons: list[str] = []

    if not final_v22.get("context_complete", True):
        return BusinessEvaluationV222("not_evaluable", ())
    if not answer:
        return BusinessEvaluationV222("fail", ("command_not_fulfilled",))
    if "current_turn_ignored" in v22_reasons:
        return BusinessEvaluationV222("fail", ("current_turn_ignored",))
    if NEGATIVE_FEEDBACK_RE.search(message) and not ACK_RE.search(answer):
        return BusinessEvaluationV222("fail", ("current_turn_ignored",))

    if action in {CONVERSATIONAL_COURTESY_ACTION, BUSINESS_OPENER_ACTION}:
        evaluation = str(final_v22.get("evaluation_status") or "")
        if evaluation == "pass":
            return BusinessEvaluationV222("pass", ())
        courtesy_reasons = tuple(
            code for code in final_v22.get("v22_reason_codes") or ()
            if code.startswith("courtesy_")
            or code in {
                "unsupported_non_engineering_claim", "confirmed_context_contradicted",
                "unrequested_engineering_decision", "unsafe_non_engineering_content",
            }
        )
        return BusinessEvaluationV222(
            "fail", courtesy_reasons or ("command_not_fulfilled",),
        )

    requested_options = _option_count(message)
    answered_options = _option_count(answer)
    explicit_choice = bool(CHOICE_RE.search(message)) and requested_options >= 2
    explicit_comparison = bool(COMPARISON_COMMAND_RE.search(message))
    if (explicit_choice or explicit_comparison) and answered_options < 2:
        return BusinessEvaluationV222("fail", ("command_not_fulfilled",))
    if explicit_comparison and not (
        re.search(r"(?:скорост|удоб|над[её]ж|разниц|в отличие|но|при этом)", answer)
        or COMPARATIVE_TERMS_RE.search(answer)
    ):
        return BusinessEvaluationV222("fail", ("command_not_fulfilled",))
    if explicit_choice and GENERIC_DEFERRAL_RE.search(answer):
        return BusinessEvaluationV222("fail", ("command_not_fulfilled",))
    if explicit_choice and _selection_requests(history, customer_message) >= 3:
        changed_strategy = bool(re.search(r"\b(?:рекоменд|основн\w+\s+вариант|смешан\w+\s+схем|по\s+критери)\w*", answer))
        if not changed_strategy:
            return BusinessEvaluationV222("fail", ("unsatisfied_intent_not_recovered",))

    claims = comparative_claims(final_answer)
    if claims:
        has_evidence = bool(evidence_refs)
        reasons.extend(("comparative_claim_requires_evidence", "decision_relevant_claim_not_verified"))
        if any(not CONDITION_RE.search(claim) for claim in claims):
            reasons.append("comparative_claim_missing_conditions")
        if not has_evidence:
            return BusinessEvaluationV222("review_required", tuple(dict.fromkeys(reasons)), claims)

    evaluation = str(final_v22.get("evaluation_status") or "")
    review_reasons = {
        "summary_does_not_cover_conversation", "corporate_practice_not_verified",
        "corporate_practice_contradicted",
        "manual_recovery_misclassified_as_fallback_identifier",
        "fallback_not_segment_specific", "fallback_requires_unconfirmed_reader",
        "universal_operational_claim", "mixed_tradeoff_categories",
        "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
        "authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated",
        "missing_primary_identifier", "missing_required_segments", "missing_guest_authorization",
        "missing_assisted_recovery", "missing_fallback_semantics", "missing_required_tradeoff",
        "missing_unknown_conditionality", "missing_or_wrong_next_question",
    }
    if evaluation == "pass":
        return BusinessEvaluationV222("pass", ())
    matched_review_reasons = tuple(sorted(v22_reasons & review_reasons))
    if matched_review_reasons:
        return BusinessEvaluationV222("review_required", matched_review_reasons)

    topic = final_v22.get("topic_assessment") or {}
    context = final_v22.get("context_assessment") or {}
    on_topic = topic.get("result") == "pass" or context.get("uses_current_turn") == "pass"
    useful = len(answer.split()) >= 5 and (answered_options >= 1 or on_topic)
    if useful:
        reason = "too_generic" if len(answer.split()) < 18 else "partially_useful"
        return BusinessEvaluationV222("review_required", (reason,))
    return BusinessEvaluationV222("fail", ("command_not_fulfilled",))


def _sha256(value: Any) -> str:
    if isinstance(value, str):
        return hashlib.sha256(value.encode("utf-8", errors="strict")).hexdigest()
    return canonical_sha256(value)


def evaluate_forensic_v11(
    final_v22: dict[str, Any], *, customer_message: str, evaluated_answer: str,
    decision_package: dict[str, Any], evaluation_stage: str,
    expected_answer_hash: str | None = None,
) -> dict[str, Any]:
    """Объяснимая повторная оценка одного сохранённого ответа без вызова модели."""
    answer = " ".join(evaluated_answer.casefold().split())
    message = " ".join(customer_message.casefold().split())
    answer_hash = _sha256(evaluated_answer)
    package_hash = _sha256(decision_package)
    recommendation_match = re.search(
        r"\b(?:оптимальн\w*\s+(?:гибридн\w+|смешанн\w+)\s+схем\w*|"
        r"(?:мы\s+)?выбра\w*\b.{0,120}\bкак\s+основн\w+\s+(?:способ|вариант|решение|идентификатор)\w*|"
        r"основн\w+\s+(?:способ|вариант|решение)\w*\b.{0,90}\b(?:будет|явля\w*|служит|выступа\w*|можно)|"
        r"рекоменду\w*|предлага\w*|целесообразно\s+использовать|"
        r"можно\s+рассматривать\b.{0,90}\bкак\s+основн\w+\s+способ)", evaluated_answer, re.I,
    )
    recommendation_found = recommendation_present(evaluated_answer)
    recommendation_basis_match = re.search(
        r"\b(?:для\s+скорост\w*|потому\s+что|поскольку|так\s+как|с\s+уч[её]том|исходя\s+из|"
        r"при\s+заданн\w*|за\s+сч[её]т|приоритет\w*\s+скорост\w*|поток\w*|трафик\w*|"
        r"бесконтактн\w+\s+поток|"
        r"карты\s+и\s+билеты\s+создают[^.]+поэтому)\b",
        evaluated_answer, re.I,
    )
    package_why = list(decision_package.get("why") or ())
    package_basis_path = next(
        (f"$.why[{index}]" for index, value in enumerate(package_why)
         if re.search(r"скорост|приоритет|соответств", str(value), re.I)),
        None,
    )
    recommendation_basis_found = recommendation_basis_present(evaluated_answer) or recommendation_basis_match is not None or (
        recommendation_found and package_basis_path is not None
    )
    conditionality_match = re.search(
        r"\b(?:в\s+зависимости\s+от|зависит\s+от|при\s+условии|если|предварительно|может\s+формироваться|"
        r"после\s+(?:подтверждения|проверки)|до\s+подтверждения|нужно\s+подтвердить|"
        r"не\s+подтвержден\w*|не\s+выбран)\b",
        evaluated_answer, re.I,
    )
    conditionality_handled = conditionality_match is not None
    requested = {name for name, pattern in {
        "license_plate": r"номер", "card": r"карт", "ticket": r"билет", "qr": r"\bqr\b",
    }.items() if re.search(pattern, message, re.I)}
    covered = {name for name, pattern in {
        "license_plate": r"номер", "card": r"карт", "ticket": r"билет", "qr": r"\bqr\b",
    }.items() if re.search(pattern, answer, re.I)}
    current_turn_used = len(requested & covered) >= min(2, max(1, len(requested)))
    semantic_reasons = [
        code for code in final_v22.get("v22_reason_codes") or []
        if code in {
            "manual_recovery_misclassified_as_fallback_identifier",
            "fallback_not_segment_specific", "fallback_requires_unconfirmed_reader",
            "universal_operational_claim", "mixed_tradeoff_categories",
            "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
            "authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated",
            "operator_presented_as_required_for_normal_operation",
            "composite_architecture_ranked_as_primitive",
        }
    ]
    stage_matches = expected_answer_hash in (None, answer_hash)
    if not stage_matches:
        semantic_reasons.append("evaluation_input_stage_mismatch")

    def exact_evidence(match: re.Match[str] | None, rule_id: str) -> list[dict[str, Any]]:
        if match is None:
            return []
        return [{
            "evidence_type": "exact_text_span", "value": match.group(0),
            "start": match.start(), "end": match.end(), "source": "final_answer",
            "rule_id": rule_id,
        }]

    def package_evidence(path: str | None, value: Any, rule_id: str) -> list[dict[str, Any]]:
        if path is None:
            return []
        return [{
            "evidence_type": "decision_package_path", "value": value,
            "start": None, "end": None, "source": "decision_package",
            "rule_id": rule_id, "json_path": path,
        }]

    def semantic_evidence(intent: str, pattern: str, rule_id: str) -> list[dict[str, Any]]:
        match = re.search(pattern, evaluated_answer, re.I)
        if match is None:
            return []
        return [{
            "evidence_type": "semantic_match", "value": match.group(0),
            "start": match.start(), "end": match.end(), "source": "final_answer",
            "rule_id": rule_id, "matched_intent": intent, "text_fragment": match.group(0),
            "confidence": 1.0, "matcher_version": "deterministic-v1",
        }]

    basis_evidence = exact_evidence(recommendation_basis_match, "recommendation_basis_missing")
    if not basis_evidence and package_basis_path is not None:
        basis_evidence = package_evidence(
            package_basis_path, package_why[int(package_basis_path[6:-1])],
            "recommendation_basis_missing",
        )

    def rule(rule_id: str, expected: dict[str, Any], actual: dict[str, Any], matched: list[dict[str, Any]], missing: list[str], result: str, function: str) -> dict[str, Any]:
        return {
            "rule_id": rule_id,
            "evaluation_stage": evaluation_stage,
            "evaluated_text_hash": answer_hash,
            "decision_package_hash": package_hash,
            "expected": expected,
            "actual": actual,
            "matched_evidence": matched,
            "missing_evidence": missing,
            "source_file": "sales_conversation_controller/evaluation_integrity_v222.py",
            "source_function": function,
            "result": result,
        }

    traces = [
        rule("recommendation_missing", {"recommendation_present": True}, {"recommendation_present": recommendation_found}, exact_evidence(recommendation_match, "recommendation_missing"), [] if recommendation_found else ["recommendation_semantics"], "cleared" if recommendation_found else "confirmed", "evaluate_forensic_v11"),
        rule("recommendation_basis_missing", {"recommendation_basis_present": True}, {"recommendation_basis_present": recommendation_basis_found}, basis_evidence, [] if recommendation_basis_found else ["recommendation_basis"], "cleared" if recommendation_basis_found else "confirmed", "evaluate_forensic_v11"),
        rule("current_command_not_fulfilled", {"recommendation_command_fulfilled": True}, {"recommendation_command_fulfilled": recommendation_found and recommendation_basis_found}, semantic_evidence("requested_options_covered", r"(?:номер\w*|карт\w*|билет\w*)", "current_command_not_fulfilled"), sorted(requested - covered), "cleared" if recommendation_found and recommendation_basis_found else "confirmed", "evaluate_forensic_v11"),
        rule("current_turn_ignored", {"current_turn_used": True}, {"current_turn_used": current_turn_used}, semantic_evidence("current_turn_options_used", r"(?:номер\w*|карт\w*|билет\w*)", "current_turn_ignored"), sorted(requested - covered), "cleared" if current_turn_used else "confirmed", "evaluate_forensic_v11"),
        rule("conditionality_not_handled", {"conditionality_handled": evaluation_stage == "final"}, {"conditionality_handled": conditionality_handled}, exact_evidence(conditionality_match, "conditionality_not_handled"), [] if conditionality_handled or evaluation_stage != "final" else ["conditionality_marker"], "cleared" if conditionality_handled else "not_applicable" if evaluation_stage != "final" else "confirmed", "evaluate_forensic_v11"),
        rule("evaluation_input_stage_mismatch", {"expected_answer_hash": expected_answer_hash}, {"evaluated_answer_hash": answer_hash}, package_evidence("$.evaluated_answer_hash", answer_hash, "evaluation_input_stage_mismatch") if stage_matches else [], [] if stage_matches else [str(expected_answer_hash)], "cleared" if stage_matches else "confirmed", "evaluate_forensic_v11"),
    ]
    for code in semantic_reasons:
        if code == "evaluation_input_stage_mismatch":
            continue
        traces.append(rule(code, {"allowed": False}, {"detected": True}, package_evidence("$.reason_codes", code, code), [], "confirmed", "evaluate_forensic_v11"))
    no_stale_evidence_spans = all(
        evidence.get("evidence_type") != "exact_text_span"
        or evaluated_answer[evidence["start"]:evidence["end"]] == evidence["value"]
        for trace in traces for evidence in trace["matched_evidence"]
    )
    status = "fail" if not (recommendation_found and recommendation_basis_found and current_turn_used and stage_matches) else "review_required" if semantic_reasons else "pass"
    return {
        "evaluation_explain_mode": True,
        "evaluation_stage": evaluation_stage,
        "raw_answer_hash": answer_hash if evaluation_stage == "raw" else None,
        "repaired_answer_hash": answer_hash if evaluation_stage == "final" else None,
        "evaluated_answer_hash": answer_hash,
        "decision_package_hash": package_hash,
        "recommendation_present": recommendation_found,
        "recommendation_basis_present": recommendation_basis_found,
        "current_turn_used": current_turn_used,
        "current_command_fulfilled": recommendation_found and recommendation_basis_found,
        "conditionality_handled": conditionality_handled,
        "no_stale_evidence_spans": no_stale_evidence_spans,
        "reason_codes": list(dict.fromkeys(semantic_reasons)),
        "evaluation_status": status,
        "rule_traces": traces,
    }


def evaluate_forensic_v12(
    final_v22: dict[str, Any], *, customer_message: str, evaluated_answer: str,
    decision_package: dict[str, Any], expected_answer_hash: str | None = None,
) -> dict[str, Any]:
    """Оценивает исправленный кандидат V1.2 без наследования причин исходного ответа."""
    result = evaluate_forensic_v11(
        final_v22, customer_message=customer_message, evaluated_answer=evaluated_answer,
        decision_package=decision_package, evaluation_stage="final",
        expected_answer_hash=expected_answer_hash,
    )
    clean = " ".join(evaluated_answer.casefold().split())
    architecture_type = str(
        ((decision_package.get("recommended_architecture") or {}).get("architecture_type") or "")
    )
    next_question = str(decision_package.get("next_question") or "").strip()
    ontology_checks = {
        "guest_authorization_separate": bool(re.search(
            r"право\s+доступа.{0,60}гостев\w+\s+заявк\w*.{0,80}идентификац", clean, re.I,
        )),
        "operator_exception_only": operator_exception_only_preserved(clean),
        "universal_operational_claim_absent": not bool(re.search(
            r"карт\w*\s+или\s+билет\w*.{0,80}(?:высок\w*|больш\w*)\s+нагрузк", clean, re.I,
        )),
        "unconfirmed_reader_recommendation_absent": not any(
            is_candidate_recommendation_context(sentence)
            and bool(re.search(r"\b(?:qr|rfid|карт\w*|билет\w*)\b", sentence, re.I))
            for sentence in re.split(r"(?<=[.!?])\s+", clean)
        ),
        "segment_semantics_valid": all(term in clean for term in ("сотрудник", "арендатор", "гост")),
        "authorization_identifier_separated": bool(re.search(
            r"право\s+доступа.{0,120}идентификац", clean, re.I,
        )),
        "hybrid_semantics_valid": not (
            architecture_type != "hybrid_access" and bool(re.search(r"\bгибридн\w*", clean, re.I))
        ),
        "one_question_compliance": evaluated_answer.count("?") == 1 and (
            not next_question or next_question in evaluated_answer
        ),
    }
    inherited = list(final_v22.get("v22_reason_codes") or [])
    hard_ontology = {
        "operator_exception_only", "unconfirmed_reader_recommendation_absent",
        "hybrid_semantics_valid", "one_question_compliance",
    }
    failures = [name for name, passed in ontology_checks.items() if not passed]
    hard_failures = [name for name in failures if name in hard_ontology]
    review_failures = [name for name in failures if name not in hard_ontology]
    if not result.get("no_stale_evidence_spans", False):
        failures.append("stale_evidence_span")
    status = (
        "fail" if result["evaluation_status"] == "fail" or hard_failures
        else "review_required" if inherited or review_failures
        else "pass"
    )
    result.update({
        "schema_version": "EVALUATION_EXPLAIN_V1.2",
        "ontology_checks": ontology_checks,
        "inherited_original_reason_codes": [],
        "current_candidate_reason_codes": inherited,
        "ontology_failures": failures,
        "ontology_hard_failures": hard_failures,
        "ontology_review_findings": review_failures,
        "evaluation_status": status,
    })
    return result
