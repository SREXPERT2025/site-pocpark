from __future__ import annotations

from dataclasses import asdict, dataclass

from .non_engineering_evaluation import CONVERSATIONAL_COURTESY_ACTION


COURTESY_PROFILE = "courtesy"
UTILITY_PROFILE = "utility"
ENGINEERING_PROFILE = "engineering"
GENERAL_INFORMATION_PROFILE = "general_information"

ENGINEERING_RULE_GROUPS = (
    "engineering_tradeoffs",
    "segment_coverage",
    "operator_role",
    "guest_authorization",
    "fallback_architecture",
    "engineering_question_completeness",
)


@dataclass(frozen=True)
class EvaluationProfile:
    name: str
    applied_rule_groups: tuple[str, ...]
    skipped_rule_groups: tuple[str, ...]
    repair_profile: str

    def to_dict(self) -> dict:
        value = asdict(self)
        value["applied_rule_groups"] = list(self.applied_rule_groups)
        value["skipped_rule_groups"] = list(self.skipped_rule_groups)
        return value


def select_evaluation_profile(*, action_type: str, engineering_required: bool) -> EvaluationProfile:
    """Выбирает область проверки до evaluator и Response Repair."""
    if action_type == CONVERSATIONAL_COURTESY_ACTION:
        return EvaluationProfile(
            name=COURTESY_PROFILE,
            applied_rule_groups=(
                "answer_presence",
                "courtesy_relevance",
                "instruction_and_system_leakage",
                "unsupported_claims",
                "context_contradiction",
                "unrequested_engineering_decision",
                "courtesy_question_limit",
            ),
            skipped_rule_groups=ENGINEERING_RULE_GROUPS,
            repair_profile=COURTESY_PROFILE,
        )
    if action_type == "utility_request":
        return EvaluationProfile(
            name=UTILITY_PROFILE,
            applied_rule_groups=(
                "answer_presence",
                "current_turn_fulfilment",
                "instruction_and_system_leakage",
                "unsafe_content",
            ),
            skipped_rule_groups=ENGINEERING_RULE_GROUPS,
            repair_profile=UTILITY_PROFILE,
        )
    if engineering_required:
        return EvaluationProfile(
            name=ENGINEERING_PROFILE,
            applied_rule_groups=(
                "answer_presence",
                "current_turn_fulfilment",
                "instruction_and_system_leakage",
                *ENGINEERING_RULE_GROUPS,
            ),
            skipped_rule_groups=(),
            repair_profile=ENGINEERING_PROFILE,
        )
    return EvaluationProfile(
        name=GENERAL_INFORMATION_PROFILE,
        applied_rule_groups=(
            "answer_presence",
            "current_turn_fulfilment",
            "instruction_and_system_leakage",
            "unsupported_claims",
            "context_contradiction",
        ),
        skipped_rule_groups=ENGINEERING_RULE_GROUPS,
        repair_profile=GENERAL_INFORMATION_PROFILE,
    )
