from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Any

from .verbalization_semantics import operator_presented_as_automatic_fallback


@dataclass(frozen=True)
class VerbalizationFidelityResult:
    operator_semantic_violations: int
    unconfirmed_fallback_selections: int
    unknown_facts_promoted: int
    authorization_identifier_violations: int
    primary_architecture_changes: int
    new_engineering_decisions: int
    evidence_fragments: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["evidence_fragments"] = list(self.evidence_fragments)
        return value


def _sentences(text: str) -> list[str]:
    return [item.strip() for item in re.findall(r"[^.!?]+(?:[.!?]+|$)", str(text or "")) if item.strip()]


def _conditional_candidate(sentence: str) -> bool:
    return bool(re.search(
        r"(?:требует\s+подтверждения|нужно\s+подтвердить|после\s+подтверждения|"
        r"не\s+подтвержден|пока\s+не\s+выбран|оста[её]тся\s+(?:вариант|кандидат)|"
        r"рассматрива\w*\s+как\s+вариант|зависит\s+от\s+наличия)",
        sentence, re.I,
    ))


def evaluate_verbalization_fidelity(
    answer: str, decision_package: dict[str, Any] | None,
) -> VerbalizationFidelityResult:
    package = decision_package or {}
    sentences = _sentences(answer)
    evidence: list[str] = []
    operator_violations = int(operator_presented_as_automatic_fallback(answer))
    if operator_violations:
        evidence.extend(item for item in sentences if re.search(r"оператор|резерв", item, re.I))

    candidate_pattern = r"(?:карт\w*|билет\w*|\bqr\b|rfid|радиомет\w*)"
    fallback_pattern = (
        rf"(?:автоматическ\w*\s+)?резерв\w*[^.!?]{{0,70}}{candidate_pattern}|"
        rf"{candidate_pattern}[^.!?]{{0,70}}(?:автоматическ\w*\s+)?резерв\w*"
    )
    fallback_fragments = [
        sentence for sentence in sentences
        if re.search(fallback_pattern, sentence, re.I) and not _conditional_candidate(sentence)
    ]

    unknown_fragments = [
        sentence for sentence in sentences
        if re.search(
            r"(?:есть|установлен|имеется|подключен)[^.!?]{0,45}(?:считывател|rfid|qr)|"
            r"(?:считывател|rfid|qr)[^.!?]{0,45}(?:есть|установлен|имеется|подключен)",
            sentence, re.I,
        ) and not _conditional_candidate(sentence)
    ]
    authorization_fragments = [
        sentence for sentence in sentences
        if re.search(
            r"гостев\w+\s+заявк\w*[^.!?]{0,45}(?:явля\w*|служит|как)\s+идентификатор|"
            r"идентификац\w*\s+(?:через|по)\s+гостев\w+\s+заявк",
            sentence, re.I,
        )
    ]

    primary_is_lpr = any(
        (plan.get("primary_identifier") or {}).get("type") == "license_plate_recognition"
        for plan in ((package.get("recommended_architecture") or {}).get("segments") or {}).values()
    )
    primary_fragments = []
    if primary_is_lpr:
        primary_fragments = [
            sentence for sentence in sentences
            if re.search(r"(?:основн\w+\s+(?:решение|способ|вариант)|рекоменду\w*)", sentence, re.I)
            and re.search(candidate_pattern, sentence, re.I)
            and not re.search(r"распознаван\w*\s+(?:государственн\w*\s+)?номер|госномер", sentence, re.I)
            and not _conditional_candidate(sentence)
        ]

    evidence.extend((*fallback_fragments, *unknown_fragments, *authorization_fragments, *primary_fragments))
    unique_evidence = tuple(dict.fromkeys(evidence))
    count = (
        operator_violations + len(fallback_fragments) + len(unknown_fragments)
        + len(authorization_fragments) + len(primary_fragments)
    )
    return VerbalizationFidelityResult(
        operator_semantic_violations=operator_violations,
        unconfirmed_fallback_selections=len(fallback_fragments),
        unknown_facts_promoted=len(unknown_fragments),
        authorization_identifier_violations=len(authorization_fragments),
        primary_architecture_changes=len(primary_fragments),
        new_engineering_decisions=count,
        evidence_fragments=unique_evidence,
    )
