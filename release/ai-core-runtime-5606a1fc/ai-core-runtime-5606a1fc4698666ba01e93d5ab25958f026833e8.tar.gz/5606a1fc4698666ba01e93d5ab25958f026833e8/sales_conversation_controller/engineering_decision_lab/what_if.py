from __future__ import annotations

from dataclasses import replace
from typing import Any

from .decision_engine import EngineeringDecisionEngine
from .models import ProjectFacts, WhatIfResult


ALLOWED_CHANGES = {
    "daily_traffic", "peak_traffic", "free_parking_minutes", "operator_present",
    "consumables_priority", "staff_intervention_priority", "consumables_forbidden",
    "mandatory_fallback", "security_priority",
    "maintenance_staff_present", "user_segments", "unknown_plate_policy",
    "speed_priority", "existing_system", "modernization_or_new_build",
    "qr_reader_present", "card_reader_present", "rfid_reader_present", "ticket_reader_present",
    "guest_application_flow_confirmed", "guest_qr_delivery_confirmed",
    "guest_qr_binding_confirmed", "guest_qr_reuse_policy_confirmed",
    "guest_qr_expiry_confirmed",
}


class WhatIfEngine:
    def __init__(self, engine: EngineeringDecisionEngine | None = None) -> None:
        self.engine = engine or EngineeringDecisionEngine()

    def compare(self, facts: ProjectFacts | dict[str, Any], changes: dict[str, Any]) -> WhatIfResult:
        facts = ProjectFacts.from_dict(facts) if isinstance(facts, dict) else facts
        unknown = set(changes) - ALLOWED_CHANGES
        if unknown:
            raise ValueError(f"Неподдерживаемые what-if изменения: {sorted(unknown)}")
        before = self.engine.decide(facts)
        updated = replace(facts, **changes)
        after = self.engine.decide(updated)
        reasons = tuple(f"Изменено подтверждённое поле {key}: {value}" for key, value in changes.items())
        return WhatIfResult(
            changed_facts=dict(changes), previous_architecture=before.recommended_architecture,
            new_architecture=after.recommended_architecture,
            architecture_changed=before.recommended_architecture != after.recommended_architecture,
            changed_reasons=reasons, decision=after,
        )
