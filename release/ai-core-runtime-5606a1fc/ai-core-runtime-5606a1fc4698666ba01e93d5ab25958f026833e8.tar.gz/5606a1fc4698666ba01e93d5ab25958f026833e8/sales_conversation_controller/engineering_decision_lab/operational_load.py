from __future__ import annotations

from .models import ProjectFacts


class OperationalLoadEstimator:
    def assess(self, option: str, facts: ProjectFacts) -> dict[str, object]:
        staff = "low"
        service = "low"
        consumables = "none"
        reasons: list[str] = []
        assumptions: list[str] = []
        ranges: dict[str, object] = {}
        if option == "parking_card":
            staff, service, consumables = "high", "medium", "reusable"
            reasons.append("Карты требуют возврата, переноса и сортировки.")
            if facts.card_return_process is None:
                assumptions.append("Процесс возврата и переноса карт не подтверждён.")
        elif option == "parking_ticket":
            staff, service, consumables = "medium", "medium", "continuous"
            reasons.append("Билеты требуют пополнения рулона и создают постоянный расход.")
            if facts.daily_traffic is not None and facts.ticket_user_share is not None:
                daily_uses = facts.daily_traffic * facts.ticket_user_share
                if daily_uses > 0:
                    ranges["replacement_interval_days_orientation"] = round(2000 / daily_uses, 1)
                    assumptions.append("Расчёт использует owner-confirmed ориентир 2000 билетов на рулон и подтверждённую долю билетных пользователей.")
            else:
                assumptions.append("Нельзя рассчитывать частоту замены без суточного потока и доли билетных пользователей.")
        elif option == "license_plate_recognition":
            service = "medium"
            reasons.append("Камеры требуют контроля условий обзора и резервного сценария.")
        elif option == "guest_qr":
            service = "low"
            reasons.append("Нагрузка зависит от способа выдачи и проверки QR-кода.")
        elif option == "radio_tag":
            staff, service = "medium", "low"
            reasons.append("Радиометки нужно выдавать и учитывать.")
        elif option == "operator_assisted_access":
            staff, service = "high", "low"
            reasons.append("Ручной допуск зависит от доступности и полномочий оператора.")
            if facts.operator_present is not True:
                reasons.append("Постоянное присутствие оператора не подтверждено.")
        elif option == "hybrid_access":
            staff, service, consumables = "medium", "high", "conditional"
            reasons.append("Смешанная схема повышает устойчивость, но увеличивает число обслуживаемых компонентов.")
        if facts.operator_present is False and staff == "high":
            reasons.append("Отсутствие оператора усиливает эксплуатационный риск.")
        return {
            "staff_load": staff, "service_load": service, "consumables": consumables,
            "entry_speed": "contactless_or_short_stop" if option in {"license_plate_recognition", "radio_tag"} else "stop_required",
            "exit_speed": "policy_dependent",
            "reasons": reasons, "assumptions": assumptions, "range": ranges or None,
        }
