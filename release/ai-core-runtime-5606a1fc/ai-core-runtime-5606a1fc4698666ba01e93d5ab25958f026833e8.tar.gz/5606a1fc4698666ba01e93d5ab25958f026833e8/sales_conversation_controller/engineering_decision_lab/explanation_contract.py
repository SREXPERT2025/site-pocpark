from __future__ import annotations

from .models import DecisionPackage


class ExplanationContract:
    FORBIDDEN = (
        "карты только для постоянных", "билеты всегда лучше для разовых",
        "билеты всегда дешевле", "распознавание номеров всегда достаточно",
        "qr или оператор", "карта или оператор", "билет или оператор", "rfid или оператор",
        "карты или билеты создают высокую нагрузку",
    )

    def validate(self, package: DecisionPackage) -> None:
        if package.decision_type != "access_identifier_selection":
            raise ValueError("Поддерживается только access_identifier_selection")
        segments = package.recommended_architecture.get("segments") or {}
        if not segments:
            raise ValueError("Нужен хотя бы один сегментный план доступа")
        if not any(value.get("primary_identifier") for value in segments.values()) and package.confidence >= .4:
            raise ValueError("Без основного идентификатора confidence должен быть ниже 0.4")
        for name, plan in segments.items():
            automated = set(plan.get("automated_fallback_identifiers") or [])
            if "operator_assisted_access" in automated or "operator_verification" in automated:
                raise ValueError(f"Оператор ошибочно указан автоматическим резервом для {name}")
            recovery = plan.get("assisted_recovery")
            if recovery and recovery.get("usage") != "exception_only":
                raise ValueError(f"Ручная обработка должна быть только исключением для {name}")
            if not plan.get("failure_policy"):
                raise ValueError(f"Не задана политика отказа для {name}")
        if len([package.next_question] if package.next_question else []) > 1:
            raise ValueError("Допускается только один следующий вопрос")
        combined = " ".join((*package.why, *package.tradeoffs)).lower()
        if any(text in combined for text in self.FORBIDDEN):
            raise ValueError("Обнаружено безусловное запрещённое правило")
        if package.missing_critical_facts and not package.next_question:
            raise ValueError("При нехватке данных нужен один следующий вопрос")
