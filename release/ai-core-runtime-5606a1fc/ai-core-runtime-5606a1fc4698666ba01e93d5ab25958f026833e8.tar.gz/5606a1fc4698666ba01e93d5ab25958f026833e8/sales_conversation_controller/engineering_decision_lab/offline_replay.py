from __future__ import annotations

import html
import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from ..context_integrity_v22 import ContextIntentIntegrityLayerV22, IntegrityState
from ..contracts import ControllerInput, LeadCard
from ..controller import SalesConversationController
from .integration import ELIGIBLE_ACTIONS, EngineeringDecisionLabIntegration
from .models import ALLOWED_FACT_FIELDS
from .schema_validation import validate_json_schema


WORD_NUMBER = {"один": 1, "одна": 1, "два": 2, "две": 2, "три": 3, "четыре": 4}
OBJECT_TYPES = {
    "бизнес-центр": "business_center", "бизнес центр": "business_center",
    "торговый центр": "shopping_center", "трц": "shopping_center",
    "жилой комплекс": "residential_complex", "жк": "residential_complex",
    "склад": "warehouse",
}
FORBIDDEN_SIMPLIFICATIONS = (
    "карты только для постоянных", "билеты всегда лучше для разовых",
    "билеты всегда дешевле", "распознавание номеров всегда достаточно",
)


@dataclass
class ReplayConversationState:
    integrity: IntegrityState = field(default_factory=IntegrityState)
    history: list[dict[str, str]] = field(default_factory=list)
    project_facts: dict[str, Any] = field(default_factory=lambda: {"confirmed_sources": {}, "conflicts": {}})
    asked_questions: list[str] = field(default_factory=list)
    lead_card: LeadCard = field(default_factory=LeadCard)


def _number(value: str) -> int | None:
    return int(value) if value.isdigit() else WORD_NUMBER.get(value.casefold())


def _set_confirmed(state: ReplayConversationState, field_name: str, value: Any, message_id: str) -> None:
    current = state.project_facts.get(field_name)
    if current not in (None, (), [], value):
        state.project_facts.setdefault("conflicts", {}).setdefault(field_name, [])
        conflict = state.project_facts["conflicts"][field_name]
        for candidate in (current, value):
            record = {"value": candidate, "source_message_id": message_id}
            if record not in conflict:
                conflict.append(record)
        return
    state.project_facts[field_name] = value
    state.project_facts.setdefault("confirmed_sources", {})[field_name] = {
        "status": "confirmed", "source_message_id": message_id,
    }


def ingest_confirmed_facts(state: ReplayConversationState, message: str, message_id: str) -> list[str]:
    text = " ".join(message.casefold().replace("ё", "е").split())
    added: list[str] = []
    for token, canonical in OBJECT_TYPES.items():
        if token in text:
            _set_confirmed(state, "object_type", canonical, message_id)
            added.append("object_type")
    patterns = {
        "entrances_count": r"\b(\d+|один|одна|два|две|три|четыре)\s+въезд",
        "exits_count": r"\b(\d+|один|одна|два|две|три|четыре)\s+выезд",
        "daily_traffic": r"\b(?:около\s+)?(\d{2,6})\s+(?:автомобил\w*|машин\w*)\s+в\s+день",
        "entry_price_rub": r"\b(?:въезд\s+стоит|платит\w*)\s+(\d+)\s*руб",
    }
    for field_name, pattern in patterns.items():
        found = re.search(pattern, text)
        if found:
            value = _number(found.group(1))
            if value is not None:
                _set_confirmed(state, field_name, value, message_id)
                added.append(field_name)
    free = re.search(r"\b(\d+)\s*(минут\w*|час\w*)\s+бесплат", text)
    if free:
        value = int(free.group(1)) * (60 if free.group(2).startswith("час") else 1)
        _set_confirmed(state, "free_parking_minutes", value, message_id)
        added.append("free_parking_minutes")
    if re.search(r"\b(?:без|нет|не будет)\s+(?:постоянн\w+\s+)?оператор", text):
        _set_confirmed(state, "operator_present", False, message_id)
        added.append("operator_present")
    elif re.search(r"\b(?:есть|будет)\s+(?:постоянн\w+\s+)?оператор", text):
        _set_confirmed(state, "operator_present", True, message_id)
        added.append("operator_present")
    segments = set(state.project_facts.get("user_segments") or [])
    before_segments = set(segments)
    for pattern, segment in ((r"сотрудник", "employee"), (r"арендатор", "tenant"), (r"гост", "guest"), (r"разов", "occasional"), (r"жител|резидент", "resident")):
        if re.search(pattern, text):
            segments.add(segment)
    if segments != before_segments:
        _set_confirmed(state, "user_segments", sorted(segments), message_id)
        added.append("user_segments")
    if re.search(r"\b(?:главное|важно).{0,30}(?:скорост|очеред)", text):
        _set_confirmed(state, "speed_priority", "high", message_id)
        added.append("speed_priority")
    if re.search(r"\b(?:без\s+расходник|расходники\s+запрещены|не\s+хотим\s+бумагу)", text):
        _set_confirmed(state, "consumables_forbidden", True, message_id)
        added.append("consumables_forbidden")
    if re.search(r"\b(?:нужен|обязателен|требуется)\s+резерв", text):
        _set_confirmed(state, "mandatory_fallback", True, message_id)
        added.append("mandatory_fallback")
    if re.search(r"\b(?:неизвестн\w+|нераспознанн\w+)\s+номер.{0,30}(?:не\s+пропуск|запрещ)", text):
        _set_confirmed(state, "unknown_plate_policy", "deny", message_id)
        added.append("unknown_plate_policy")
    if "оплат" in text:
        _set_confirmed(state, "payment_scenario", "paid_access", message_id)
        added.append("payment_scenario")
    state.project_facts["confirmed_sources"] = dict(state.project_facts.get("confirmed_sources") or {})
    return sorted(set(added))


def classify_lab_action(message: str, base_action: str, controller_action: str) -> str:
    text = " ".join(message.casefold().split())
    if base_action in {"utility_request", "provide_contact", "provide_link", "remember_fact", "recall_facts"}:
        return base_action
    if re.search(r"\b(?:риск|грязн\w+\s+номер|не\s+распозна|сбой|резерв|отказ|пропадет\s+(?:связь|питание))\w*", text):
        return "risk_question"
    if re.search(r"\b(?:окупа|tco|совокупн\w+\s+стоимост)\w*", text):
        return "roi_question"
    if re.search(r"\b(?:техническ\w+\s+обслужив|\bто\b|рулон|диспенсер|сколько\s+карт|эксплуатац)\w*", text):
        return "operational_question"
    if base_action == "conversation_summary":
        return "conversation_summary"
    if base_action in {"compare_options", "recommend_solution"}:
        return base_action
    if re.search(r"\b(?:что\s+выбрать|что\s+подойдет|что\s+лучше|порекоменду)\w*", text):
        return "configuration_selection"
    if base_action == "propose_next_step" or controller_action in {"offer_calculation", "prepare_handoff", "offer_human_contact"}:
        return "propose_next_step"
    return base_action


def validate_decision_package(payload: dict[str, Any]) -> list[str]:
    schema_name = {
        "1.2": "decision-package-v1.2.schema.json",
        "1.1": "decision-package-v1.1.schema.json",
    }.get(payload.get("schema_version"), "decision-package.schema.json")
    schema = Path(__file__).resolve().parent / f"schemas/{schema_name}"
    errors = validate_json_schema(payload, schema)
    question = payload.get("next_question")
    if isinstance(question, str) and question.count("?") > 1:
        errors.append("$.next_question:one_question")
    return errors


def render_manual_review(rows: Iterable[dict[str, Any]]) -> str:
    cards = []
    for row in rows:
        package = row.get("decision_package") or {}
        cards.append(f"""
<article class="card">
  <h2>Случай {html.escape(str(row['priority_review_number']))}: {html.escape(row['selection_reason'])}</h2>
  <h3>История</h3><pre>{html.escape(json.dumps(row['history_before'], ensure_ascii=False, indent=2))}</pre>
  <h3>Реплика клиента</h3><p>{html.escape(row['customer_message'])}</p>
  <h3>Подтверждённые факты</h3><pre>{html.escape(json.dumps(row['project_facts'], ensure_ascii=False, indent=2))}</pre>
  <h3>Профиль целей</h3><pre>{html.escape(json.dumps(package.get('objective_profile', {}), ensure_ascii=False, indent=2))}</pre>
  <h3>Решение контроллера</h3><pre>{html.escape(json.dumps(row['controller_decision'], ensure_ascii=False, indent=2))}</pre>
  <h3>Пакет решения</h3><pre>{html.escape(json.dumps(package, ensure_ascii=False, indent=2))}</pre>
  <h3>Допущения и пропущенные факты</h3><pre>{html.escape(json.dumps({'assumptions': package.get('assumptions', []), 'missing': row.get('missing_facts', [])}, ensure_ascii=False, indent=2))}</pre>
  <h3>Сегментные планы / аварийный режим / следующий вопрос</h3><pre>{html.escape(json.dumps({'segments': package.get('recommended_architecture', {}).get('segments', {}), 'emergency_override': package.get('recommended_architecture', {}).get('emergency_override'), 'candidate_options': package.get('candidate_options', []), 'next_question': row.get('next_question')}, ensure_ascii=False, indent=2))}</pre>
  <h3>Коды причин</h3><pre>{html.escape(json.dumps(row.get('reason_codes', []), ensure_ascii=False, indent=2))}</pre>
</article>""")
    return """<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Офлайн-проверка инженерной лаборатории</title><style>body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:1180px;margin:24px auto;background:#f4f6f8;color:#17202a}.card{background:white;border:1px solid #d9e0e7;border-radius:14px;padding:20px;margin:18px 0}pre{white-space:pre-wrap;background:#f7f9fb;padding:12px;border-radius:8px}h2{color:#174a7e}</style></head><body><h1>15 приоритетных случаев: Controller + Engineering Decision Laboratory</h1>""" + "".join(cards) + "</body></html>"
