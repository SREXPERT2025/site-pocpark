from __future__ import annotations

from .models import ObjectiveProfile, ProjectFacts


def _weight(value: str | None, *, default: float = 1.0) -> float:
    return {"high": 2.0, "medium": 1.0, "low": .4}.get(str(value or "").lower(), default)


class ObjectiveResolver:
    def resolve(self, facts: ProjectFacts) -> ObjectiveProfile:
        evidence: list[str] = []
        if facts.speed_priority:
            evidence.append("speed_priority")
        if facts.security_priority:
            evidence.append("security_priority")
        if facts.consumables_priority:
            evidence.append("consumables_priority")
        if facts.staff_intervention_priority:
            evidence.append("staff_intervention_priority")
        if facts.advertising_priority:
            evidence.append("advertising_priority")
        weights = {
            "throughput": _weight(facts.speed_priority),
            "reliability": 1.6 if facts.mandatory_fallback else 1.0,
            "staff_workload": _weight(facts.staff_intervention_priority),
            "consumables": 3.0 if facts.consumables_forbidden else _weight(facts.consumables_priority),
            "security": _weight(facts.security_priority),
            "advertising": _weight(facts.advertising_priority, default=0.0),
        }
        objective_candidates = [
            ("maximize_security", weights["security"]),
            ("minimize_consumables", weights["consumables"]),
            ("minimize_staff_interventions", weights["staff_workload"]),
            ("maximize_throughput", weights["throughput"]),
            ("maximize_reliability", weights["reliability"]),
            ("monetize_advertising_media", weights["advertising"]),
        ]
        ranked = sorted(objective_candidates, key=lambda item: (-item[1], objective_candidates.index(item)))
        primary = ranked[0][0] if ranked[0][1] > 1.0 else "balanced_solution"
        secondary = tuple(name for name, weight in ranked[1:] if weight > 1.0)
        constraints = tuple(
            name for name, active in (
                ("no_dedicated_parking_operator", facts.operator_present is False),
                ("no_consumables", facts.consumables_forbidden is True),
                ("strict_unknown_plate_rejection", facts.unknown_plate_policy == "deny"),
            ) if active
        )
        return ObjectiveProfile(
            speed=_weight(facts.speed_priority),
            reliability=1.6 if facts.mandatory_fallback else 1.0,
            staff_load=_weight(facts.staff_intervention_priority),
            consumables=3.0 if facts.consumables_forbidden else _weight(facts.consumables_priority),
            security=_weight(facts.security_priority),
            advertising=_weight(facts.advertising_priority, default=0.0),
            evidence=tuple(evidence),
            primary_objective=primary,
            secondary_objectives=secondary,
            constraints=constraints,
            weights=weights,
        )
