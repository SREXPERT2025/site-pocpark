from __future__ import annotations


EVIDENCE = {
    "ticket_roll_typical_capacity": "knowledge_base/engineering/rospark_engineering_experience.md#ticket_roll_typical_capacity",
    "card_dispenser_typical_capacity": "knowledge_base/engineering/rospark_engineering_experience.md#parking_card_dispenser_typical_capacity",
    "parking_card_operational_properties": "knowledge_base/engineering/rospark_engineering_experience.md#parking_card_operational_properties",
    "parking_card_advertising": "knowledge_base/engineering/rospark_engineering_experience.md#parking_card_advertising",
    "lpr_speed_conditional": "knowledge_base/engineering/parking_solution_decision_framework.md#варианты-идентификации",
    "automated_fallback_vs_assisted_recovery": "knowledge_base/engineering/automated_fallback_vs_assisted_recovery.md",
}


class EvidenceGate:
    def validate_refs(self, refs: list[str] | tuple[str, ...]) -> tuple[str, ...]:
        unknown = [ref for ref in refs if ref not in EVIDENCE]
        if unknown:
            raise ValueError(f"Неподтверждённые ссылки на знания: {unknown}")
        return tuple(EVIDENCE[ref] for ref in refs)
