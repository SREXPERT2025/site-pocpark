from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _matches_type(value: Any, expected: str) -> bool:
    return {
        "null": value is None,
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "boolean": isinstance(value, bool),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "number": isinstance(value, (int, float)) and not isinstance(value, bool),
    }.get(expected, True)


def validate_json_schema(value: Any, schema_path: Path) -> list[str]:
    root = schema_path.parent
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors: list[str] = []

    def check(current: Any, rule: dict[str, Any], location: str) -> None:
        if "$ref" in rule:
            referenced = json.loads((root / rule["$ref"]).read_text(encoding="utf-8"))
            check(current, referenced, location)
            return
        expected = rule.get("type")
        if expected is not None:
            types = expected if isinstance(expected, list) else [expected]
            if not any(_matches_type(current, candidate) for candidate in types):
                errors.append(f"{location}:type")
                return
        if "const" in rule and current != rule["const"]:
            errors.append(f"{location}:const")
        if "enum" in rule and current not in rule["enum"]:
            errors.append(f"{location}:enum")
        if isinstance(current, (int, float)) and not isinstance(current, bool):
            if "minimum" in rule and current < rule["minimum"]:
                errors.append(f"{location}:minimum")
            if "maximum" in rule and current > rule["maximum"]:
                errors.append(f"{location}:maximum")
        if isinstance(current, dict):
            required = set(rule.get("required") or [])
            missing = required - set(current)
            errors.extend(f"{location}.{key}:required" for key in sorted(missing))
            properties = rule.get("properties") or {}
            if rule.get("additionalProperties") is False:
                errors.extend(f"{location}.{key}:additional" for key in sorted(set(current) - set(properties)))
            for key, child in current.items():
                if key in properties:
                    check(child, properties[key], f"{location}.{key}")
                elif isinstance(rule.get("additionalProperties"), dict):
                    check(child, rule["additionalProperties"], f"{location}.{key}")
        if isinstance(current, list):
            if len(current) < int(rule.get("minItems") or 0):
                errors.append(f"{location}:minItems")
            if "maxItems" in rule and len(current) > int(rule["maxItems"]):
                errors.append(f"{location}:maxItems")
            if rule.get("uniqueItems") and len({json.dumps(item, ensure_ascii=False, sort_keys=True) for item in current}) != len(current):
                errors.append(f"{location}:uniqueItems")
            if isinstance(rule.get("items"), dict):
                for index, child in enumerate(current):
                    check(child, rule["items"], f"{location}[{index}]")

    check(value, schema, "$")
    return errors
