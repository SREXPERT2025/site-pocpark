from __future__ import annotations

from .models import ProjectFacts


QUESTIONS = (
    ("user_segments", "Какие группы будут пользоваться парковкой: сотрудники, арендаторы, гости или разовые посетители?"),
    ("entrances_count", "Сколько въездов нужно оборудовать?"),
    ("exits_count", "Сколько выездов нужно оборудовать?"),
    ("daily_traffic", "Какой ожидается средний суточный поток автомобилей?"),
    ("peak_traffic", "Какой поток ожидается в наиболее загруженный час?"),
    ("operator_present", "Будет ли на объекте постоянно присутствовать оператор?"),
    ("maintenance_staff_present", "Есть ли на объекте сотрудник, который сможет обслуживать стойки и носители?"),
    ("payment_scenario", "Как должен быть организован платный проезд и подтверждение оплаты?"),
    ("speed_priority", "Что важнее для объекта: максимальная скорость проезда или минимальная стоимость эксплуатации?"),
    ("free_parking_minutes", "Предусмотрен ли бесплатный период и сколько минут он составляет?"),
    ("object_type", "Какой тип объекта планируется автоматизировать?"),
    ("existing_system", "Какая система и оборудование уже установлены на объекте?"),
    ("modernization_or_new_build", "Существующую парковку нужно модернизировать или система создаётся с нуля?"),
    ("security_priority", "Как должна работать система, если номер автомобиля не распознан?"),
    ("mandatory_fallback", "Обязателен ли автоматический резервный способ проезда?"),
    ("weather_exposure", "Въезды находятся на открытом воздухе или в крытой зоне?"),
    ("space_for_entry_station", "Есть ли место для стойки выдачи носителя на въезде?"),
    ("interfaces_compatible", "Подтверждена ли совместимость существующего оборудования с планируемыми интерфейсами?"),
    ("ticket_user_share", "Какая доля потока будет использовать билеты?"),
    ("card_return_process", "Кто будет возвращать и переносить карты между выездом и въездом?"),
)


class QuestionPlanner:
    V12_QUESTIONS = (
        {
            "question_id": "existing_system_or_new_build",
            "question": "Парковочная система уже установлена или проектируется с нуля?",
            "fields": ("existing_system", "modernization_or_new_build"),
            "question_information_gain": 1.0, "question_prerequisite": None,
        },
        {
            "question_id": "installed_identifiers_and_readers",
            "question": "Какие идентификаторы и считыватели уже используются?",
            "fields": ("card_reader_present", "rfid_reader_present", "qr_reader_present", "ticket_reader_present"),
            "question_information_gain": .9, "question_prerequisite": "existing_system_confirmed",
        },
        {
            "question_id": "acceptable_automatic_fallbacks",
            "question": "Какие автоматические резервные сценарии вы считаете допустимыми?",
            "fields": ("mandatory_fallback",),
            "question_information_gain": .75, "question_prerequisite": "new_build_confirmed",
        },
    )

    def missing_critical_facts(self, facts: ProjectFacts) -> tuple[str, ...]:
        missing = []
        for field, _question in QUESTIONS:
            value = getattr(facts, field)
            if value is None or value == ():
                missing.append(field)
        if facts.mandatory_fallback and not any(value is True for value in (
            facts.qr_reader_present, facts.card_reader_present,
            facts.rfid_reader_present, facts.ticket_reader_present,
        )):
            missing.append("fallback_reader_infrastructure")
        return tuple(missing)

    def next_question(self, facts: ProjectFacts, asked_questions: tuple[str, ...] | list[str] = ()) -> str | None:
        missing = set(self.missing_critical_facts(facts))
        asked = {" ".join(value.casefold().split()) for value in asked_questions}
        infrastructure_question = "Какие считыватели уже предусмотрены: для карт, RFID, QR или билетов?"
        if (
            "fallback_reader_infrastructure" in missing
            and " ".join(infrastructure_question.casefold().split()) not in asked
        ):
            return infrastructure_question
        return next((question for field, question in QUESTIONS if field in missing and " ".join(question.casefold().split()) not in asked), None)

    def missing_critical_facts_v12(self, facts: ProjectFacts) -> tuple[str, ...]:
        missing = [
            field for field in (
                "existing_system", "modernization_or_new_build", "security_priority",
                "payment_scenario", "peak_traffic",
            ) if getattr(facts, field) is None
        ]
        if not any(getattr(facts, field) is not None for field in (
            "card_reader_present", "rfid_reader_present", "qr_reader_present", "ticket_reader_present",
        )):
            missing.append("fallback_reader_infrastructure")
        return tuple(missing)

    def rank_questions_v12(
        self, facts: ProjectFacts, asked_questions: tuple[str, ...] | list[str] = (),
        *, include_dependency_semantics: bool = False,
    ) -> list[dict[str, object]]:
        asked = {" ".join(value.casefold().split()) for value in asked_questions}
        dependencies = self.dependency_semantics_v12(facts)
        existing_known = (
            dependencies["new_build_confirmed"]
            or dependencies["existing_system_confirmed"]
        )
        result = []
        for item in self.V12_QUESTIONS:
            prerequisite = item["question_prerequisite"]
            if prerequisite is None:
                applicable = not existing_known
            elif prerequisite == "new_build_confirmed":
                applicable = (
                    dependencies[prerequisite]
                    and facts.mandatory_fallback is True
                )
            elif prerequisite in dependencies:
                applicable = dependencies[prerequisite] and not any(
                    getattr(facts, field) is not None for field in item["fields"]
                )
            else:
                applicable = False
            question = str(item["question"])
            ranked_item = {
                **item, "fields": list(item["fields"]), "applicable": applicable,
                "already_asked": " ".join(question.casefold().split()) in asked,
                "question_not_yet_applicable": not applicable and not all(getattr(facts, field) is not None for field in item["fields"]),
                "question_dependency_graph": ([prerequisite] if prerequisite else []),
            }
            if include_dependency_semantics:
                ranked_item.update({
                    "question_dependency_satisfied": (
                    True if prerequisite is None else dependencies.get(prerequisite, False)
                    ),
                    "dependency_semantics": dict(dependencies),
                })
            result.append(ranked_item)
        return sorted(result, key=lambda value: (-float(value["question_information_gain"]), str(value["question_id"])))

    @staticmethod
    def dependency_semantics_v12(facts: ProjectFacts) -> dict[str, bool]:
        """Взаимоисключающие признаки нового и существующего объекта."""
        new_build_confirmed = (
            facts.modernization_or_new_build in {"new_build", "new", "from_scratch"}
            or facts.existing_system in {"none", "new_build"}
        )
        existing_system_confirmed = (
            not new_build_confirmed
            and (
                facts.modernization_or_new_build in {"modernization", "existing"}
                or facts.existing_system not in (None, "none", "new_build")
            )
        )
        return {
            "new_build_confirmed": new_build_confirmed,
            "existing_system_confirmed": existing_system_confirmed,
        }
