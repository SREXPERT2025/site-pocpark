from __future__ import annotations

from .models import ProjectFacts


class TotalCostOfOwnershipModel:
    EVIDENCE = {
        "ticket_roll_typical_capacity": "Ориентир около 2000 билетов на рулон; фактическое значение зависит от длины билета и печати.",
        "card_dispenser_typical_capacity": "Ориентир 450–500 карт; паспорт конкретной модели имеет приоритет.",
    }

    def factors(self, option: str, facts: ProjectFacts) -> dict[str, object]:
        result: dict[str, object] = {
            "relative_consumables": "low", "requires_price_inputs": True, "evidence_refs": [],
            "horizons": ["purchase", "monthly_operations", "annual_operations", "multi_year_ownership"],
            "drivers": ["capex", "personnel_labor", "preventive_maintenance", "corrective_maintenance", "downtime"],
            "missing_inputs": ["equipment_prices", "labor_cost", "maintenance_cost", "downtime_cost"],
            "winner": "unknown", "assumptions": [],
        }
        if option == "parking_ticket":
            result.update(relative_consumables="high", capacity_orientation=2000)
            result["evidence_refs"] = ["ticket_roll_typical_capacity"]
        elif option == "parking_card":
            result.update(relative_consumables="medium", reusable=True, capacity_orientation="450-500")
            result["evidence_refs"] = ["card_dispenser_typical_capacity"]
            if facts.advertising_priority == "high":
                result["advertising_value"] = "possible"
                result["assumptions"].append("Рекламная компенсация не считается гарантированным доходом без согласованной величины.")
        elif option in {"license_plate_recognition", "guest_qr", "radio_tag"}:
            result["relative_consumables"] = "none_or_low"
        elif option == "operator_assisted_access":
            result["relative_consumables"] = "none_or_low"
            result["drivers"].append("operator_labor")
        elif option == "hybrid_access":
            result["relative_consumables"] = "depends_on_fallback_share"
        return result
