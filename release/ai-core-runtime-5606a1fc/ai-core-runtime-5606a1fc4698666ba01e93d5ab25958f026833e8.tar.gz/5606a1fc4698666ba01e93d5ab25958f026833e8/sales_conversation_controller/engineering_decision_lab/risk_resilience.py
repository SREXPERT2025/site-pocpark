from __future__ import annotations

from .models import ProjectFacts


class RiskResilienceAssessor:
    def assess(self, option: str, facts: ProjectFacts) -> tuple[str, ...]:
        risks: list[str] = []
        if option == "license_plate_recognition":
            risks.append("Нужно проверить условия установки камер и сценарий нераспознанного номера.")
            if facts.weather_exposure in {"high", "open_air"}:
                risks.append("Открытые погодные условия повышают требования к обзору и обслуживанию камер.")
        if option == "parking_card":
            risks.append("Нужен контроль возврата, чистоты, сухости и потерь карт.")
        if option == "parking_ticket":
            risks.append("Нужны запас рулонов и контроль механизма выдачи.")
        if option == "guest_qr":
            risks.append("Нужно проверить канал доставки и считывания QR-кода.")
        if option == "radio_tag":
            risks.append("Нужен учёт выданных радиометок.")
        if option == "operator_assisted_access":
            risks.append("Недоступность или ошибка оператора может создать очередь; нужны полномочия и порядок ручного допуска.")
        if option == "hybrid_access":
            risks.append("Нужно определить приоритеты и правила переключения между каналами.")
        return tuple(risks)

    def resilience(self, option: str, facts: ProjectFacts) -> dict[str, object]:
        failure_modes = {
            "license_plate_recognition": "plate_not_recognized",
            "parking_card": "card_unavailable_or_unreadable",
            "parking_ticket": "ticket_unavailable_or_unreadable",
            "guest_qr": "qr_unavailable_or_invalid",
            "radio_tag": "radio_tag_unavailable_or_unreadable",
            "operator_assisted_access": "operator_unavailable",
            "hybrid_access": "primary_channel_unavailable",
        }
        fallback = None
        policy = "deny_unknown_plate" if facts.unknown_plate_policy == "deny" else "apply_site_security_policy"
        return {
            "primary": option,
            "failure_mode": failure_modes[option],
            "automated_fallback_identifier": fallback,
            "assisted_recovery": (
                {"method": "operator_verification", "usage": "exception_only"}
                if facts.operator_present is True else None
            ),
            "emergency_override": {"allowed": "according_to_site_security_policy", "method": None},
            "fallback_policy": policy,
            "remaining_risk": "unknown" if not facts.mandatory_fallback else "medium",
            "evidence_refs": [],
        }
