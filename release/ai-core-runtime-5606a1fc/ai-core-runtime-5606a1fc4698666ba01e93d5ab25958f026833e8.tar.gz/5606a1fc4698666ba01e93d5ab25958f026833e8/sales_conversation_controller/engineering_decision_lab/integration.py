from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .decision_engine import EngineeringDecisionEngine


ALLOWED_MODES = {"off", "offline_audit", "offline_controller"}
ELIGIBLE_ACTIONS = {
    "recommend_solution", "compare_options", "configuration_selection",
    "operational_question", "risk_question", "roi_question",
    "propose_next_step", "conversation_summary",
}
INELIGIBLE_ACTIONS = {
    "greeting", "identity_question", "utility_request", "provide_contact",
    "known_link_request", "provide_link", "remember_fact", "simple_recall", "recall_facts",
}


@dataclass(frozen=True)
class LabIntegrationResult:
    invoked: bool
    decision_package: dict[str, Any]
    reason_codes: tuple[str, ...]
    missing_facts: tuple[str, ...]
    next_question: str | None
    ready_for_verbalization: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "invoked": self.invoked,
            "decision_package": self.decision_package,
            "reason_codes": list(self.reason_codes),
            "missing_facts": list(self.missing_facts),
            "next_question": self.next_question,
            "ready_for_verbalization": self.ready_for_verbalization,
        }


class EngineeringDecisionLabIntegration:
    """Офлайн-адаптер: не импортирует и не вызывает исполнительные модели."""

    def __init__(self, *, enabled: bool = False, mode: str = "off", engine: EngineeringDecisionEngine | None = None) -> None:
        if mode not in ALLOWED_MODES:
            raise ValueError("engineering_decision_lab_mode_invalid")
        self.enabled = bool(enabled)
        self.mode = mode
        self.engine = engine or EngineeringDecisionEngine()

    def run(self, value: dict[str, Any]) -> LabIntegrationResult:
        action = str(value.get("action_type") or "")
        if not self.enabled or self.mode == "off":
            return LabIntegrationResult(False, {}, ("engineering_decision_lab_disabled",), (), None, False)
        if action in INELIGIBLE_ACTIONS or action not in ELIGIBLE_ACTIONS:
            return LabIntegrationResult(False, {}, ("action_not_eligible_for_engineering_lab",), (), None, False)
        constraints = dict(value.get("conversation_constraints") or {})
        package = self.engine.decide(
            dict(value.get("project_facts") or {}),
            objective_profile=value.get("objective_profile") or None,
            constraints=tuple(constraints.get("hard_constraints") or ()),
            asked_questions=tuple(constraints.get("asked_questions") or ()),
        )
        payload = package.to_dict()
        reasons = ["engineering_decision_lab_invoked_offline"]
        if package.missing_critical_facts:
            reasons.append("missing_critical_facts_preserved")
        if package.assumptions:
            reasons.append("assumptions_explicit")
        segments = package.recommended_architecture.get("segments") or {}
        ready = (
            any(plan.get("primary_identifier") for plan in segments.values())
            and package.confidence >= .7 and bool(package.evidence_refs)
        )
        return LabIntegrationResult(
            True, payload, tuple(reasons), package.missing_critical_facts,
            package.next_question, ready,
        )
