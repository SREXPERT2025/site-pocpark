from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


ALLOWED_FACT_FIELDS = {
    "object_type", "entrances_count", "exits_count", "daily_traffic", "peak_traffic",
    "free_parking_minutes", "user_segments", "existing_system", "operator_present",
    "maintenance_staff_present", "payment_scenario", "security_priority", "speed_priority",
    "consumables_priority", "staff_intervention_priority", "advertising_priority",
    "modernization_or_new_build", "weather_exposure", "mandatory_fallback",
    "consumables_forbidden",
    "entry_price_rub", "power_redundancy", "network_redundancy",
    "confirmed_sources", "conflicts", "unknown_plate_policy",
    "space_for_entry_station", "interfaces_compatible", "ticket_user_share",
    "card_return_process", "card_loss_rate",
    "qr_reader_present", "card_reader_present", "rfid_reader_present", "ticket_reader_present",
    "guest_application_flow_confirmed", "guest_qr_delivery_confirmed",
    "guest_qr_binding_confirmed", "guest_qr_reuse_policy_confirmed",
    "guest_qr_expiry_confirmed",
}

ENGINEERING_REASON_CODES = {
    "manual_recovery_misclassified_as_fallback_identifier",
    "fallback_not_segment_specific", "fallback_requires_unconfirmed_reader",
    "guest_qr_flow_not_defined", "operator_presented_as_required_for_normal_operation",
    "automatic_fallback_missing", "assisted_recovery_missing",
    "failure_policy_missing", "segment_access_plan_missing",
    "fallback_infrastructure_unknown", "universal_operational_claim",
    "mixed_tradeoff_categories", "operational_claim_missing_conditions",
    "decision_relevant_comparative_claim_not_verified",
    "authorization_misclassified_as_identifier",
    "identifier_misclassified_as_authorization",
    "guest_workflow_and_identifier_conflated", "lane_credential_missing",
    "composite_architecture_ranked_as_primitive", "hybrid_option_double_counted",
    "architecture_component_semantics_invalid",
}

ACCESS_AUTHORIZATION_TYPES = {
    "employee_registry", "tenant_registry", "guest_application", "white_list",
    "paid_session", "operator_approval", "other_confirmed_authorization",
}
LANE_IDENTIFIER_TYPES = {
    "license_plate_recognition", "parking_card", "parking_ticket", "guest_qr",
    "radio_tag", "other_confirmed_identifier",
}
PRIMITIVE_IDENTIFIER_OPTIONS = (
    "license_plate_recognition", "parking_card", "parking_ticket", "guest_qr", "radio_tag",
)


@dataclass(frozen=True)
class ProjectFacts:
    object_type: str | None = None
    entrances_count: int | None = None
    exits_count: int | None = None
    daily_traffic: int | None = None
    peak_traffic: int | None = None
    free_parking_minutes: int | None = None
    user_segments: tuple[str, ...] = ()
    existing_system: str | None = None
    operator_present: bool | None = None
    maintenance_staff_present: bool | None = None
    payment_scenario: str | None = None
    security_priority: str | None = None
    speed_priority: str | None = None
    consumables_priority: str | None = None
    staff_intervention_priority: str | None = None
    advertising_priority: str | None = None
    modernization_or_new_build: str | None = None
    weather_exposure: str | None = None
    mandatory_fallback: bool | None = None
    consumables_forbidden: bool | None = None
    entry_price_rub: int | None = None
    power_redundancy: bool | None = None
    network_redundancy: bool | None = None
    confirmed_sources: dict[str, Any] = field(default_factory=dict)
    conflicts: dict[str, Any] = field(default_factory=dict)
    unknown_plate_policy: str | None = None
    space_for_entry_station: bool | None = None
    interfaces_compatible: bool | None = None
    ticket_user_share: float | None = None
    card_return_process: bool | None = None
    card_loss_rate: float | None = None
    qr_reader_present: bool | None = None
    card_reader_present: bool | None = None
    rfid_reader_present: bool | None = None
    ticket_reader_present: bool | None = None
    guest_application_flow_confirmed: bool | None = None
    guest_qr_delivery_confirmed: bool | None = None
    guest_qr_binding_confirmed: bool | None = None
    guest_qr_reuse_policy_confirmed: bool | None = None
    guest_qr_expiry_confirmed: bool | None = None

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ProjectFacts":
        unknown = set(value) - ALLOWED_FACT_FIELDS
        if unknown:
            raise ValueError(f"Неподдерживаемые поля проекта: {sorted(unknown)}")
        prepared = dict(value)
        prepared["user_segments"] = tuple(prepared.get("user_segments") or ())
        for key in ("entrances_count", "exits_count", "daily_traffic", "peak_traffic", "free_parking_minutes", "entry_price_rub"):
            if prepared.get(key) is not None and (not isinstance(prepared[key], int) or prepared[key] < 0):
                raise ValueError(f"Поле {key} должно быть неотрицательным целым числом")
        for key in ("ticket_user_share", "card_loss_rate"):
            if prepared.get(key) is not None and (not isinstance(prepared[key], (int, float)) or not 0 <= prepared[key] <= 1):
                raise ValueError(f"Поле {key} должно находиться в диапазоне 0..1")
        return cls(**prepared)

    def confirmed_dict(self) -> dict[str, Any]:
        return {key: value for key, value in asdict(self).items() if value not in (None, (), [])}


@dataclass(frozen=True)
class ObjectiveProfile:
    speed: float = 1.0
    reliability: float = 1.0
    staff_load: float = 1.0
    consumables: float = 1.0
    security: float = 1.0
    advertising: float = 0.0
    evidence: tuple[str, ...] = ()
    primary_objective: str = "balanced_solution"
    secondary_objectives: tuple[str, ...] = ()
    constraints: tuple[str, ...] = ()
    weights: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in ("evidence", "secondary_objectives", "constraints"):
            value[key] = list(value[key])
        return value


@dataclass(frozen=True)
class DecisionCard:
    option: str
    score: float
    strengths: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    operational_load: dict[str, Any] = field(default_factory=dict)
    tco_factors: dict[str, Any] = field(default_factory=dict)
    risks: tuple[str, ...] = ()
    suitable_when: tuple[str, ...] = ()
    less_suitable_when: tuple[str, ...] = ()
    hard_constraints: tuple[str, ...] = ()
    criterion_scores: dict[str, float] = field(default_factory=dict)
    evidence_required: tuple[str, ...] = ()
    review_status: str = "machine_generated_from_verified_rules"
    resilience: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in ("strengths", "limitations", "evidence_refs", "risks", "suitable_when", "less_suitable_when", "hard_constraints", "evidence_required"):
            value[key] = list(value[key])
        return value


@dataclass(frozen=True)
class PrimaryIdentifier:
    value: str | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AutomatedFallbackIdentifier:
    value: str
    required_reader: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AssistedRecovery:
    method: str
    usage: str = "exception_only"

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class EmergencyOverride:
    allowed: str = "according_to_site_security_policy"
    method: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InfrastructureRequirement:
    identifier: str
    required_reader: str
    confirmed: bool | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class FailurePolicy:
    value: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SegmentAccessPlan:
    primary_identifier: str | None
    automated_fallback_identifiers: tuple[str, ...] = ()
    assisted_recovery: AssistedRecovery | None = None
    failure_policy: str | None = None
    infrastructure_requirements: tuple[InfrastructureRequirement, ...] = ()
    evidence_refs: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "primary_identifier": self.primary_identifier,
            "automated_fallback_identifiers": list(self.automated_fallback_identifiers),
            "assisted_recovery": self.assisted_recovery.to_dict() if self.assisted_recovery else None,
            "failure_policy": self.failure_policy,
            "infrastructure_requirements": [item.to_dict() for item in self.infrastructure_requirements],
            "evidence_refs": list(self.evidence_refs),
        }


@dataclass(frozen=True)
class AccessAuthorization:
    type: str
    status: str | None = None

    def __post_init__(self) -> None:
        if self.type not in ACCESS_AUTHORIZATION_TYPES:
            raise ValueError("access_authorization_type_invalid")

    def to_dict(self) -> dict[str, Any]:
        return {key: value for key, value in asdict(self).items() if value is not None}


@dataclass(frozen=True)
class LaneIdentifier:
    type: str
    status: str | None = None

    def __post_init__(self) -> None:
        if self.type not in LANE_IDENTIFIER_TYPES:
            raise ValueError("lane_identifier_type_invalid")

    def to_dict(self) -> dict[str, Any]:
        return {key: value for key, value in asdict(self).items() if value is not None}


@dataclass(frozen=True)
class AutomatedFallbackCredential:
    type: str
    required_reader: str
    status: str = "confirmed"

    def __post_init__(self) -> None:
        if self.type not in LANE_IDENTIFIER_TYPES:
            raise ValueError("automated_fallback_credential_type_invalid")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SegmentAccessPlanV12:
    authorization: AccessAuthorization
    primary_identifier: LaneIdentifier | None
    automated_fallback_credentials: tuple[AutomatedFallbackCredential, ...] = ()
    assisted_recovery: AssistedRecovery | None = None
    failure_policy: str | None = None
    infrastructure_requirements: tuple[InfrastructureRequirement, ...] = ()
    evidence_refs: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "authorization": self.authorization.to_dict(),
            "primary_identifier": self.primary_identifier.to_dict() if self.primary_identifier else None,
            "automated_fallback_credentials": [item.to_dict() for item in self.automated_fallback_credentials],
            "assisted_recovery": self.assisted_recovery.to_dict() if self.assisted_recovery else None,
            "failure_policy": self.failure_policy,
            "infrastructure_requirements": [item.to_dict() for item in self.infrastructure_requirements],
            "evidence_refs": list(self.evidence_refs),
        }


@dataclass(frozen=True)
class PrimitiveOptionAssessment:
    option: str
    ordinal_rating: str
    normalized_score: float | None
    internal_ranking_only: bool
    criterion_trace: tuple[dict[str, Any], ...]
    missing_data: tuple[str, ...]
    review_status: str
    evidence_refs: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "option": self.option, "ordinal_rating": self.ordinal_rating,
            "normalized_score": self.normalized_score,
            "internal_ranking_only": self.internal_ranking_only,
            "criterion_trace": list(self.criterion_trace), "missing_data": list(self.missing_data),
            "review_status": self.review_status, "evidence_refs": list(self.evidence_refs),
        }


@dataclass(frozen=True)
class DecisionPackageV12:
    decision_type: str
    decision_status: str
    comparison_scope: tuple[str, ...]
    recommended_architecture: dict[str, Any]
    primitive_option_assessments: tuple[PrimitiveOptionAssessment, ...]
    candidate_credentials_requiring_confirmation: tuple[dict[str, Any], ...]
    why: tuple[str, ...]
    tradeoffs: tuple[str, ...]
    assumptions: tuple[str, ...]
    missing_critical_facts: tuple[str, ...]
    confidence: float
    confidence_trace: dict[str, Any]
    next_question: str | None
    next_step: str | None
    evidence_refs: tuple[str, ...]
    question_ranking: tuple[dict[str, Any], ...] = ()
    sensitivity_analysis: tuple[dict[str, Any], ...] = ()
    reason_codes: tuple[str, ...] = ()
    schema_version: str = "1.2"

    def to_dict(self) -> dict[str, Any]:
        value = {
            "schema_version": self.schema_version, "decision_type": self.decision_type,
            "recommended_architecture": self.recommended_architecture,
            "primitive_option_assessments": [item.to_dict() for item in self.primitive_option_assessments],
            "candidate_credentials_requiring_confirmation": list(self.candidate_credentials_requiring_confirmation),
            "why": list(self.why), "tradeoffs": list(self.tradeoffs),
            "assumptions": list(self.assumptions), "missing_critical_facts": list(self.missing_critical_facts),
            "confidence": self.confidence, "confidence_trace": self.confidence_trace,
            "next_question": self.next_question, "next_step": self.next_step,
            "evidence_refs": list(self.evidence_refs), "question_ranking": list(self.question_ranking),
            "sensitivity_analysis": list(self.sensitivity_analysis), "reason_codes": list(self.reason_codes),
        }
        if self.decision_status != "full_decision" or self.comparison_scope:
            value["decision_status"] = self.decision_status
            value["comparison_scope"] = list(self.comparison_scope)
        return value


@dataclass(frozen=True)
class DecisionPackage:
    decision_type: str
    recommended_architecture: dict[str, Any]
    why: tuple[str, ...]
    tradeoffs: tuple[str, ...]
    assumptions: tuple[str, ...]
    missing_critical_facts: tuple[str, ...]
    confidence: float
    next_question: str | None
    next_step: str | None
    evidence_refs: tuple[str, ...]
    objective_profile: ObjectiveProfile
    option_cards: tuple[DecisionCard, ...]
    schema_version: str = "1.1"
    candidate_options: tuple[dict[str, Any], ...] = ()
    reason_codes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "decision_type": self.decision_type,
            "recommended_architecture": self.recommended_architecture,
            "why": list(self.why), "tradeoffs": list(self.tradeoffs),
            "assumptions": list(self.assumptions), "missing_critical_facts": list(self.missing_critical_facts),
            "confidence": self.confidence, "next_question": self.next_question,
            "next_step": self.next_step, "evidence_refs": list(self.evidence_refs),
            "objective_profile": self.objective_profile.to_dict(),
            "option_cards": [card.to_dict() for card in self.option_cards],
            "candidate_options": list(self.candidate_options),
            "reason_codes": list(self.reason_codes),
        }


@dataclass(frozen=True)
class WhatIfResult:
    changed_facts: dict[str, Any]
    previous_architecture: dict[str, Any]
    new_architecture: dict[str, Any]
    architecture_changed: bool
    changed_reasons: tuple[str, ...]
    decision: DecisionPackage

    def to_dict(self) -> dict[str, Any]:
        return {
            "changed_facts": self.changed_facts,
            "previous_architecture": self.previous_architecture,
            "new_architecture": self.new_architecture,
            "architecture_changed": self.architecture_changed,
            "changed_reasons": list(self.changed_reasons),
            "decision": self.decision.to_dict(),
        }
