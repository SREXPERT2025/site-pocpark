from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from typing import Any, Callable

from .contracts import ControllerDecision
from .decision_package_semantic_coverage import evaluate_semantic_coverage
from .verbalization_semantics import (
    is_candidate_recommendation_context,
    operator_presented_as_automatic_fallback,
)


PRICE_RE = re.compile(r"\b\d[\d\s.,]*(?:₽|руб(?:лей|ля|ль)?\b)", re.I)
TIMELINE_RE = re.compile(r"\b(?:сделаем|поставим|смонтируем|запустим|установим)\b.{0,45}\b\d+\s*(?:дн|недел|месяц)", re.I)
AVAILABILITY_RE = re.compile(r"\b(?:есть в наличии|точно в наличии|зарезервируем|всегда в наличии)\b", re.I)
COMPATIBILITY_RE = re.compile(
    r"\b(?:(?:точно|полностью|гарантированно|безусловно)\s+совместим\w*|"
    r"(?:эта|система|решение|оборудование)\b.{0,25}\bсовместим\w*)",
    re.I,
)
GUARANTEE_RE = re.compile(r"\b(?:гарантируем|гарантированно|сто процентов|точно сработает|обязательно сработает)\b", re.I)
DISCOUNT_RE = re.compile(r"\b(?:дадим|согласуем|предоставим)\s+скидк\w*", re.I)
PRESSURE_RE = re.compile(
    r"\b(?:решайте сейчас|последний шанс|вы обязаны|иначе потеряете|только сегодня|"
    r"вам обязательно нужно|нужно срочно|лучше не откладывать|единственно правильн\w+ вариант|"
    r"оставьте контакт прямо сейчас)\b",
    re.I,
)
CONTACT_RE = re.compile(r"\b(?:оставьте|напишите|пришлите)\b.{0,28}\b(?:телефон|номер|почт|email|телеграм|контакт)", re.I)
MODEL_RE = re.compile(r"\b(?:codex|qwen|ollama|gpt[-\w.]*)\b", re.I)
LINK_ONLY_RE = re.compile(r"^\s*(?:https?://\S+|/[-\w./]+)\s*$", re.I)
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
PHONE_RE = re.compile(r"(?<!\w)(?:\+?7|8)[\s()\-]*\d{3}[\s()\-]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2}(?!\w)")
SYSTEM_LEAK_RE = re.compile(r"\b(?:system prompt|системн\w+ промпт|скрыт\w+(?:\s+системн\w+)?\s+инструкц\w*|внутренн\w+ маршрутизац|chain of thought)\b", re.I)
INTERNAL_SERVICE_MARKER_RE = re.compile(
    r"\b(?:exact_next_question|NEXT_QUESTION_PLACEHOLDER)\b", re.I,
)
DANGEROUS_RE = re.compile(r"\b(?:отключите защит\w*|замкните контакт\w*|обойдите систем\w+ безопасност|отключите блокировк\w*)\b", re.I)
SENTENCE_RE = re.compile(r"[^.!?]+(?:[.!?]+|$)")

GROUNDED_TERMS = (
    "1с", "crm", "камера", "шлагбаум", "терминал", "распознавание номеров",
    "rfid", "qr", "онлайн-оплата", "монтаж", "контроллер", "интеграц",
)
TECH_ASSERTION_RE = re.compile(
    r"\b(?:умеет|поддерживает|обеспечивает|автоматически|можно подключить|работает с|"
    r"интегрируется|позволяет|открывает|распозна[её]т)\b",
    re.I,
)
AUTOMATIC_AND_OPERATOR_RE = re.compile(
    r"\b(?:qr|карт\w*|билет\w*|rfid|радиомет\w*)\b.{0,55}\b(?:или|и|,)\s*оператор\w*|"
    r"\bоператор\w*\b.{0,55}\b(?:или|и|,)\s*(?:qr|карт\w*|билет\w*|rfid|радиомет\w*)",
    re.I,
)
UNIVERSAL_CARD_TICKET_LOAD_RE = re.compile(
    r"\bкарт\w*\s+или\s+билет\w*\b.{0,80}\b(?:высок\w*|больш\w*)\s+нагрузк\w*", re.I
)
AUTHORIZATION_AS_IDENTIFIER_RE = re.compile(
    r"(?:гостев\w+\s+заявк\w*\b.{0,30}\b(?:является|служит|как)\b.{0,20}\bидентификатор|"
    r"идентификац\w*\s+(?:через|по)\s+гостев\w+\s+заявк\w*)", re.I,
)

SAFE_TEMPLATE = (
    "Точный ответ зависит от подтверждённых данных по объекту и конфигурации. "
    "Я могу продолжить консультацию здесь и помочь собрать исходные данные для проверки специалистом."
)

SPECIALIZED_FALLBACKS = {
    "technical_verification_required": "Чтобы ответить точно, нужно проверить модель оборудования и интерфейсы подключения.",
    "price_configuration_required": "Точная стоимость зависит от конфигурации объекта, количества въездов и требуемых функций.",
    "human_review_required": "Этот вопрос требует проверки специалистом, чтобы не дать неточную информацию. Можно продолжить здесь и уточнить исходные данные.",
    "answer_without_sales_motion": "По имеющимся данным можно дать только общий ответ без неподтверждённых деталей.",
}

BLOCKING_TYPES = {
    "empty_answer", "pii_leak", "dangerous_instruction", "system_instruction_leakage",
}

QUESTION_GOAL_TERMS: dict[str, tuple[str, ...]] = {
    "identify_object_type": ("объект", "бизнес-центр", "жилой", "торговый"),
    "identify_entrances_count": ("въезд", "выезд", "полос", "проезд"),
    "identify_current_system": ("система", "оборудование", "контроллер", "модель", "установлен"),
    "identify_current_problem": ("проблем", "не устраивает", "очеред", "сбой"),
    "identify_desired_outcome": ("результат", "нужно", "хотите", "задач"),
    "identify_real_objection": ("сомнен", "дорого", "останавливает", "причин"),
}

STOPWORDS = {
    "это", "как", "для", "или", "при", "что", "чтобы", "можно", "нужно", "будет",
    "есть", "такой", "такая", "такие", "ваш", "ваша", "ваши", "система", "ответ",
}


@dataclass(frozen=True)
class RepairViolation:
    type: str
    fragment: str
    repair_action: str
    priority: int
    severity: str = "repairable"
    evidence_level: str = "unknown"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RepairDecision:
    repair_required: bool
    severity: str
    violations: tuple[RepairViolation, ...]
    preserve_fragments: tuple[str, ...]
    fallback_allowed: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "repair_required": self.repair_required,
            "severity": self.severity,
            "violations": [item.to_dict() for item in self.violations],
            "preserve_fragments": list(self.preserve_fragments),
            "fallback_allowed": self.fallback_allowed,
        }


@dataclass(frozen=True)
class PostProcessingResult:
    answer: str
    passed: bool
    flags: tuple[str, ...]
    replacement_used: bool
    raw_answer: str = ""
    repair_applied: bool = False
    repair_success: bool = False
    repair_method: str = "none"
    fallback_type: str | None = None
    repair_decision: dict[str, Any] | None = None
    remaining_flags: tuple[str, ...] = ()
    useful_content_preserved: bool = False


class LocalResponseRepairer:
    """Необязательный короткий LLM-repair через уже доступный локальный исполнитель."""

    SYSTEM = (
        "Ты редактор ответа AI-консультанта РОСПАРК. Перепиши ответ минимально. "
        "Сохрани всю полезную подтверждённую информацию. Исправь только перечисленные нарушения. "
        "Не добавляй технических фактов, нового вопроса или запроса контакта без разрешения. "
        "Не превращай ответ в общий безопасный шаблон. Верни только исправленный ответ."
    )

    def __init__(self, executor: Any, *, timeout_seconds: float = 20.0) -> None:
        self.executor = executor
        self.timeout_seconds = timeout_seconds

    def __call__(self, context: dict[str, Any]) -> str:
        messages = [
            {"role": "system", "content": self.SYSTEM},
            {"role": "user", "content": json.dumps(context, ensure_ascii=False, separators=(",", ":"))},
        ]
        generated = self.executor.generate(messages, timeout_seconds=self.timeout_seconds)
        return str(generated.answer or "").strip()


class AnswerPostProcessor:
    def __init__(self, *, llm_repairer: Callable[[dict[str, Any]], str] | None = None) -> None:
        self.llm_repairer = llm_repairer

    def check(
        self,
        answer: str,
        decision: ControllerDecision,
        *,
        confirmed_claims: list[str] | None = None,
        asked_question_texts: list[str] | None = None,
        user_message: str = "",
        allow_llm_repair: bool = True,
        decision_package: dict[str, Any] | None = None,
    ) -> PostProcessingResult:
        clean = " ".join(str(answer or "").split())
        confirmed_claims = confirmed_claims or []
        violations = self._detect(
            clean,
            decision,
            confirmed_claims=confirmed_claims,
            asked_question_texts=asked_question_texts or [],
            user_message=user_message,
            decision_package=decision_package,
        )
        if not violations:
            return PostProcessingResult(clean, True, (), False, raw_answer=clean)

        contract = self._contract(clean, violations)
        original_flags = tuple(dict.fromkeys(item.type for item in violations))
        semantic_types = {
            "semantic_architecture_mismatch",
            "manual_recovery_misclassified_as_fallback_identifier",
            "fallback_not_segment_specific",
            "fallback_requires_unconfirmed_reader",
        }
        if semantic_types & set(original_flags) and not decision_package:
            unresolved = tuple(dict.fromkeys((*original_flags,
                "repair_requires_decision_package",
                "semantic_repair_requires_regeneration",
                "repair_cannot_select_engineering_fallback",
            )))
            return PostProcessingResult(
                clean, False, unresolved, False, raw_answer=clean,
                repair_applied=False, repair_success=False,
                repair_method="semantic_regeneration_required",
                fallback_type="semantic_repair_requires_regeneration",
                repair_decision=contract.to_dict(), remaining_flags=unresolved,
                useful_content_preserved=True,
            )
        if contract.severity == "blocking":
            fallback_type, fallback = self._specialized_fallback(violations, decision)
            remaining = self._detect(
                fallback, decision, confirmed_claims=confirmed_claims,
                asked_question_texts=asked_question_texts or [], user_message=user_message,
            )
            if remaining:
                return PostProcessingResult(
                    SAFE_TEMPLATE, False, original_flags, True, raw_answer=clean,
                    repair_applied=False, repair_success=False, repair_method="safe_template",
                    fallback_type="general_safe_template", repair_decision=contract.to_dict(),
                    remaining_flags=tuple(dict.fromkeys(item.type for item in remaining)),
                )
            return PostProcessingResult(
                fallback, True, original_flags, True, raw_answer=clean,
                repair_applied=False, repair_success=False, repair_method="specialized_fallback",
                fallback_type=fallback_type, repair_decision=contract.to_dict(),
            )

        repaired = self._deterministic_repair(
            clean, violations, decision, confirmed_claims=confirmed_claims,
            decision_package=decision_package,
        )
        remaining = self._detect(
            repaired, decision, confirmed_claims=confirmed_claims,
            asked_question_texts=asked_question_texts or [], user_message=user_message,
            decision_package=decision_package,
        )
        method = "deterministic"
        if remaining and self.llm_repairer is not None and allow_llm_repair:
            context = {
                "user_message": user_message,
                "original_answer": clean,
                "deterministic_repair": repaired,
                "violations": [item.to_dict() for item in remaining],
                "preserve_fragments": list(contract.preserve_fragments),
                "controller_decision": decision.to_dict(),
                "confirmed_knowledge": confirmed_claims[:4],
                "constraints": {
                    "question_allowed": decision.should_ask_question,
                    "question_goal": decision.question_goal,
                    "contact_allowed": decision.should_request_contact,
                    "maximum_questions": 1,
                },
            }
            try:
                candidate = " ".join(self.llm_repairer(context).split())
            except Exception:
                candidate = ""
            if candidate:
                llm_remaining = self._detect(
                    candidate, decision, confirmed_claims=confirmed_claims,
                    asked_question_texts=asked_question_texts or [], user_message=user_message,
                    decision_package=decision_package,
                )
                if not llm_remaining:
                    repaired, remaining, method = candidate, [], "llm"

        if not remaining and repaired:
            return PostProcessingResult(
                repaired, True, original_flags, False, raw_answer=clean,
                repair_applied=True, repair_success=True, repair_method=method,
                repair_decision=contract.to_dict(),
                useful_content_preserved=self._useful_content_preserved(clean, repaired),
            )

        fallback_type, fallback = self._specialized_fallback(remaining or violations, decision)
        fallback_remaining = self._detect(
            fallback, decision, confirmed_claims=confirmed_claims,
            asked_question_texts=asked_question_texts or [], user_message=user_message,
            decision_package=decision_package,
        )
        if fallback_remaining:
            fallback_type, fallback = "general_safe_template", SAFE_TEMPLATE
        return PostProcessingResult(
            fallback, not fallback_remaining, original_flags, True, raw_answer=clean,
            repair_applied=True, repair_success=False, repair_method="specialized_fallback",
            fallback_type=fallback_type, repair_decision=contract.to_dict(),
            # remaining_flags describes the answer that will actually be shown.
            # The violations that led to fallback are already retained in
            # repair_decision and flags; carrying them here would incorrectly
            # mark a revalidated specialized fallback as unsafe.
            remaining_flags=tuple(dict.fromkeys(item.type for item in fallback_remaining)),
            useful_content_preserved=False,
        )

    def _detect(
        self,
        clean: str,
        decision: ControllerDecision,
        *,
        confirmed_claims: list[str],
        asked_question_texts: list[str],
        user_message: str,
        decision_package: dict[str, Any] | None = None,
    ) -> list[RepairViolation]:
        result: list[RepairViolation] = []
        if not clean:
            return [RepairViolation("empty_answer", "", "human_review_required", 1, "blocking")]
        for pattern, code in (
            (EMAIL_RE, "pii_leak"), (PHONE_RE, "pii_leak"),
            (SYSTEM_LEAK_RE, "system_instruction_leakage"),
            (DANGEROUS_RE, "dangerous_instruction"),
        ):
            match = pattern.search(clean)
            if match:
                result.append(RepairViolation(code, self._sentence_for(clean, match.start()), "block_and_fallback", 1, "blocking"))
        for match in INTERNAL_SERVICE_MARKER_RE.finditer(clean):
            result.append(RepairViolation(
                "internal_service_marker_leak", match.group(0),
                "remove_marker_and_restore_exact_question", 1,
            ))

        evidence_text = " ".join([*confirmed_claims, user_message]).lower()
        for match in PRICE_RE.finditer(clean):
            if match.group(0).lower() not in evidence_text:
                result.append(RepairViolation("unsupported_price", self._sentence_for(clean, match.start()), "replace_with_pricing_factors", 1))
        for pattern, code, action, priority in (
            (TIMELINE_RE, "unsupported_timeline", "downgrade_timeline", 1),
            (AVAILABILITY_RE, "unsupported_availability", "require_availability_check", 1),
            (COMPATIBILITY_RE, "unsupported_compatibility", "downgrade_to_verification_required", 1),
            (GUARANTEE_RE, "unsupported_guarantee", "downgrade_guarantee", 1),
            (DISCOUNT_RE, "unauthorized_discount", "remove_discount_promise", 1),
            (PRESSURE_RE, "pressure_violation", "soften_pressure", 2),
        ):
            for match in pattern.finditer(clean):
                fragment = self._sentence_for(clean, match.start())
                if match.group(0).lower() not in evidence_text:
                    result.append(RepairViolation(code, fragment, action, priority))

        questions = self._question_units(clean)
        allowed = 1 if decision.should_ask_question else 0
        if len(questions) > allowed:
            result.append(RepairViolation("question_count_violation", " ".join(questions), "keep_one_question", 2))
        if questions and not decision.should_ask_question:
            result.append(RepairViolation("question_permission_violation", " ".join(questions), "remove_questions", 1))
        if len(questions) == 1 and self._is_compound_question(questions[0]):
            result.append(RepairViolation("compound_question", questions[0], "keep_one_question_goal", 3))
        if questions and decision.should_ask_question and decision.question_goal:
            package_question = str((decision_package or {}).get("next_question") or "").strip()
            package_question_present = bool(package_question) and any(
                self._normalize_question(item) == self._normalize_question(package_question) for item in questions
            )
            if not package_question_present and not any(self._question_goal_match(item, decision.question_goal) for item in questions):
                result.append(RepairViolation("question_relevance_violation", " ".join(questions), "align_question_to_goal", 3))
        for question in questions:
            normalized = self._normalize_question(question)
            if any(normalized and normalized == self._normalize_question(previous) for previous in asked_question_texts):
                result.append(RepairViolation("duplicate_question", question, "remove_duplicate_question", 2))
                break

        match = CONTACT_RE.search(clean)
        if match and not decision.should_request_contact:
            result.append(RepairViolation("premature_contact_request", self._sentence_for(clean, match.start()), "remove_contact_request", 1))
        if decision.loop_count > 2:
            result.append(RepairViolation("loop_limit_violation", clean, "remove_sales_motion", 1))
        match = MODEL_RE.search(clean)
        if match:
            result.append(RepairViolation("executor_disclosure", self._sentence_for(clean, match.start()), "remove_executor_name", 1))
        if LINK_ONLY_RE.match(clean):
            result.append(RepairViolation("link_only_answer", clean, "add_grounded_summary", 2))

        match = AUTOMATIC_AND_OPERATOR_RE.search(clean)
        if match and operator_presented_as_automatic_fallback(clean):
            result.append(RepairViolation(
                "semantic_architecture_mismatch", self._sentence_for(clean, match.start()),
                "separate_automatic_fallback_and_assisted_recovery", 1,
            ))
            result.append(RepairViolation(
                "manual_recovery_misclassified_as_fallback_identifier",
                self._sentence_for(clean, match.start()), "restore_from_decision_package", 1,
            ))
        comparison_only = (
            (decision_package or {}).get("decision_status") == "comparison_only"
        )
        fallback_decision_pending = (
            (decision_package or {}).get("decision_status") == "fallback_decision_pending"
        )
        if fallback_decision_pending and re.search(
            r"\b(?:всегда|постоянно)\b.{0,50}\b(?:охранник|оператор)\w*|"
            r"\b(?:охранник|оператор)\w*\b.{0,50}\b(?:всегда|постоянно)\b|"
            r"\b(?:охранник|дежурн\w*|оператор)\w*\b.{0,55}\b(?:дежурит|откроет|открывает|пропустит|пропускает)\b",
            clean, re.I,
        ) and not re.search(
            r"\b(?:только\s+для\s+исключ|исключительн|не\s+явля\w*.{0,35}резерв)\b",
            clean, re.I,
        ):
            result.append(RepairViolation(
                "operator_as_automated_fallback", clean,
                "restore_operator_exception_only", 1,
            ))
        if fallback_decision_pending and re.search(
            r"\b(?:экран|табло|терминал)\w*\b.{0,90}\b(?:покаж|увид|инструкц|подсказ)",
            clean, re.I,
        ) and not re.search(
            r"\b(?:не\s+подтвержден|нельзя\s+(?:утверждать|определить)|только\s+после\s+подтверждения)\b",
            clean, re.I,
        ):
            result.append(RepairViolation(
                "unsupported_lane_guidance_claim", clean,
                "remove_unconfirmed_lane_guidance", 1,
            ))
        if (
            not comparison_only and not fallback_decision_pending
            and (decision_package or {}).get("decision_type") == "access_identifier_selection"
            and re.search(r"\bрезерв\w*\b", clean, re.I)
            and not re.search(r"\b(?:сотрудник|арендатор|гост)\w*\b", clean, re.I)
        ):
            result.append(RepairViolation(
                "fallback_not_segment_specific", self._sentence_for(clean, clean.lower().find("резерв")),
                "restore_segment_access_plan", 1,
            ))
        universal = UNIVERSAL_CARD_TICKET_LOAD_RE.search(clean)
        if universal:
            fragment = self._sentence_for(clean, universal.start())
            result.extend((
                RepairViolation("universal_operational_claim", fragment, "split_conditional_tradeoffs", 1),
                RepairViolation("mixed_tradeoff_categories", fragment, "split_conditional_tradeoffs", 1),
                RepairViolation("operational_claim_missing_conditions", fragment, "add_operational_conditions", 2),
                RepairViolation("decision_relevant_comparative_claim_not_verified", fragment, "split_conditional_tradeoffs", 2),
            ))
        authorization_mismatch = AUTHORIZATION_AS_IDENTIFIER_RE.search(clean)
        if authorization_mismatch:
            fragment = self._sentence_for(clean, authorization_mismatch.start())
            result.extend((
                RepairViolation("authorization_misclassified_as_identifier", fragment, "restore_access_ontology", 1),
                RepairViolation("guest_workflow_and_identifier_conflated", fragment, "restore_access_ontology", 1),
            ))
        if decision_package:
            coverage = evaluate_semantic_coverage(
                clean, decision_package, user_message=user_message,
            )
            coverage_actions = {
                "missing_primary_identifier": "restore_primary_identifier",
                "missing_required_segments": "restore_segment_semantics",
                "missing_guest_authorization": "restore_guest_authorization",
                "missing_assisted_recovery": "restore_assisted_recovery",
                "missing_fallback_semantics": "restore_pending_fallback",
                "fallback_scenario_not_resolved": "restore_pending_fallback",
                "missing_required_tradeoff": "restore_required_tradeoff",
                "missing_unknown_conditionality": "restore_unknown_conditionality",
                "missing_or_wrong_next_question": "restore_exact_next_question",
            }
            result.extend(
                RepairViolation(code, "", coverage_actions[code], 2)
                for code in coverage.reason_codes
            )
            candidates = (
                decision_package.get("candidate_options")
                or decision_package.get("candidate_credentials_requiring_confirmation") or []
            )
            # Вопрос о наличии считывателя не является рекомендацией самого
            # идентификатора. Исключаем точный вопрос лаборатории из области
            # проверки, иначе корректный сбор факта давал ложное нарушение.
            candidate_scope = clean
            package_question = str(decision_package.get("next_question") or "").strip()
            if package_question:
                candidate_scope = candidate_scope.replace(package_question, "")
            candidate_scope = " ".join(
                sentence for sentence in self._sentences(candidate_scope)
                if is_candidate_recommendation_context(sentence)
            )
            mentioned = {
                item.get("identifier") or (item.get("credential") or {}).get("type") for item in candidates
                if self._identifier_mentioned(
                    candidate_scope,
                    str(item.get("identifier") or (item.get("credential") or {}).get("type") or ""),
                )
            }
            if mentioned:
                result.append(RepairViolation(
                    "fallback_requires_unconfirmed_reader", ", ".join(sorted(mentioned)),
                    "remove_unconfirmed_identifier", 1,
                ))

        seen_fragments: set[tuple[str, str]] = set()
        for sentence in self._sentences(clean):
            lower = sentence.lower()
            if not any(term in lower for term in GROUNDED_TERMS):
                continue
            level = self._evidence_level(sentence, confirmed_claims)
            categorical = bool(TECH_ASSERTION_RE.search(sentence))
            if level in {"verified", "supported"}:
                continue
            if level == "partially_supported" and re.search(
                r"\b(?:в зависимости|может быть|нужно проверить|требует проверки)\b", sentence, re.I
            ):
                continue
            if level == "unknown" and not categorical:
                continue
            code = "partially_supported_technical_claim" if level == "partially_supported" else (
                "unsupported_technical_claim" if categorical else "unknown_technical_claim"
            )
            key = (code, sentence)
            if key not in seen_fragments:
                result.append(RepairViolation(code, sentence, "condition_or_verify_technical_claim", 2, evidence_level=level))
                seen_fragments.add(key)
        return self._deduplicate_violations(result)

    def _deterministic_repair(
        self,
        clean: str,
        violations: list[RepairViolation],
        decision: ControllerDecision,
        *,
        confirmed_claims: list[str],
        decision_package: dict[str, Any] | None = None,
    ) -> str:
        clean = " ".join(INTERNAL_SERVICE_MARKER_RE.sub(" ", clean).split())
        types = {item.type for item in violations}
        missing_semantics = {
            "missing_primary_identifier", "missing_required_segments",
            "missing_guest_authorization", "missing_assisted_recovery",
            "missing_fallback_semantics", "missing_required_tradeoff",
            "fallback_scenario_not_resolved",
            "missing_unknown_conditionality", "missing_or_wrong_next_question",
        }
        if (decision_package or {}).get("schema_version") == "1.2" and types & missing_semantics:
            body = [sentence for sentence in self._sentences(clean) if "?" not in sentence]
            if types & {"missing_primary_identifier", "missing_required_segments"}:
                body.append(
                    "Для сотрудников и арендаторов основным способом предварительно можно использовать распознавание номеров; "
                    "для гостей идентификация также может выполняться по заранее зарегистрированному номеру."
                )
            if "missing_guest_authorization" in types:
                body.append(
                    "Для гостей право доступа задаёт гостевая заявка, а идентификация на полосе выполняется отдельно."
                )
            if types & {"missing_fallback_semantics", "fallback_scenario_not_resolved"}:
                body.append(
                    "Конкретный автоматический резерв пока не выбран: его можно определить только после подтверждения инфраструктуры считывателей."
                )
            if "missing_assisted_recovery" in types:
                body.append("Оператор используется только для ручной обработки исключительных ситуаций.")
            if "missing_required_tradeoff" in types:
                body.append(
                    "Карты требуют организации выдачи, возврата и контроля состояния, а билеты — расхода ленты и обслуживания механизма; "
                    "значимость различий зависит от потока и эксплуатации объекта."
                )
            if "missing_unknown_conditionality" in types:
                body.append("Наличие считывателей пока не подтверждено, поэтому неизвестную инфраструктуру нельзя считать выбранной.")
            package_question = str((decision_package or {}).get("next_question") or "").strip()
            if decision.should_ask_question and package_question:
                body.append(package_question)
            return " ".join(dict.fromkeys(item.strip() for item in body if item.strip()))
        if (decision_package or {}).get("schema_version") == "1.2" and types & {
            "semantic_architecture_mismatch",
            "manual_recovery_misclassified_as_fallback_identifier",
            "operator_as_automated_fallback", "unsupported_lane_guidance_claim",
            "fallback_not_segment_specific", "fallback_requires_unconfirmed_reader",
            "universal_operational_claim", "mixed_tradeoff_categories",
            "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
            "authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated",
        }:
            parts = [self._segment_plan_sentence(decision_package)]
            package_question = str((decision_package or {}).get("next_question") or "").strip()
            if decision.should_ask_question and package_question:
                parts.append(package_question)
            return " ".join(item for item in parts if item)
        questions = self._question_units(clean)
        output: list[str] = []
        for sentence in self._sentences(clean):
            if "?" in sentence:
                continue
            sentence_types = {item.type for item in violations if item.fragment and item.fragment in sentence or sentence in item.fragment}
            if "pii_leak" in sentence_types or "system_instruction_leakage" in sentence_types or "dangerous_instruction" in sentence_types:
                continue
            if "premature_contact_request" in sentence_types:
                continue
            if "unsupported_price" in sentence_types:
                output.append("Стоимость зависит от состава оборудования, количества въездов и требуемых функций.")
                continue
            if "unsupported_timeline" in sentence_types:
                output.append("Срок зависит от конфигурации, готовности объекта и объёма монтажных работ; его подтверждают после уточнения исходных данных.")
                continue
            if "unsupported_availability" in sentence_types:
                output.append("Наличие нужно подтвердить для выбранной комплектации.")
                continue
            if "unsupported_compatibility" in sentence_types:
                output.append("Совместимость нужно проверить по модели оборудования и интерфейсам подключения.")
                continue
            if "unsupported_guarantee" in sentence_types:
                output.append("Гарантийные условия нужно подтвердить для выбранной комплектации и договора.")
                continue
            if "unauthorized_discount" in sentence_types:
                output.append("Коммерческие условия согласует специалист после уточнения проекта.")
                continue
            if sentence_types & {"unsupported_technical_claim", "unknown_technical_claim"}:
                output.append("Такая функция может быть доступна в зависимости от конфигурации; её нужно проверить по составу оборудования.")
                continue
            if sentence_types & {
                "semantic_architecture_mismatch",
                "manual_recovery_misclassified_as_fallback_identifier",
                "operator_as_automated_fallback", "unsupported_lane_guidance_claim",
                "fallback_not_segment_specific",
                "fallback_requires_unconfirmed_reader",
                "authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated",
            }:
                replacement = self._segment_plan_sentence(decision_package)
                if replacement and replacement not in output:
                    output.append(replacement)
                continue
            if sentence_types & {
                "universal_operational_claim", "mixed_tradeoff_categories",
                "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
            }:
                output.append(
                    "Эксплуатационная нагрузка карт и билетов различается и зависит от потока, "
                    "процесса возврата карт и расхода билетной ленты."
                )
                continue
            if "partially_supported_technical_claim" in sentence_types:
                output.append(self._condition_sentence(sentence))
                continue
            repaired_sentence = MODEL_RE.sub("внутренний исполнитель", sentence)
            repaired_sentence = self._soften_pressure(repaired_sentence)
            if repaired_sentence.strip():
                output.append(repaired_sentence.strip())

        if LINK_ONLY_RE.match(clean):
            summary = self._knowledge_summary(confirmed_claims)
            output = [summary, clean] if summary else []

        package_question = str((decision_package or {}).get("next_question") or "").strip()
        if decision.should_ask_question and package_question:
            output.append(package_question)
        elif decision.should_ask_question and questions:
            eligible = [q for q in questions if not any(
                item.type in {"duplicate_question", "premature_contact_request"} and item.fragment in q
                for item in violations
            )]
            if eligible:
                selected = max(eligible, key=lambda item: self._question_score(item, decision.question_goal))
                selected = self._reduce_compound_question(selected, decision.question_goal)
                output.append(selected)
        repaired = " ".join(item.strip() for item in output if item.strip())
        return " ".join(repaired.split())

    @staticmethod
    def _identifier_mentioned(text: str, identifier: str) -> bool:
        patterns = {
            "guest_qr": r"\bqr\b", "parking_card": r"\bкарт\w*\b",
            "guest_card": r"\bкарт\w*\b", "radio_tag": r"\b(?:rfid|радиомет\w*)\b",
            "parking_ticket": r"\bбилет\w*\b",
        }
        pattern = patterns.get(identifier)
        return bool(pattern and re.search(pattern, text, re.I))

    @staticmethod
    def _segment_plan_sentence(decision_package: dict[str, Any] | None) -> str:
        if (decision_package or {}).get("schema_version") == "1.2":
            return (
                "Для сотрудников и арендаторов предварительно можно рассматривать распознавание номеров как основной способ проезда. "
                "Для гостей право доступа может формироваться через гостевую заявку, а идентификация — по заранее зарегистрированному номеру либо другому подтверждённому носителю. "
                "Автоматический резерв определяется отдельно для каждой категории после проверки установленного оборудования; оператор используется только для исключительных ситуаций. "
                "Карты и билеты создают разные виды эксплуатационной нагрузки, поэтому их нужно сравнивать по потоку, бесплатному периоду, возврату карт и расходу билетной ленты."
            )
        segments = ((decision_package or {}).get("recommended_architecture") or {}).get("segments") or {}
        if not segments:
            return "Автоматический резерв нужно определить отдельно по категориям пользователей после подтверждения считывателей."
        parts: list[str] = []
        if "employees" in segments or "tenants" in segments:
            parts.append("Для сотрудников и арендаторов основной способ — распознавание номеров")
        if "guests" in segments:
            parts.append("для гостей — заранее зарегистрированный номер или подтверждённая гостевая заявка")
        text = "; ".join(parts).rstrip(".") + "." if parts else ""
        confirmed = sorted({
            identifier
            for plan in segments.values()
            for identifier in plan.get("automated_fallback_identifiers") or []
        })
        if confirmed:
            text += " Подтверждённые автоматические резервы: " + ", ".join(confirmed) + "."
        else:
            text += " Автоматический резерв нужно определить отдельно для каждой группы после подтверждения считывателей."
        if any(plan.get("assisted_recovery") for plan in segments.values()):
            text += " Ручная проверка оператором применяется только как исключение."
        return " ".join(text.split())

    def _contract(self, clean: str, violations: list[RepairViolation]) -> RepairDecision:
        bad_fragments = {item.fragment for item in violations if item.fragment}
        preserved = tuple(
            sentence for sentence in self._sentences(clean)
            if sentence not in bad_fragments and "?" not in sentence
        )
        severity = "blocking" if any(item.severity == "blocking" for item in violations) else "repairable"
        return RepairDecision(True, severity, tuple(violations), preserved)

    def _specialized_fallback(
        self, violations: list[RepairViolation], decision: ControllerDecision
    ) -> tuple[str, str]:
        types = {item.type for item in violations}
        if "unsupported_price" in types:
            key = "price_configuration_required"
        elif types & {"unsupported_compatibility", "unsupported_technical_claim", "unknown_technical_claim", "partially_supported_technical_claim"}:
            key = "technical_verification_required"
        elif types & BLOCKING_TYPES:
            key = "human_review_required"
        else:
            key = "answer_without_sales_motion"
        answer = SPECIALIZED_FALLBACKS[key]
        if decision.should_ask_question:
            question = self._fallback_question(decision.question_goal)
            if question:
                answer += " " + question
        return key, answer

    @staticmethod
    def _fallback_question(goal: str) -> str:
        return {
            "identify_object_type": "Какой у вас тип объекта?",
            "identify_entrances_count": "Сколько у вас въездов?",
            "identify_current_system": "Какая система сейчас установлена?",
            "identify_current_problem": "Что именно не устраивает в текущей работе?",
            "identify_desired_outcome": "Какой результат для вас приоритетен?",
            "identify_real_objection": "Что именно вызывает сомнение?",
        }.get(goal, "")

    @staticmethod
    def _sentences(text: str) -> list[str]:
        return [" ".join(item.group(0).split()) for item in SENTENCE_RE.finditer(text) if item.group(0).strip()]

    @classmethod
    def _question_units(cls, text: str) -> list[str]:
        return [sentence for sentence in cls._sentences(text) if "?" in sentence]

    @classmethod
    def _sentence_for(cls, text: str, position: int) -> str:
        cursor = 0
        for sentence in cls._sentences(text):
            start = text.find(sentence, cursor)
            end = start + len(sentence)
            if start <= position <= end:
                return sentence
            cursor = max(end, cursor)
        return text

    @staticmethod
    def _normalize_question(text: str) -> str:
        return re.sub(r"\W+", " ", text.lower()).strip()

    @staticmethod
    def _is_compound_question(question: str) -> bool:
        lower = question.lower()
        dimensions = (
            ("какой объект", "тип объекта"), ("сколько въезд", "количество въезд", "сколько полос"),
            ("какая система", "что установлено", "модель контроллера"),
            ("что не устраивает", "не устраивает", "какая проблема"), ("какой результат", "что хотите"),
        )
        found = sum(any(term in lower for term in group) for group in dimensions)
        return found >= 2 and (" и " in lower or "," in lower)

    @staticmethod
    def _question_score(question: str, goal: str) -> int:
        lower = question.lower()
        goal_score = sum(term in lower for term in QUESTION_GOAL_TERMS.get(goal, ())) * 10
        technical_score = sum(term in lower for term in ("модель", "оборудование", "система", "контроллер", "интерфейс")) * 20
        narrowness = max(0, 8 - len(question.split()) // 3)
        return goal_score + technical_score + narrowness

    @staticmethod
    def _question_goal_match(question: str, goal: str) -> bool:
        lower = question.lower()
        return any(term in lower for term in QUESTION_GOAL_TERMS.get(goal, ()))

    @classmethod
    def _reduce_compound_question(cls, question: str, goal: str) -> str:
        if not cls._is_compound_question(question):
            return question
        parts = [item.strip(" ,?.") for item in re.split(r"\s+и\s+|,", question) if item.strip(" ,?.")]
        if not parts:
            return question
        selected = max(parts, key=lambda item: cls._question_score(item, goal))
        if not re.match(r"(?i)^(?:какой|какая|какие|сколько|что|где|когда|подскажите|правильно)", selected):
            selected = "Подскажите, " + selected[0].lower() + selected[1:]
        else:
            selected = selected[:1].upper() + selected[1:]
        return selected.rstrip(".?!") + "?"

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {
            token for token in re.findall(r"[a-zа-яё0-9]+", text.lower())
            if len(token) >= 3 and token not in STOPWORDS
        }

    @classmethod
    def _evidence_level(cls, claim: str, confirmed_claims: list[str]) -> str:
        if not confirmed_claims:
            return "unknown"
        claim_normalized = " ".join(claim.lower().split()).strip(" .!?")
        confirmed = " ".join(confirmed_claims).lower()
        if claim_normalized and claim_normalized in confirmed:
            return "verified"
        claim_tokens = cls._tokens(claim)
        if not claim_tokens:
            return "unknown"
        coverage = len(claim_tokens & cls._tokens(confirmed)) / len(claim_tokens)
        if coverage >= 0.55:
            return "supported"
        if coverage >= 0.25:
            return "partially_supported"
        return "unknown"

    @staticmethod
    def _condition_sentence(sentence: str) -> str:
        base = sentence.rstrip(".!?")
        base = re.sub(r"(?i)\b(?:точно|гарантированно|всегда|безусловно)\b\s*", "", base)
        return "В зависимости от конфигурации " + base[:1].lower() + base[1:] + "."

    @staticmethod
    def _soften_pressure(sentence: str) -> str:
        replacements = {
            "решайте сейчас": "решение можно принять после проверки исходных данных",
            "последний шанс": "один из возможных вариантов",
            "вы обязаны": "можно рассмотреть",
            "иначе потеряете": "это может повлиять на результат",
            "только сегодня": "после уточнения условий",
            "вам обязательно нужно": "можно рассмотреть",
            "нужно срочно": "стоит проверить",
            "лучше не откладывать": "можно запланировать следующий шаг",
            "оставьте контакт прямо сейчас": "можно продолжить консультацию здесь",
        }
        value = sentence
        for source, target in replacements.items():
            value = re.sub(re.escape(source), target, value, flags=re.I)
        return value

    @classmethod
    def _knowledge_summary(cls, confirmed_claims: list[str]) -> str:
        for claim in confirmed_claims:
            for sentence in cls._sentences(str(claim)):
                if len(sentence) >= 25:
                    return sentence[:280].rstrip() + ("…" if len(sentence) > 280 else "")
        return ""

    @classmethod
    def _useful_content_preserved(cls, original: str, repaired: str) -> bool:
        if repaired in SPECIALIZED_FALLBACKS.values() or repaired == SAFE_TEMPLATE:
            return False
        overlap = cls._tokens(original) & cls._tokens(repaired)
        return len(overlap) >= 3 or bool(re.search(r"https?://|/[-\w./]+", repaired))

    @staticmethod
    def _deduplicate_violations(items: list[RepairViolation]) -> list[RepairViolation]:
        result: list[RepairViolation] = []
        seen: set[tuple[str, str]] = set()
        for item in items:
            key = (item.type, item.fragment)
            if key not in seen:
                seen.add(key)
                result.append(item)
        return result
