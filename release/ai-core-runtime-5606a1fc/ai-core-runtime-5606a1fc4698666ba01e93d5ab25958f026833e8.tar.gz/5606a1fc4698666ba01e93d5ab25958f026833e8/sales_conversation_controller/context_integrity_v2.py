from __future__ import annotations

import ast
import operator
import re
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Callable

from .contracts import ControllerDecision, LeadCard


TRI = {"pass", "fail", "unknown"}
RELATIONS = {
    "standalone_request", "answer_to_previous_question", "answer_plus_new_request",
    "clarification", "correction", "confirmation", "rejection", "continuation",
    "reference_to_previous_topic", "request_to_recall", "request_for_source",
    "new_topic", "small_talk", "out_of_domain", "unclear",
}
COMMANDS = {
    "answer_directly", "give_link", "list_options", "compare_options", "remember_fact",
    "recall_facts", "ask_one_question", "stop_questions", "be_brief", "explain",
    "recommend", "summarize", "handoff",
}

OBJECT_TYPES = (
    ("shopping_center", re.compile(r"\b(?:торгов(?:ый|ого|ом)?\s+центр(?:а|е|ом)?|трц|тц)\b", re.I)),
    ("business_center", re.compile(r"\b(?:бизнес[- ]?центр(?:а|е|ом)?|бц)\b", re.I)),
    ("residential_complex", re.compile(r"\b(?:жил(?:ой|ого|ом)?\s+комплекс(?:а|е|ом)?|жк)\b", re.I)),
    ("warehouse", re.compile(r"\b(?:склад(?:а|е|ом)?|логистическ(?:ий|ого|ом)\s+комплекс(?:а|е|ом)?)\b", re.I)),
    ("hotel", re.compile(r"\b(?:гостиниц(?:а|ы|е)|отел(?:ь|я|е))\b", re.I)),
)
NUMBER_WORDS = {
    "один": 1, "одна": 1, "одно": 1, "два": 2, "две": 2, "три": 3,
    "четыре": 4, "пять": 5, "шесть": 6, "семь": 7, "восемь": 8,
    "девять": 9, "десять": 10, "двух": 2, "трёх": 3, "трех": 3,
}

LINK_TOPICS = {
    "online_payment": "/vozmozhnosti/onlain-oplata",
    "guest_access": "/vozmozhnosti/gostevie-klienti",
    "demo_catalog": "/demo",
    "guest_demo": "/demo/gostevaya-zayavka",
    "tenant_payment_demo": "/demo/web-skidki",
    "contacts": "/contacts",
    "capabilities": "/vozmozhnosti",
}

SOURCE_ROUTES = {
    "link_request": ("website_routes", "published_site_content"),
    "demo_link_request": ("website_routes", "demo_catalog"),
    "demo_catalog_request": ("website_routes", "demo_catalog"),
    "technical_question": ("technical_manual", "capability_document", "engineer_confirmed_practice"),
    "configuration_selection": ("capability_document", "technical_manual", "verified_case"),
    "comparison_request": ("capability_document", "technical_manual", "verified_case"),
    "support_request": ("support_manual", "verified_resolved_case"),
}

QUESTION_WORDS = re.compile(
    r"(?:^|[.!?]\s*|\b)(?:кто|что|как|почему|когда|где|какой|какая|какие|какое|"
    r"сколько|можно\s+ли|нужно\s+ли|произойд[её]т\s+ли)\b", re.I,
)
COMMAND_WORDS = re.compile(
    r"\b(?:дай|дайте|покажи|покажите|пришли|сравни|сравните|объясни|объясните|"
    r"порекомендуй|порекомендуйте|посоветуй|зафиксируй|запомни|вспомни|перечисли|задавай)\b", re.I,
)


@dataclass(frozen=True)
class TurnIngestion:
    conversation_id: str
    message_id: str
    timestamp: str
    raw_text: str
    normalized_text: str
    language: str = "ru"
    input_type: str = "text"
    ingested: bool = True
    processing_status: str = "pending"
    parent_turn_id: str | None = None
    reply_to_question_goal: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ExpectedQuestion:
    question_id: str
    question_goal: str
    question_text: str
    expected_answer_type: str
    allowed_values: list[str] = field(default_factory=list)
    asked_at_message_id: str = ""
    status: str = "active"
    answer_message_id: str | None = None
    closed_reason: str | None = None


@dataclass(frozen=True)
class AnswerLinkDecision:
    expected_question_id: str | None
    candidate_answer: Any
    answer_shape_match: bool
    semantic_match: bool
    independent_request_detected: bool
    link_confidence: float
    decision: str
    validator: str | None
    reason_codes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["reason_codes"] = list(self.reason_codes)
        return payload


@dataclass
class IntegrityState:
    confirmed_facts: dict[str, dict[str, Any]] = field(default_factory=dict)
    candidate_facts: list[dict[str, Any]] = field(default_factory=list)
    inferences: dict[str, dict[str, Any]] = field(default_factory=dict)
    conversation_preferences: dict[str, Any] = field(default_factory=dict)
    open_questions: list[dict[str, Any]] = field(default_factory=list)
    conflicts: list[dict[str, Any]] = field(default_factory=list)
    active_subject: dict[str, Any] | None = None
    subject_stack: list[dict[str, Any]] = field(default_factory=list)
    last_topic: str = ""
    last_intent: str = ""
    last_user_message_id: str = ""
    ingested_message_ids: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, value: dict[str, Any] | None) -> "IntegrityState":
        raw = value or {}
        defaults = asdict(cls())
        return cls(**{key: raw.get(key, default) for key, default in defaults.items()})

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RetrievalPlan:
    intent: str
    resolved_topic: str
    query: str
    required_artifact_type: str
    allowed_sources: tuple[str, ...]
    required_route: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["allowed_sources"] = list(self.allowed_sources)
        return payload


@dataclass(frozen=True)
class IntegrityResolution:
    ingestion: TurnIngestion
    version: str
    relation: str
    intent: str
    command: str
    resolved_topic: str
    topic_resolution: dict[str, Any]
    active_subject: dict[str, Any] | None
    resolved_text: str
    required_action: str
    command_requirements: dict[str, Any]
    action_dependency: dict[str, Any]
    sales_motion_allowed: bool
    question_allowed: bool
    answer_link: AnswerLinkDecision
    answered_question_ids: tuple[str, ...]
    extracted_facts: dict[str, Any]
    candidate_facts: tuple[dict[str, Any], ...]
    state_updates: dict[str, Any]
    retrieval: RetrievalPlan
    state_before: dict[str, Any]
    state_after: dict[str, Any]
    conflicts: tuple[dict[str, Any], ...]

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["ingestion"] = self.ingestion.to_dict()
        payload["answer_link"] = self.answer_link.to_dict()
        payload["answered_question_ids"] = list(self.answered_question_ids)
        payload["candidate_facts"] = list(self.candidate_facts)
        payload["retrieval"] = self.retrieval.to_dict()
        payload["conflicts"] = list(self.conflicts)
        return payload


@dataclass(frozen=True)
class FinalIntegrityResult:
    topic_assessment: dict[str, Any]
    command_assessment: dict[str, Any]
    fact_assessment: dict[str, Any]
    question_assessment: dict[str, Any]
    link_assessment: dict[str, Any]
    source_assessment: dict[str, Any]
    context_assessment: dict[str, Any]
    violations: tuple[str, ...]
    fallback_type: str | None = None
    fallback_answer: str | None = None

    @property
    def topic_match(self) -> bool:
        return self.topic_assessment.get("result") == "pass"

    @property
    def command_satisfied(self) -> bool:
        return self.command_assessment.get("result") == "pass"

    @property
    def uses_current_turn(self) -> bool:
        return self.context_assessment.get("uses_current_turn") == "pass"

    @property
    def uses_required_context(self) -> bool:
        return self.context_assessment.get("uses_required_context") == "pass"

    @property
    def contradicts_confirmed_facts(self) -> bool:
        return bool(self.fact_assessment.get("contradictions"))

    @property
    def passed(self) -> bool:
        return not any(
            assessment.get("result") == "fail"
            for assessment in (
                self.topic_assessment, self.command_assessment, self.fact_assessment,
                self.question_assessment, self.link_assessment, self.source_assessment,
                self.context_assessment,
            )
        )

    @property
    def proven_passed(self) -> bool:
        relevant = (
            self.topic_assessment, self.command_assessment, self.fact_assessment,
            self.question_assessment, self.link_assessment, self.source_assessment,
            self.context_assessment,
        )
        assessed = [item for item in relevant if item.get("result") != "unknown"]
        return bool(assessed) and all(item.get("result") == "pass" for item in assessed)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.update({
            "topic_match": self.topic_match,
            "command_satisfied": self.command_satisfied,
            "uses_current_turn": self.uses_current_turn,
            "uses_required_context": self.uses_required_context,
            "contradicts_confirmed_facts": self.contradicts_confirmed_facts,
            "passed": self.passed,
            "proven_passed": self.proven_passed,
        })
        payload["violations"] = list(self.violations)
        return payload


class ContextIntentIntegrityLayerV2:
    VERSION = "2.0"

    def process(
        self, *, conversation_id: str, message_id: str, raw_text: str,
        state: IntegrityState, recent_messages: list[dict[str, str]] | None = None,
        timestamp: str | None = None,
    ) -> IntegrityResolution:
        normalized = self.normalize(raw_text)
        before = state.to_dict()
        expected = self._active_expected(state)
        independent = self._independent_request(normalized)
        link = self._link_expected(normalized, expected, independent)
        intent, command = self._intent_command(normalized, "standalone_request")
        facts, candidates = self._extract_facts(normalized, link, expected, command, message_id)
        relation = self._relation(normalized, expected, link, independent, intent)
        if relation == "answer_to_previous_question":
            intent, command = "answer_to_agent_question", "remember_fact"
        elif relation == "answer_plus_new_request":
            intent, command = self._intent_command(normalized, relation)
        elif relation == "request_to_recall":
            intent, command = "recall_request", "recall_facts"
        elif relation == "request_for_source":
            intent, command = self._intent_command(normalized, relation)
        elif relation == "correction":
            intent, command = "correction", "remember_fact"

        topic_resolution = self._resolve_topic(normalized, state, relation, intent, command)
        topic = str(topic_resolution["topic"])
        answered = self._close_questions_by_facts(state, facts, message_id)
        updates = self._apply_preferences(state, normalized, command)
        conflicts = self._reconcile_facts(state, facts, message_id, relation)
        state.candidate_facts.extend(candidates)
        self._update_subject(state, topic_resolution, message_id)

        dependency = self._action_dependency(command, intent, state, conflicts)
        state.last_topic = topic or state.last_topic
        state.last_intent = intent
        state.last_user_message_id = message_id
        if message_id not in state.ingested_message_ids:
            state.ingested_message_ids.append(message_id)

        parent = expected.asked_at_message_id if expected and expected.question_id in answered else None
        reply_goal = expected.question_goal if expected and expected.question_id in answered else None
        ingestion = TurnIngestion(
            conversation_id=conversation_id, message_id=message_id,
            timestamp=timestamp or datetime.now(timezone.utc).isoformat(),
            raw_text=raw_text, normalized_text=normalized,
            parent_turn_id=parent, reply_to_question_goal=reply_goal,
        )
        retrieval = self.build_retrieval(intent, topic, normalized, state.active_subject)
        requirements = self._command_requirements(command, normalized, facts, retrieval)
        question_allowed = not bool(state.conversation_preferences.get("stop_questions"))
        if command in {"give_link", "be_brief", "stop_questions", "recall_facts"}:
            question_allowed = False
        resolution = IntegrityResolution(
            ingestion=ingestion, version=self.VERSION, relation=relation, intent=intent,
            command=command, resolved_topic=topic, topic_resolution=topic_resolution,
            active_subject=state.active_subject, resolved_text=self._resolved_text(
                normalized, relation, expected, link, topic, command
            ), required_action=self._required_action(intent, command),
            command_requirements=requirements, action_dependency=dependency,
            sales_motion_allowed=intent not in {
                "link_request", "identity_question", "simple_utility_question",
                "small_talk", "out_of_domain", "recall_request",
            }, question_allowed=question_allowed, answer_link=link,
            answered_question_ids=tuple(answered), extracted_facts=facts,
            candidate_facts=tuple(candidates), state_updates=updates,
            retrieval=retrieval, state_before=before, state_after=state.to_dict(),
            conflicts=tuple(conflicts),
        )
        return resolution

    @staticmethod
    def normalize(text: str) -> str:
        clean = " ".join(str(text or "").replace("\x00", " ").split()).lower()
        clean = re.sub(r"\b(?:сслылк|сылк)(\w*)\b", r"ссылк\1", clean)
        return clean.replace("демо доступ", "демодоступ").strip()

    def register_expected_question(
        self, state: IntegrityState, *, question_id: str, question_goal: str,
        question_text: str, asked_at_message_id: str,
    ) -> None:
        expected_type = {
            "permanent_users_share": "percentage", "identify_entrances_count": "count",
            "identify_exits_count": "count", "identify_object_type": "object_type",
            "identify_current_system": "current_system", "identify_timeline": "timeline",
            "identify_budget_status": "budget_status", "identify_location": "location",
        }.get(question_goal, "free_text")
        if state.conversation_preferences.get("question_mode", "one_at_a_time") == "one_at_a_time":
            for item in state.open_questions:
                if item.get("status", "active") == "active":
                    item["status"] = "superseded"
                    item["closed_reason"] = "new_question_registered"
        state.open_questions.append(asdict(ExpectedQuestion(
            question_id=question_id, question_goal=question_goal, question_text=question_text,
            expected_answer_type=expected_type, asked_at_message_id=asked_at_message_id,
        )))

    def question_matches_goal(self, question_text: str, question_goal: str) -> bool:
        text = self.normalize(question_text)
        patterns = {
            "permanent_users_share": r"\b(?:процент|доля)\b.*\b(?:постоянн|сотрудник|арендатор)",
            "identify_entrances_count": r"\bсколько\b.*\bвъезд",
            "identify_exits_count": r"\bсколько\b.*\bвыезд",
            "identify_object_type": r"\b(?:какой|тип)\b.*\bобъект|\b(?:тц|бц|жк|склад|гостиниц)",
            "identify_current_system": r"\b(?:какая|что|система|оборудован)\b.*\b(?:установ|использ|сейчас|стоит)",
            "identify_timeline": r"\b(?:когда|срок|планиру)\b",
            "identify_budget_status": r"\b(?:бюджет|финансирован)\b",
            "identify_location": r"\b(?:где|город|регион|находится)\b",
        }
        pattern = patterns.get(question_goal)
        return bool(pattern and re.search(pattern, text))

    def apply_to_lead_card(self, lead: LeadCard, resolution: IntegrityResolution, message_id: str) -> list[str]:
        mapping = {
            "object_type": "object_type", "entrances_count": "entrances_count",
            "exits_count": "exits_count", "current_system": "current_system",
            "location": "location",
        }
        added: list[str] = []
        confirmed_after = resolution.state_after.get("confirmed_facts", {})
        for fact, attr in mapping.items():
            record = confirmed_after.get(fact)
            if not record or record.get("source_message_id") != message_id:
                continue
            value = record.get("value")
            if getattr(lead, attr) != value:
                setattr(lead, attr, value)
                added.append(attr)
            lead.facts_source_messages[attr] = message_id
        return added

    def apply_to_decision(self, decision: ControllerDecision, resolution: IntegrityResolution) -> ControllerDecision:
        updates: dict[str, Any] = {"customer_intent": resolution.intent}
        forbidden = list(decision.forbidden_actions)
        if not resolution.sales_motion_allowed:
            forbidden.extend(("sales_motion", "request_contact", "use_loop"))
            updates.update(should_offer_next_step=False, should_request_contact=False, should_use_loop=False)
        if not resolution.question_allowed:
            forbidden.append("ask_question")
            updates.update(should_ask_question=False, question_goal="")
            if decision.next_best_action in {"answer_and_ask", "ask_clarifying_question"}:
                updates.update(next_best_action="answer_only", answer_required=True)
        actions = {
            "give_link": "answer_only", "recall_facts": "summarize_requirements",
            "compare_options": "compare_options", "recommend": "provide_recommendation",
            "summarize": "summarize_requirements", "list_options": "compare_options",
        }
        if resolution.command in actions:
            updates.update(next_best_action=actions[resolution.command], answer_required=True)
        if resolution.command in {"give_link", "recall_facts", "stop_questions"}:
            updates.update(should_ask_question=False, question_goal="")
        if resolution.action_dependency.get("blocking"):
            updates.update(next_best_action="ask_clarifying_question", should_ask_question=True)
        updates["forbidden_actions"] = tuple(dict.fromkeys(forbidden))
        return replace(decision, **updates)

    def final_check(self, answer: str, resolution: IntegrityResolution, state: IntegrityState) -> FinalIntegrityResult:
        clean = " ".join(str(answer or "").split())
        lower = clean.lower()
        topic = self._assess_topic(lower, resolution)
        command = self._assess_command(lower, resolution, state)
        contradictions = self._answer_contradictions(lower, state)
        fact_result = "fail" if contradictions else ("pass" if state.confirmed_facts else "unknown")
        fact = {"result": fact_result, "contradictions": contradictions, "unsupported_recalled_facts": []}
        semantic_questions = self.semantic_question_count(clean)
        required_count = 1 if resolution.command == "ask_one_question" else 0
        question_result = "pass" if resolution.command == "ask_one_question" and semantic_questions == 1 else (
            "fail" if resolution.command == "ask_one_question" else (
                "fail" if resolution.command == "stop_questions" and semantic_questions else "pass"
                if resolution.command == "stop_questions" else "unknown"
            )
        )
        question = {
            "result": question_result, "semantic_question_count": semantic_questions,
            "required_count": required_count,
        }
        required_route = resolution.retrieval.required_route
        routes = re.findall(r"(?:https?://\S+|/[-\w./]+)", clean)
        link_required = resolution.command == "give_link"
        if not link_required:
            link_result = "unknown"
        elif not required_route:
            link_result = "unknown"
        elif not routes:
            link_result = "fail"
        else:
            link_result = "pass" if required_route in routes else "fail"
        link = {
            "result": link_result, "required": link_required, "present": bool(routes),
            "route_verified": bool(required_route and required_route in routes),
            "required_route": required_route,
        }
        if resolution.retrieval.required_artifact_type == "website_page":
            source_result = link_result
            source_reason = "verified_website_route" if source_result == "pass" else "route_unverified" if source_result == "unknown" else "wrong_or_missing_route"
        else:
            source_result = "unknown"
            source_reason = "answer_has_no_machine_verifiable_source_citation"
        source = {
            "result": source_result, "required_artifact_type": resolution.retrieval.required_artifact_type,
            "allowed_sources": list(resolution.retrieval.allowed_sources), "reason": source_reason,
        }
        context_required = bool(resolution.answered_question_ids or resolution.command == "recall_facts")
        context_result = "pass" if clean and not contradictions else "fail" if not clean else "unknown"
        if context_required and resolution.command == "recall_facts":
            context_result = command["result"]
        context = {
            "result": context_result, "uses_current_turn": "pass" if clean else "fail",
            "uses_required_context": context_result if context_required else "unknown",
        }
        violations: list[str] = []
        for prefix, assessment in (("topic", topic), ("command", command), ("fact", fact), ("question", question), ("link", link), ("source", source), ("context", context)):
            if assessment.get("result") == "fail":
                violations.append(f"{prefix}_assessment_failed")
        violations.extend(command.get("missing_requirements", []))
        if contradictions:
            violations.append("confirmed_fact_contradiction")
        fallback_type, fallback = self._fallback(resolution, state, violations)
        return FinalIntegrityResult(
            topic_assessment=topic, command_assessment=command, fact_assessment=fact,
            question_assessment=question, link_assessment=link, source_assessment=source,
            context_assessment=context, violations=tuple(dict.fromkeys(violations)),
            fallback_type=fallback_type, fallback_answer=fallback,
        )

    def deterministic_answer(self, resolution: IntegrityResolution, state: IntegrityState) -> str | None:
        if resolution.command == "give_link":
            route = resolution.retrieval.required_route
            return f"Вот подтверждённая страница: `{route}`." if route else None
        if resolution.intent == "recall_request":
            conflicted = {item.get("field") for item in state.conflicts if item.get("status") == "open"}
            facts = [self._display_fact(key, item.get("value")) for key, item in state.confirmed_facts.items() if key not in conflicted]
            facts = [item for item in facts if item]
            conflicts = [item for item in state.conflicts if item.get("status") == "open"]
            parts = ["Вы сообщали: " + "; ".join(facts) + "."] if facts else ["Пока нет непротиворечивых подтверждённых параметров."]
            if conflicts:
                names = ", ".join(sorted({self._fact_label(item.get("field", "")) for item in conflicts}))
                parts.append(f"Отдельно нужно уточнить противоречие по полям: {names}.")
            return " ".join(parts)
        if resolution.intent == "simple_utility_question":
            return self._utility_answer(resolution.ingestion.normalized_text)
        if resolution.intent == "identity_question":
            return "Я AI-консультант РОСПАРК по вопросам автоматизации парковок."
        return None

    def build_retrieval(self, intent: str, topic: str, normalized: str, subject: dict[str, Any] | None) -> RetrievalPlan:
        allowed = SOURCE_ROUTES.get(intent, ("published_site_content", "capability_document"))
        artifact = "website_page" if intent in {"link_request", "demo_link_request", "demo_catalog_request"} else "knowledge_fragment"
        required_route = LINK_TOPICS.get(topic) if artifact == "website_page" else None
        subject_topic = str((subject or {}).get("topic") or "")
        query_topic = subject_topic if intent in {"link_request", "demo_link_request"} and subject_topic else topic
        prefix = "официальная страница сайта РОСПАРК " if artifact == "website_page" else "РОСПАРК "
        return RetrievalPlan(intent, topic, (prefix + (query_topic or normalized).replace("_", " ")).strip(), artifact, tuple(allowed), required_route)

    @staticmethod
    def semantic_question_count(text: str) -> int:
        count = 0
        for segment in re.findall(r"[^?]+\?", text):
            count += 1
            count += len(re.findall(r"\bи\s+(?:что|кто|как|какой|какая|какие|сколько|когда|где|почему)\b", segment.lower()))
        return count

    @staticmethod
    def _active_expected(state: IntegrityState) -> ExpectedQuestion | None:
        for raw in reversed(state.open_questions):
            status = raw.get("status", "answered" if raw.get("answered") else "active")
            if status == "active":
                clean = dict(raw)
                clean.pop("answered", None)
                clean.setdefault("status", status)
                clean.setdefault("closed_reason", None)
                return ExpectedQuestion(**clean)
        return None

    def _independent_request(self, text: str) -> bool:
        if COMMAND_WORDS.search(text):
            return True
        if re.search(r"\b(?:ссылк|расч[её]т|вспомни|что я сообщал|повтори параметры)\w*", text):
            return True
        if "?" in text and QUESTION_WORDS.search(text):
            return True
        if "?" in text and re.search(r"\b(?:меняет|работает|произойд|подойд|стоит|нуж|можн|выбрать|получить|организовать|зависит)\w*", text):
            return True
        return bool(QUESTION_WORDS.search(text) and re.search(r"\b(?:работает|произойд|подойд|стоит|нужн|можн|выбрать|получить|организовать)\w*", text))

    def _link_expected(self, text: str, expected: ExpectedQuestion | None, independent: bool) -> AnswerLinkDecision:
        if not expected:
            return AnswerLinkDecision(None, None, False, False, independent, 0.0, "not_linked", None, ("no_active_question",))
        validator = expected.expected_answer_type
        candidate = self._parse_expected(text, validator, expected.question_goal)
        shape = candidate is not None
        semantic = shape and self._semantic_answer_match(text, expected)
        embedded_answer = shape and independent and self._candidate_precedes_request(text, expected)
        if shape and semantic and not independent:
            return AnswerLinkDecision(expected.question_id, candidate, True, True, False, 0.98, "linked", validator, ("typed_validator_passed",))
        if shape and semantic and embedded_answer:
            return AnswerLinkDecision(expected.question_id, candidate, True, True, True, 0.94, "partially_linked", validator, ("typed_validator_passed", "independent_request_after_answer",))
        reasons = []
        if not shape: reasons.append("answer_shape_mismatch")
        if shape and not semantic: reasons.append("semantic_mismatch")
        if independent and not embedded_answer: reasons.append("independent_request_detected")
        decision = "ambiguous" if shape and independent else "not_linked"
        return AnswerLinkDecision(expected.question_id, candidate, shape, semantic, independent, 0.2 if shape else 0.0, decision, validator, tuple(reasons))

    def _relation(self, text: str, expected: ExpectedQuestion | None, link: AnswerLinkDecision, independent: bool, intent: str) -> str:
        if re.search(r"(?:^нет[, ]|\bисправ\w*|\bне\b.*\bа\b|\bя имел в виду\b)", text):
            return "correction"
        if link.decision == "partially_linked":
            return "answer_plus_new_request"
        if re.search(r"\b(?:я уже говорил|вспоминай|вспомни|что я сообщал|повтори параметры)\b", text):
            return "request_to_recall"
        if re.search(r"\bгде\b.*\b(?:прочитать|посмотреть)\b|\b(?:дай|дайте|покажи|покажите|пришли)\b.*\b(?:ссылк|страниц|раздел|демо)|\bссылк\w*", text):
            return "request_for_source"
        if link.decision == "linked":
            return "answer_to_previous_question"
        if independent:
            return "new_topic" if intent in {"identity_question", "simple_utility_question", "out_of_domain"} else "standalone_request"
        if len(text.split()) <= 4 and expected:
            return "unclear"
        return "standalone_request"

    def _intent_command(self, text: str, relation: str) -> tuple[str, str]:
        command = "explain" if re.search(r"\b(?:объясни|объясните)\b", text) else "answer_directly"
        if re.search(r"\b(?:я уже говорил|вспоминай|вспомни|что я сообщал|повтори параметры)\b", text): return "recall_request", "recall_facts"
        if re.search(r"\b(?:дай|дайте|покажи|покажите|пришли)\b.*\b(?:ссылк|страниц|раздел)|\bгде\b.*\b(?:прочитать|посмотреть)\b|\bссылк\w*", text): return "link_request", "give_link"
        if re.search(r"\b(?:дай|дайте|покажи|покажите|пришли)\b.*\bдемо\b|\bдемо(?:доступ|страниц|ссылк|каталог)", text): return "demo_link_request", "give_link"
        if re.search(r"\bзадавай\b.*\bпо одному\b", text): return "instruction_to_agent", "ask_one_question"
        if re.search(r"\b(?:не задавай|без вопросов|хватит вопросов)\b", text): return "instruction_to_agent", "stop_questions"
        if re.search(r"\b(?:кратко|короче|в двух словах)\b", text): command = "be_brief"
        if re.search(r"\b(?:зафиксируй|запомни|учти)\b", text): return "instruction_to_agent", "remember_fact"
        if re.search(r"\b(?:сравни|сравните|в ч[её]м отличие|чем отличается|разниц)\w*", text): return "comparison_request", "compare_options"
        if re.search(r"\b(?:что(?:\s+лучше)?\s+выбрать|что\s+лучше\b|что подойд|посоветуй|порекомендуй|порекомендуешь|порекомендуете|рекомендаци)\w*", text): return "configuration_selection", "recommend"
        if re.search(r"\b(?:сколько стоит|стоимость|цена|цены|цену|прайс)\b|\bстоит\s+\d[\d\s]*\s*(?:руб|₽)", text): return "price_request", command
        if re.search(r"\b(?:окупа|возврат инвестиц)\w*", text): return "roi_question", command
        if re.search(r"\b(?:расч[её]т|смета|коммерческ\w+ предложен|кп)\b", text): return "calculation_request", "handoff"
        if re.search(r"\b(?:следующий шаг|что дальше|как начать)\b", text): return "next_step_request", command
        if re.search(r"\b(?:не работает|сломал|ошибка|авария|поддержка|ремонт)\w*", text): return "support_request", command
        if re.search(r"\b(?:жалоба|претензия|недоволен|безобразие)\w*", text): return "complaint", command
        if self._is_identity(text): return "identity_question", command
        if self._is_utility(text): return "simple_utility_question", command
        if re.fullmatch(r"(?:привет|здравствуйте|добрый день|добрый вечер)[!. ]*", text): return "greeting", command
        if re.search(r"\b(?:демо|демонстрация|демодоступ)\w*", text): return "demo_catalog_request", "list_options"
        if re.search(r"\b(?:связаться|контакты|позвонить|телефон)\w*", text): return "contact_request", "handoff"
        if re.search(r"\b(?:шлагбаум|парковка|парковки|въезд|выезд|камера|rfid|qr-код|qr|билет|карт|госномер|диспенсер|рулон|опла[тч]|обслужив)\w*", text): return "technical_question", command
        if command == "explain": return "general_information", "explain"
        if "?" in text: return "general_information", command
        return "unclear", command

    def _resolve_topic(self, text: str, state: IntegrityState, relation: str, intent: str, command: str) -> dict[str, Any]:
        features: dict[str, list[tuple[re.Pattern[str], float, str]]] = {
            "access_configuration_by_user_segments": [
                (re.compile(r"\bбизнес[- ]?центр\w*\b"), .28, "business_center"),
                (re.compile(r"\bсотрудник\w*\b"), .2, "employees"),
                (re.compile(r"\bарендатор\w*\b"), .2, "tenants"),
                (re.compile(r"\bгост(?:ь|я|и|ей|ям)\b"), .2, "guests"),
                (re.compile(r"\b(?:порекомендуй|порекомендуешь|порекомендуете|посоветуй|что\s+подойд)\w*\b"), .18, "recommend"),
            ],
            "tenant_pays_guest_parking": [
                (re.compile(r"\b(?:арендатор\w*|организаци\w*)\b.*\bопла[тч]\w*\b.*\bгост\w*\b|\bгост\w*\b.*\bопла[тч]\w*\b.*\b(?:арендатор\w*|организаци\w*)\b|\bоплат\w*\b.*\bгост\w*\b.*\bарендатор\w*\b"), .96, "tenant_pays_guest"),
            ],
            "guest_self_payment": [
                (re.compile(r"\bгост\w*\b.*\b(?:самостоятельн\w*\s+)?(?:опла[тч]|плат)\w*\b|\bсамостоятельн\w*\b.*\b(?:опла[тч]|плат)\w*\b|\b(?:опла[тч]|плат)\w*\b.*\bгост\w*\b"), .9, "guest_self_payment"),
            ],
            "online_payment": [(re.compile(r"\bонлайн[- ]?оплат\w*\b|\bопла[тч]\w*\b.*\bонлайн\b|\bонлайн\b.*\bопла[тч]\w*\b"), .95, "online_payment")],
            "guest_access": [(re.compile(r"\bгостев\w*\s+(?:доступ|въезд|заявк)\w*\b|\bгост\w*\b.*\b(?:въезд|заявк|доступ)\w*\b"), .92, "guest_access")],
            "comparison_identifiers": [
                (re.compile(r"\b(?:госномер\w*|государственн\w+\s+номер\w*)\b"), .25, "license_plate"),
                (re.compile(r"\b(?:rfid[- ]?)?карт\w*\b"), .25, "card"),
                (re.compile(r"\bбилет(?:ы|а|ов|ами)?\b"), .25, "ticket"),
                (re.compile(r"\b(?:сравни|сравните|отлич|разниц)\w*\b"), .25, "comparison"),
            ],
            "qr_entry_station": [(re.compile(r"\bqr[- ]?код\w*\b.*\b(?:стойк\w*|въезд\w*)\b|\b(?:стойк\w*|въезд\w*)\b.*\bqr[- ]?код\w*\b"), .95, "qr_entry_station")],
            "card_distribution": [(re.compile(r"\b(?:выдач\w*|выдава\w*|получ\w*)\b.*\bкарт\w*\b|\bдиспенсер\w*\b"), .9, "card_distribution")],
            "pricing": [(re.compile(r"\b(?:цена|цены|цену|стоимость|прайс|окупаемость|расч[её]т стоимости|сколько стоит)\b|\bстоит\s+\d[\d\s]*\s*(?:руб|₽)"), .9, "pricing")],
            "parking_access": [(re.compile(r"\b(?:въезд|выезд|шлагбаум|пропускная способность)\w*\b"), .55, "parking_access")],
            "assistant_identity": [(re.compile(r"\b(?:кто ты|ты кто|что ты такое)\b"), 1.0, "identity")],
            "utility": [(re.compile(r"\b(?:сколько будет|день недели)\b"), 1.0, "utility")],
        }
        scores: dict[str, float] = {}
        matched: dict[str, list[str]] = {}
        for topic, rules in features.items():
            for pattern, weight, label in rules:
                if pattern.search(text):
                    scores[topic] = min(1.0, scores.get(topic, 0.0) + weight)
                    matched.setdefault(topic, []).append(label)
        if intent == "identity_question": scores["assistant_identity"] = 1.0
        if intent == "simple_utility_question": scores["utility"] = 1.0
        if intent == "configuration_selection" and "access_configuration_by_user_segments" in scores:
            scores["access_configuration_by_user_segments"] = min(1.0, scores["access_configuration_by_user_segments"] + .15)
        if command == "compare_options" and "comparison_identifiers" in scores:
            scores["comparison_identifiers"] = min(1.0, scores["comparison_identifiers"] + .25)

        pronoun_reference = bool(re.search(r"\b(?:это|этот|эта|эти|этих|этого|этому|этим|такой|такого|таким|таком|сценари(?:й|ем)|вариант(?:ы|ах))\b", text))
        active = state.active_subject or (state.subject_stack[-1] if state.subject_stack else None)
        if command == "give_link" and pronoun_reference and active:
            active_topic = str(active.get("topic") or "")
            route_topic = {
                "tenant_pays_guest_parking": "tenant_payment_demo",
                "guest_self_payment": "online_payment",
                "guest_access": "guest_demo" if "демо" in text else "guest_access",
            }.get(active_topic, active_topic)
            return {
                "topic": route_topic, "scores": {route_topic: float(active.get("confidence", .8))},
                "matched_features": ["structured_subject_reference"], "rejected_features": [],
                "confidence": float(active.get("confidence", .8)), "source": "active_subject",
            }
        if command == "give_link" and "демо" in text and "гост" in text:
            return {"topic": "guest_demo", "scores": {"guest_demo": .98}, "matched_features": ["guest_demo_phrase"], "rejected_features": [], "confidence": .98, "source": "current_turn"}
        if command == "give_link" and "демо" in text:
            return {"topic": "demo_catalog", "scores": {"demo_catalog": .9}, "matched_features": ["demo_phrase"], "rejected_features": [], "confidence": .9, "source": "current_turn"}
        if command == "give_link" and re.search(r"\bконтакт\w*\b", text):
            return {"topic": "contacts", "scores": {"contacts": .95}, "matched_features": ["contacts"], "rejected_features": [], "confidence": .95, "source": "current_turn"}
        if command == "give_link" and re.search(r"\bвозможност\w*\b", text):
            return {"topic": "capabilities", "scores": {"capabilities": .95}, "matched_features": ["capabilities"], "rejected_features": [], "confidence": .95, "source": "current_turn"}
        if pronoun_reference and active and not scores:
            inherited = str(active.get("topic") or state.last_topic)
            return {"topic": inherited, "scores": {inherited: float(active.get("confidence", .7))}, "matched_features": ["structured_subject_reference"], "rejected_features": [], "confidence": float(active.get("confidence", .7)), "source": "active_subject"}
        if pronoun_reference and active and scores and max(scores.values()) < float(active.get("confidence", .7)):
            inherited = str(active.get("topic") or state.last_topic)
            return {"topic": inherited, "scores": {**scores, inherited: float(active.get("confidence", .7))}, "matched_features": ["structured_subject_reference"], "rejected_features": ["weaker_current_turn_features"], "confidence": float(active.get("confidence", .7)), "source": "active_subject"}
        if not scores and relation in {"request_for_source", "continuation", "reference_to_previous_topic"} and active:
            inherited = str(active.get("topic") or state.last_topic)
            return {"topic": inherited, "scores": {inherited: float(active.get("confidence", .7))}, "matched_features": ["structured_subject_reference"], "rejected_features": [], "confidence": float(active.get("confidence", .7)), "source": "active_subject"}
        if scores:
            topic = max(scores, key=scores.get)
            if scores[topic] < .5:
                return {"topic": "general", "scores": scores, "matched_features": [], "rejected_features": ["insufficient_topic_score"], "confidence": scores[topic], "source": "unknown"}
            return {"topic": topic, "scores": scores, "matched_features": matched.get(topic, []), "rejected_features": ["substring:цен", "substring:номер", "substring:карта", "substring:оплат"], "confidence": scores[topic], "source": "current_turn"}
        return {"topic": "general", "scores": {}, "matched_features": [], "rejected_features": ["no_supported_topic_feature"], "confidence": 0.0, "source": "unknown"}

    def _extract_facts(
        self, text: str, link: AnswerLinkDecision, expected: ExpectedQuestion | None,
        command: str, message_id: str,
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        facts: dict[str, Any] = {}
        candidates: list[dict[str, Any]] = []
        if expected and link.decision in {"linked", "partially_linked"} and link.candidate_answer is not None:
            facts[self._goal_field(expected.question_goal)] = link.candidate_answer
        for value, pattern in OBJECT_TYPES:
            if pattern.search(text): facts["object_type"] = value
        for key, noun in (("entrances_count", "въезд"), ("exits_count", "выезд")):
            match = re.search(rf"\b(\d{{1,3}}|{'|'.join(NUMBER_WORDS)})\s+{noun}(?:а|ов|ы|ах|е)?\b", text)
            if match: facts[key] = self._number(match.group(1))
        traffic_range = re.search(
            r"\b(\d{2,6})\s*[–—-]\s*(\d{2,6})\s+(?:автомобил\w*|машин\w*)\b",
            text,
        )
        if traffic_range:
            lower, upper = sorted((int(traffic_range.group(1)), int(traffic_range.group(2))))
            facts["daily_traffic"] = upper
            facts["daily_traffic_certainty"] = "range_upper_bound"
            facts["daily_traffic_range"] = [lower, upper]
        else:
            traffic = re.search(
                r"\b(?:(около|примерно|до)\s+)?(\d{2,6})\s+"
                r"(?:автомобил\w*|машин\w*)\b",
                text,
            )
            if traffic:
                facts["daily_traffic"] = int(traffic.group(2))
                certainty = {
                    "около": "approximate",
                    "примерно": "approximate",
                    "до": "upper_bound",
                }.get(traffic.group(1) or "")
                if certainty:
                    facts["daily_traffic_certainty"] = certainty
        segments = [
            canonical
            for pattern, canonical in (
                (r"\bсотрудник\w*\b", "employees"),
                (r"(?<!\w)арендатор\w*\b", "tenants"),
                (r"\bгост(?:ь|я|ю|ем|и|ей|ям|ями|ях)\b", "guests"),
            )
            if re.search(pattern, text)
        ]
        if segments:
            facts["user_segments"] = list(dict.fromkeys(segments))
        operator_absent = bool(re.search(
            r"\b(?:без\s+(?:постоянн\w+\s+)?оператор\w*|"
            r"оператор(?:а)?\s+(?:нет|не\s+будет|отсутств\w*)|"
            r"не\s+будет\s+(?:постоянн\w+\s+)?оператор\w*)\b",
            text,
        ))
        operator_present = bool(re.search(
            r"\b(?:оператор\w*\s+(?:есть|будет|присутств\w*)|"
            r"(?:есть|будет)\s+(?:постоянн\w+\s+)?оператор\w*)\b",
            text,
        ))
        if operator_absent:
            facts["operator_present"] = False
        elif operator_present:
            facts["operator_present"] = True
        if re.search(
            r"\b(?:максимальн\w+\s+быстр\w+\s+(?:автоматическ\w+\s+)?проезд\w*|"
            r"приоритет\w*.{0,30}\bскорост\w*|"
            r"(?:главн\w*|важн\w*)\w*.{0,30}\b(?:скорост\w*|быстр\w+\s+проезд\w*))\b",
            text,
        ):
            facts["speed_priority"] = "high"
        fallback_required = bool(re.search(
            r"\b(?:обязательн\w*|нужен|нужна|нужно|требуется)"
            r".{0,60}\b(?:автоматическ\w+\s+)?резерв\w*|"
            r"\b(?:автоматическ\w+\s+)?резерв\w*.{0,60}"
            r"\b(?:обязател\w*|нужен|нужна|нужно|требуется)\b",
            text,
        ))
        if fallback_required:
            facts["mandatory_automated_fallback"] = True
        percent = self._validate_percentage(text)
        if percent is not None and "permanent_users_share" not in facts:
            candidates.append({
                "field": "permanent_users_share", "value": percent,
                "source_message_id": message_id, "status": "unattached",
                "confidence": .55, "source_reason": "standalone_percentage_heuristic",
            })
        price = re.search(r"\b(\d[\d\s]{0,8})\s*(?:руб(?:лей|ля|ль)?|₽)\b", text)
        if price and (command == "remember_fact" or re.search(r"\b(?:стоит|цена|тариф|въезд)\b", text)):
            facts["entry_price_rub"] = int(price.group(1).replace(" ", ""))
            facts["entry_price_rub__fact_type"] = "client_constraint"
        return facts, candidates

    def _close_questions_by_facts(self, state: IntegrityState, facts: dict[str, Any], message_id: str) -> list[str]:
        answered: list[str] = []
        for item in state.open_questions:
            status = item.get("status", "answered" if item.get("answered") else "active")
            if status != "active": continue
            field = self._goal_field(str(item.get("question_goal") or ""))
            if field not in facts: continue
            item.update(status="answered", answer_message_id=message_id, closed_reason="matching_fact_extracted")
            item.pop("answered", None)
            answered.append(str(item.get("question_id")))
        return answered

    def _reconcile_facts(self, state: IntegrityState, facts: dict[str, Any], message_id: str, relation: str) -> list[dict[str, Any]]:
        conflicts: list[dict[str, Any]] = []
        for key, value in facts.items():
            if key.endswith("__fact_type"):
                continue
            old = state.confirmed_facts.get(key)
            record = {"value": value, "source_message_id": message_id, "confirmed_at": datetime.now(timezone.utc).isoformat()}
            fact_type = facts.get(key + "__fact_type")
            if fact_type: record["fact_type"] = fact_type
            if old and old.get("value") != value:
                if relation == "correction":
                    record["replaces_source_message_id"] = old.get("source_message_id")
                    state.confirmed_facts[key] = record
                    for conflict in state.conflicts:
                        if conflict.get("field") == key and conflict.get("status") == "open": conflict["status"] = "resolved_by_correction"
                    continue
                conflict = {
                    "field": key, "old_value": old.get("value"), "new_value": value,
                    "old_source_message_id": old.get("source_message_id"),
                    "new_source_message_id": message_id, "status": "open",
                }
                state.conflicts.append(conflict)
                conflicts.append(conflict)
                continue
            state.confirmed_facts[key] = record
        return conflicts

    def _update_subject(self, state: IntegrityState, topic_resolution: dict[str, Any], message_id: str) -> None:
        topic = str(topic_resolution.get("topic") or "")
        if topic in {"general", "assistant_identity", "utility", "pricing"} or not topic_resolution.get("confidence"):
            return
        entities: dict[str, str] = {}
        action = ""
        if topic == "tenant_pays_guest_parking": entities = {"payer": "tenant", "parking_user": "guest"}; action = "pay_parking"
        if topic == "guest_self_payment": entities = {"payer": "guest", "parking_user": "guest"}; action = "pay_parking"
        subject = {
            "topic": topic, "entities": entities, "action": action,
            "source_message_ids": [message_id],
            "confidence": float(topic_resolution.get("confidence", 0.0)),
            "status": "active",
        }
        if state.active_subject and state.active_subject.get("topic") == topic:
            subject["source_message_ids"] = list(dict.fromkeys(state.active_subject.get("source_message_ids", []) + [message_id]))
        elif state.active_subject:
            previous = dict(state.active_subject); previous["status"] = "recent"
            state.subject_stack.append(previous)
        state.active_subject = subject
        state.subject_stack = (state.subject_stack + [subject])[-5:]

    def _action_dependency(self, command: str, intent: str, state: IntegrityState, conflicts: list[dict[str, Any]]) -> dict[str, Any]:
        required = {
            "recommend": ["object_type", "entrances_count", "daily_traffic"],
            "compare_options": [], "give_link": [], "recall_facts": [],
            "handoff": ["object_type"],
        }.get(command, [])
        open_conflicts = [item for item in state.conflicts if item.get("status") == "open"]
        conflicting_required = sorted({item["field"] for item in open_conflicts if item.get("field") in required})
        return {
            "action": command if command != "answer_directly" else intent,
            "required_facts": required,
            "conflicting_required_facts": conflicting_required,
            "blocking": bool(conflicting_required),
        }

    def _command_requirements(self, command: str, text: str, facts: dict[str, Any], retrieval: RetrievalPlan) -> dict[str, Any]:
        requirements: dict[str, Any] = {"command": command}
        option_patterns = {
            "license_plate": r"\b(?:госномер\w*|номер\w*\s+автомобил\w*)\b",
            "card": r"\b(?:rfid[- ]?)?карт\w*\b", "ticket": r"\bбилет\w*\b",
            "qr": r"\bqr[- ]?код\w*\b",
        }
        dimension_patterns = {
            "speed": r"\bскорост\w*\b", "convenience": r"\bудобств\w*\b",
            "reliability": r"\bнад[её]жност\w*\b", "cost": r"\b(?:цен|стоимост)\w*\b",
        }
        if command == "compare_options":
            requirements["required_options"] = [key for key, pattern in option_patterns.items() if re.search(pattern, text)]
            requirements["required_dimensions"] = [key for key, pattern in dimension_patterns.items() if re.search(pattern, text)]
        if command == "give_link": requirements["required_route"] = retrieval.required_route
        if command == "remember_fact": requirements["required_fact_names"] = [key for key in facts if not key.endswith("__fact_type")]
        if command == "ask_one_question": requirements["required_semantic_question_count"] = 1
        if command == "stop_questions": requirements["required_semantic_question_count"] = 0
        return requirements

    def _assess_topic(self, answer: str, resolution: IntegrityResolution) -> dict[str, Any]:
        topic = resolution.resolved_topic
        if resolution.retrieval.required_route and resolution.retrieval.required_route in answer:
            return {"result": "pass", "confidence": 1.0, "evidence": [resolution.retrieval.required_route], "reason": "verified_route_matches_topic"}
        evidence_patterns = {
            "access_configuration_by_user_segments": r"\b(?:сотрудник|арендатор|гост|абонемент|гостев\w+ заявк|распознаван\w+ номер)\w*",
            "tenant_pays_guest_parking": r"\b(?:арендатор|организаци\w*)\b.*\b(?:оплат|сесс|гост)\w*|\bгост\w*\b.*\b(?:арендатор|организаци|оплат)\w*",
            "tenant_payment_demo": re.escape(LINK_TOPICS["tenant_payment_demo"]),
            "guest_self_payment": r"\bгост\w*\b.*\bоплат\w*\b|\bоплат\w*\b.*\bгост\w*\b",
            "online_payment": r"\b(?:онлайн[- ]?оплат|оплат\w*\s+(?:через|по)\s+(?:сайт|сбп|qr))\w*",
            "guest_access": r"\bгостев\w*\b|/vozmozhnosti/gostevie-klienti",
            "guest_demo": re.escape(LINK_TOPICS["guest_demo"]),
            "demo_catalog": r"/demo\b|\bдемо\w*\b",
            "contacts": r"/contacts\b|\bконтакт\w*\b",
            "comparison_identifiers": r"\b(?:госномер|карт|билет|rfid|qr)\w*",
            "qr_entry_station": r"\bqr[- ]?код\w*\b.*\b(?:стойк|въезд)\w*|\b(?:стойк|въезд)\w*.*\bqr[- ]?код\w*",
            "card_distribution": r"\b(?:карт|диспенсер|выдач)\w*",
            "pricing": r"\b(?:стоимост|цена|тариф|расч[её]т)\w*",
            "parking_access": r"\b(?:въезд|выезд|шлагбаум|проезд)\w*",
            "assistant_identity": r"\b(?:ai-консультант|ии-консультант|помощник|консультант)\b",
            "utility": r"(?:=\s*-?\d|сегодня\s+(?:понедельник|вторник|среда|четверг|пятница|суббота|воскресенье))",
        }
        pattern = evidence_patterns.get(topic)
        if not pattern:
            return {"result": "unknown", "confidence": 0.0, "evidence": [], "reason": "no_topic_contract"}
        matches = re.findall(pattern, answer, re.I)
        result = "pass" if matches else "fail"
        return {"result": result, "confidence": .95 if matches else .9, "evidence": [str(item) for item in matches[:5]], "reason": "topic_evidence_present" if matches else "topic_evidence_missing"}

    def _assess_command(self, answer: str, resolution: IntegrityResolution, state: IntegrityState) -> dict[str, Any]:
        command = resolution.command
        requirements = resolution.command_requirements
        missing: list[str] = []
        evidence: dict[str, Any] = {}
        if command == "answer_directly":
            return {"command": command, "result": "unknown", "missing_requirements": [], "evidence": {}, "reason": "no_explicit_command"}
        if command == "give_link":
            route = requirements.get("required_route")
            if not route: return {"command": command, "result": "unknown", "missing_requirements": ["route_not_resolved"], "evidence": {}, "reason": "unknown_route"}
            if route not in answer: missing.append("verified_route_missing")
            evidence["required_route"] = route
        elif command == "compare_options":
            synonyms = {
                "license_plate": r"\b(?:госномер|номер\w*\s+автомобил)\w*", "card": r"\b(?:rfid[- ]?)?карт\w*",
                "ticket": r"\bбилет\w*", "qr": r"\bqr[- ]?код\w*",
                "speed": r"\b(?:скорост|быстр|медлен)\w*", "convenience": r"\bудоб\w*", "reliability": r"\bнад[её]ж\w*", "cost": r"\b(?:цен|стоимост)\w*",
            }
            covered_options = [item for item in requirements.get("required_options", []) if re.search(synonyms[item], answer)]
            covered_dimensions = [item for item in requirements.get("required_dimensions", []) if re.search(synonyms[item], answer)]
            evidence.update(covered_options=covered_options, covered_dimensions=covered_dimensions)
            if set(covered_options) != set(requirements.get("required_options", [])): missing.append("options_not_compared")
            if set(covered_dimensions) != set(requirements.get("required_dimensions", [])): missing.append("dimensions_not_covered")
            if not re.search(r"\b(?:а|но|тогда как|в отличие|быстр|удоб|над[её]ж|требу|подход)\w*", answer): missing.append("comparison_not_present")
        elif command == "recommend":
            if not re.search(r"\b(?:рекоменду|оптималь|лучше использовать|подойд[её]т|предварительн\w+ вариант)\w*", answer): missing.append("recommendation_missing")
            if not re.search(r"\b(?:потому что|так как|учитывая|для|при|это позволит|зависит)\b", answer): missing.append("recommendation_basis_missing")
        elif command == "ask_one_question":
            if self.semantic_question_count(answer) != 1: missing.append("exactly_one_semantic_question_required")
        elif command == "stop_questions":
            if self.semantic_question_count(answer) != 0: missing.append("questions_must_be_absent")
        elif command == "remember_fact":
            required = requirements.get("required_fact_names", [])
            saved = [name for name in required if name in state.confirmed_facts]
            evidence["saved_facts"] = saved
            if set(saved) != set(required): missing.append("facts_not_saved")
            if required and not any(self._answer_mentions_fact(answer, name, state.confirmed_facts[name].get("value")) for name in saved): missing.append("saved_facts_not_confirmed_to_client")
        elif command == "recall_facts":
            safe = {key: value for key, value in state.confirmed_facts.items() if not any(item.get("field") == key and item.get("status") == "open" for item in state.conflicts)}
            missing_values = [key for key, value in safe.items() if not self._answer_mentions_fact(answer, key, value.get("value"))]
            if missing_values: missing.append("confirmed_facts_missing")
            if state.conflicts and not re.search(r"\b(?:противореч|уточнить|конфликт)\w*", answer): missing.append("conflicts_not_separated")
        elif command == "list_options":
            option_hits = len(re.findall(r"(?:^|[;:]|\d+[.)]|[-—])\s*[^.;]+", answer))
            if option_hits < 2 and len(re.findall(r"\b(?:госномер|карт|билет|qr|демо)\w*", answer)) < 2: missing.append("options_list_missing")
        elif command == "summarize":
            if state.confirmed_facts and not any(self._answer_mentions_fact(answer, key, item.get("value")) for key, item in state.confirmed_facts.items()): missing.append("summary_missing_confirmed_facts")
        elif command == "handoff":
            if not re.search(r"\b(?:специалист|инженер|менеджер|расч[её]т|консультаци|контакт|продолжить)\w*", answer): missing.append("handoff_action_missing")
        elif command == "be_brief":
            if len(answer) > 500: missing.append("brevity_violated")
        else:
            return {"command": command, "result": "unknown", "missing_requirements": [], "evidence": {}, "reason": "no_command_contract"}
        return {"command": command, "result": "fail" if missing else "pass", "missing_requirements": missing, "evidence": evidence, "reason": "requirements_checked"}

    def _fallback(self, resolution: IntegrityResolution, state: IntegrityState, violations: list[str]) -> tuple[str | None, str | None]:
        if "link_assessment_failed" in violations or "verified_route_missing" in violations:
            route = resolution.retrieval.required_route
            return ("known_link", f"Вот подтверждённая страница: `{route}`.") if route else ("link_not_found", "Не нашёл подтверждённую страницу по этой теме. Уточните, к какому сценарию нужна ссылка?")
        if resolution.action_dependency.get("blocking"):
            fields = ", ".join(self._fact_label(item) for item in resolution.action_dependency.get("conflicting_required_facts", []))
            return "relevant_context_conflict", f"Для этого ответа нужно уточнить противоречие по полям: {fields}."
        if resolution.command == "recall_facts" and "command_assessment_failed" in violations:
            return "safe_recall", self.deterministic_answer(resolution, state)
        if resolution.relation == "request_for_source" and not resolution.retrieval.required_route:
            return "unclear_reference", "Уточните, к какому именно сценарию нужна ссылка?"
        return None, None

    @staticmethod
    def _apply_preferences(state: IntegrityState, text: str, command: str) -> dict[str, Any]:
        updates: dict[str, Any] = {}
        if command == "ask_one_question": updates["question_mode"] = "one_at_a_time"
        if command == "stop_questions": updates["stop_questions"] = True
        if command == "be_brief" or re.search(r"\b(?:кратко|короче|в двух словах)\b", text): updates["response_length"] = "brief"
        if re.search(r"\b(?:можно снова задавать|задавай вопросы)\b", text): updates["stop_questions"] = False
        state.conversation_preferences.update(updates)
        return updates

    def _parse_expected(self, text: str, answer_type: str, goal: str) -> Any:
        validators: dict[str, Callable[[str], Any]] = {
            "percentage": self._validate_percentage, "count": lambda value: self._validate_count(value, goal),
            "object_type": self._validate_object_type, "current_system": self._validate_current_system,
            "timeline": self._validate_timeline, "location": self._validate_location,
            "budget_status": self._validate_budget, "free_text": self._validate_free_text,
        }
        validator = validators.get(answer_type)
        return validator(text) if validator else None

    @staticmethod
    def _validate_percentage(text: str) -> float | None:
        match = re.search(r"(?:^|\b)(?:около\s+|примерно\s+)?(\d{1,3}(?:[.,]\d+)?)\s*(?:%(?=\s|$)|процент\w*\b)", text)
        if match: return float(match.group(1).replace(",", ".")) / 100
        if re.search(r"\bпримерно\s+треть\b|\bоколо\s+трети\b|\bтреть\b", text): return 1 / 3
        return None

    def _validate_count(self, text: str, goal: str) -> int | None:
        noun = "въезд" if "entrances" in goal else "выезд" if "exits" in goal else ""
        token = rf"(\d{{1,6}}|{'|'.join(NUMBER_WORDS)})"
        if noun:
            match = re.search(rf"\b{token}\s+{noun}(?:а|ов|ы|ах|е)?\b", text)
            if match: return self._number(match.group(1))
        match = re.fullmatch(rf"\s*{token}\s*", text)
        return self._number(match.group(1)) if match else None

    @staticmethod
    def _validate_object_type(text: str) -> str | None:
        for value, pattern in OBJECT_TYPES:
            if pattern.search(text): return value
        return None

    @staticmethod
    def _answer_clause(text: str) -> str:
        return re.split(r"[.!?]", text, maxsplit=1)[0].strip()

    @classmethod
    def _validate_current_system(cls, text: str) -> str | None:
        clause = cls._answer_clause(text)
        if QUESTION_WORDS.search(clause) or COMMAND_WORDS.search(clause): return None
        if re.search(r"\b(?:с\s+нуля|нов(?:ое|ая|ый)\s+(?:строительство|проект|система)|проектиру\w*\s+с\s+нуля)\b", clause):
            return "new_build"
        if re.search(r"\b(?:систем\w*|оборудован\w*)\b.*\b(?:установлен\w*|работает|есть)\b", clause):
            return "existing"
        patterns = (
            r"\bпока\s+(?:ничего|никакой)\b", r"\b(?:используем|установлен|стоит|есть)\b.*\b(?:систем|шлагбаум|паркомат|карт|билет|камера)\w*",
            r"\b(?:нет|всё|все)\b.*\b(?:вручную|ручн)\w*", r"\bстар\w+\s+систем\w*",
        )
        return clause if any(re.search(pattern, clause) for pattern in patterns) else None

    @classmethod
    def _validate_timeline(cls, text: str) -> str | None:
        clause = cls._answer_clause(text)
        return clause if re.search(r"\b(?:в этом году|до\s+[а-яё]+|за\s+(?:\d+|один|два|три|четыре)\s+(?:дн|недел|месяц)|срок\s+не определ[её]н|пока\s+срок)\w*", clause) else None

    @classmethod
    def _validate_location(cls, text: str) -> str | None:
        clause = re.sub(r"^(?:нет,?\s*|исправляю:\s*)", "", cls._answer_clause(text))
        return clause if re.fullmatch(r"(?:объект\s+в\s+)?[а-яё-]+(?:\s+(?:область|край|республика))?", clause) and not re.search(r"\b(?:систем|шлагбаум|камера|оплата|парковка)\b", clause) else None

    @classmethod
    def _validate_budget(cls, text: str) -> str | None:
        clause = cls._answer_clause(text)
        return clause if re.search(r"\b(?:бюджет|финансирован)\w*\b", clause) and re.search(r"\b(?:утвержд|нет|пока|до\s+\d|следующ\w+\s+год)\w*", clause) else None

    @staticmethod
    def _validate_free_text(text: str) -> str | None:
        if QUESTION_WORDS.search(text) or "?" in text or COMMAND_WORDS.search(text): return None
        return text if 0 < len(text.split()) <= 12 else None

    @staticmethod
    def _semantic_answer_match(text: str, expected: ExpectedQuestion) -> bool:
        goal_terms = {
            "permanent_users_share": r"(?:%|процент|треть|постоянн|сотрудник|арендатор)",
            "identify_entrances_count": r"(?:^\s*(?:\d+|один|два|три|четыре)\s*$|\bвъезд)",
            "identify_exits_count": r"(?:^\s*(?:\d+|один|два|три|четыре)\s*$|\bвыезд)",
            "identify_object_type": r"\b(?:тц|трц|бц|жк|центр|комплекс|склад|гостиниц|отел)\w*",
            "identify_current_system": r"\b(?:с\s+нуля|проектир\w*|систем|шлагбаум|паркомат|карт|билет|вручную|никакой)\w*",
            "identify_timeline": r"\b(?:год|декабр|месяц|недел|срок)\w*",
            "identify_location": r"\b(?:объект\s+в|москва|казань|область|край|республика)\b",
            "identify_budget_status": r"\b(?:бюджет|финансирован)\w*",
        }
        pattern = goal_terms.get(expected.question_goal)
        return bool(pattern and re.search(pattern, text))

    def _candidate_precedes_request(self, text: str, expected: ExpectedQuestion) -> bool:
        question_position = text.find("?")
        command_match = COMMAND_WORDS.search(text)
        boundary = question_position if question_position >= 0 else command_match.start() if command_match else -1
        if boundary < 0: return False
        prefix = text[:boundary].rstrip(". ")
        if expected.expected_answer_type == "count": return bool(re.search(r"\b(?:\d+|один|два|две|три|четыре)\s+(?:въезд|выезд)", prefix))
        if expected.expected_answer_type == "object_type": return any(pattern.search(prefix) for _, pattern in OBJECT_TYPES)
        if expected.expected_answer_type == "percentage": return bool(re.search(r"(?:%|процент|треть)", prefix))
        return self._parse_expected(prefix, expected.expected_answer_type, expected.question_goal) is not None

    @staticmethod
    def _goal_field(goal: str) -> str:
        return {
            "identify_object_type": "object_type", "identify_entrances_count": "entrances_count",
            "identify_exits_count": "exits_count", "identify_current_system": "current_system",
            "identify_timeline": "timeline", "identify_location": "location",
            "identify_budget_status": "budget_status", "permanent_users_share": "permanent_users_share",
        }.get(goal, goal)

    @staticmethod
    def _number(value: str) -> int:
        return int(value) if value.isdigit() else NUMBER_WORDS[value.lower()]

    @staticmethod
    def _resolved_text(text: str, relation: str, expected: ExpectedQuestion | None, link: AnswerLinkDecision, topic: str, command: str) -> str:
        if relation in {"answer_to_previous_question", "answer_plus_new_request"} and expected:
            return f"Подтверждённый ответ на {expected.question_goal}: {link.candidate_answer}. Текущая реплика: {text}"
        if relation == "request_for_source": return f"Нужна проверенная ссылка по предмету {topic}. Текущая реплика: {text}"
        if relation == "request_to_recall": return "Клиент просит перечислить подтверждённые факты и отдельно показать конфликты."
        return text

    @staticmethod
    def _required_action(intent: str, command: str) -> str:
        return {
            "give_link": "return_verified_subject_route", "recall_facts": "recall_safe_facts_and_conflicts",
            "ask_one_question": "persist_and_ask_one_semantic_question", "stop_questions": "disable_questions",
            "remember_fact": "store_only_validated_facts", "compare_options": "compare_all_requested_options",
            "recommend": "recommend_with_basis",
        }.get(command, "answer_current_topic")

    @staticmethod
    def _fact_label(key: str) -> str:
        return {
            "object_type": "тип объекта", "entrances_count": "количество въездов",
            "exits_count": "количество выездов", "daily_traffic": "суточный поток",
            "entry_price_rub": "условие цены за въезд", "permanent_users_share": "доля постоянных пользователей",
            "current_system": "текущая система", "timeline": "срок", "location": "местоположение",
            "budget_status": "статус бюджета",
        }.get(key, key)

    @classmethod
    def _display_fact(cls, key: str, value: Any) -> str:
        if key == "permanent_users_share": value = f"{round(float(value) * 100):g}%"
        return f"{cls._fact_label(key)} — {value}" if key in {
            "object_type", "entrances_count", "exits_count", "daily_traffic", "entry_price_rub",
            "permanent_users_share", "current_system", "timeline", "location", "budget_status",
        } else ""

    @classmethod
    def _answer_mentions_fact(cls, answer: str, key: str, value: Any) -> bool:
        display = cls._display_fact(key, value).lower()
        raw = str(value).lower()
        if key == "permanent_users_share": raw = f"{round(float(value) * 100):g}%"
        return bool(display and (display in answer or raw in answer))

    @staticmethod
    def _is_identity(text: str) -> bool:
        return bool(re.search(r"\b(?:кто ты|ты кто|что ты такое)\b", text))

    @staticmethod
    def _is_utility(text: str) -> bool:
        return bool(re.search(r"\b(?:какой сегодня день недели|сколько будет\s+\d+\s*[+\-*/]\s*\d+)\b", text))

    @staticmethod
    def _utility_answer(text: str) -> str:
        match = re.search(r"сколько будет\s+([\d\s+\-*/().]+)", text)
        if match:
            try:
                node = ast.parse(match.group(1).strip(), mode="eval")
                allowed = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}
                def calc(item: ast.AST) -> float:
                    if isinstance(item, ast.Expression): return calc(item.body)
                    if isinstance(item, ast.Constant) and isinstance(item.value, (int, float)): return item.value
                    if isinstance(item, ast.BinOp) and type(item.op) in allowed: return allowed[type(item.op)](calc(item.left), calc(item.right))
                    raise ValueError
                value = calc(node)
                return f"{match.group(1).strip()} = {value:g}."
            except Exception:
                pass
        if "день недели" in text:
            days = ("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")
            return f"Сегодня {days[datetime.now().weekday()]} .".replace("е .", "е.")
        return "Не могу уверенно ответить на этот служебный вопрос."

    @staticmethod
    def _answer_contradictions(answer: str, state: IntegrityState) -> list[str]:
        contradictions: list[str] = []
        object_fact = (state.confirmed_facts.get("object_type") or {}).get("value")
        if object_fact:
            found = [value for value, pattern in OBJECT_TYPES if pattern.search(answer)]
            if found and object_fact not in found: contradictions.append("object_type")
        return contradictions


# Явное имя для новых интеграций. V1 остаётся в context_integrity.py для сравнения.
ContextIntentIntegrityLayer = ContextIntentIntegrityLayerV2
