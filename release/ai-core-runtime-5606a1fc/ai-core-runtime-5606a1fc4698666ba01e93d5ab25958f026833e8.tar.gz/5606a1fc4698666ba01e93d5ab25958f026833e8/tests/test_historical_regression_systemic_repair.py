from __future__ import annotations

import unittest
from unittest.mock import patch

from sales_conversation_controller.site_contract_runtime_v1 import (
    OfflineRuntimeAdapterV1,
    apply_mutation_ack_v11,
)
from sales_conversation_controller.site_contract_runtime_v1.semantic_runtime import VerifiedPublicKnowledge
from sales_conversation_controller.public_semantics import (
    PUBLIC_ENUM_LABELS,
    public_semantic_value,
)
from sales_conversation_controller.verbalization_projection import forbidden_internal_tokens
from tests.test_runtime_semantic_pipeline_repair import request


def confirmed_facts(values: dict) -> list[dict]:
    return [
        {
            "fact_id": f"fact_systemic_{index:03d}",
            "field": field,
            "value": value,
            "source_message_id": "message_systemic_context",
            "confirmed_at": "2026-08-27T08:00:00Z",
            "version": 1,
            "conflict_state": "none",
        }
        for index, (field, value) in enumerate(values.items(), start=1)
        if value is not None and value != []
    ]


def acknowledgement(response: dict, sequence: int) -> dict:
    return {
        "contract_version": response["contract_version"],
        "canonicalization_version": response["canonicalization_version"],
        "request_id": response["request_id"],
        "response_id": response["response_id"],
        "acknowledged_at": f"2026-08-27T09:00:{sequence:02d}Z",
        "acknowledgements": [
            {
                "mutation_id": item["mutation_id"],
                "status": "applied",
                "reason_code": "applied",
                "entity_version_before": 0,
                "entity_version_after": 1,
                "audit_ref": f"auditref:{sequence:02x}{index:030x}",
            }
            for index, item in enumerate(response["state_mutations"], start=1)
        ],
    }


class HistoricalRegressionSystemicRepair(unittest.TestCase):
    TECHNICAL_CASES = (
        ("Сравни распознавание номеров, RFID-карты и билеты для постоянного и разового потока.", True),
        ("Нужно заранее регистрировать гостя по номеру автомобиля и времени визита. Как организовать въезд?", True),
        ("Сколько парковочных карт помещается в диспенсер стойки въезда?", False),
        ("На сколько выдач обычно хватает одного рулона билетной ленты?", False),
        ("Шлагбаум открывается только после подтверждения оплаты. Какие варианты реализации подтверждены?", True),
    )

    def test_technical_routes_require_verified_knowledge_and_engineering_profile(self):
        for index, (message, lab_required) in enumerate(self.TECHNICAL_CASES, start=1):
            with self.subTest(message=message):
                adapter = OfflineRuntimeAdapterV1()
                response = adapter.process(request(message, f"systemic_knowledge_{index}"))
                self.assertTrue(response["success"], response)
                knowledge = adapter.last_trace["knowledge_retrieval"]
                self.assertTrue(knowledge["required"])
                self.assertTrue(knowledge["attempted"])
                self.assertGreaterEqual(knowledge["retrieval_result_count"], 1)
                self.assertEqual(
                    knowledge["retrieval_result_count"],
                    knowledge["executor_received_knowledge_count"],
                )
                self.assertEqual(adapter.last_trace["evaluation_policy"]["name"], "engineering")
                self.assertEqual(
                    adapter.last_trace["ingestion_observability"]["engineering_lab_input_facts"] is not None,
                    lab_required,
                )

    def test_missing_required_technical_knowledge_fails_closed_for_every_class(self):
        class MustNotRun:
            def execute(self, _context):
                raise AssertionError("model_must_not_run_without_verified_technical_knowledge")

        for index, (message, _lab_required) in enumerate(self.TECHNICAL_CASES, start=1):
            with self.subTest(message=message):
                with patch.object(VerifiedPublicKnowledge, "load", return_value=None):
                    adapter = OfflineRuntimeAdapterV1(qwen_executor=MustNotRun())
                    response = adapter.process(request(message, f"systemic_fail_closed_{index}"))
                self.assertTrue(response["success"], response)
                self.assertEqual(response["executor_trace"]["model_request_count"], 0)
                self.assertEqual(response["executor_trace"]["attempts"], [])
                self.assertIn(
                    "required_technical_knowledge_missing",
                    response["evaluation_result"]["reason_codes"],
                )

    def test_object_card_public_projection_is_complete_or_explicitly_excluded(self):
        values = {
            "object_type": "shopping_center",
            "entrances_count": 2,
            "exits_count": 2,
            "daily_traffic": 800,
            "user_segments": ["employees", "tenants", "guests", "one_time"],
            "operator_present": True,
            "entry_price_rub": 200,
            "gate_requires_payment_confirmation": True,
            "current_system": "new_build",
            "mandatory_automated_fallback": True,
        }
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(
            "Что мы уже выяснили об объекте?", "systemic_object_card",
            facts=confirmed_facts(values),
        ))
        self.assertTrue(response["success"], response)
        answer = response["answer"].casefold()
        for marker in (
            "торговый центр", "въезды — 2", "выезды — 2", "800 автомобилей",
            "разовые посетители", "оператор — есть", "200 рублей",
            "после подтверждения оплаты", "проектируется с нуля", "автоматический резерв — обязателен",
        ):
            self.assertIn(marker, answer)
        projection = adapter.last_trace["object_card_projection"]
        self.assertEqual(set(projection["rendered_fields"]), set(values))
        self.assertEqual(projection["excluded_fields"], [])

    def test_all_public_canonical_enums_are_projected_before_transport(self):
        cases = (
            (
                "Сравни распознавание номеров, RFID-карты и билеты для постоянного и разового потока.",
                {"user_segments": ["permanent", "one_time"]},
                ("постоянные пользователи", "разовые посетители"),
            ),
            (
                "Сформулируй предварительную рекомендацию по всей информации, которую мы уже собрали.",
                {
                    "object_type": "shopping_center", "entrances_count": 2,
                    "exits_count": 2, "daily_traffic": 800,
                    "current_system": "new_build",
                    "user_segments": ["employees", "tenants", "guests", "one_time"],
                    "speed_priority": "high", "mandatory_automated_fallback": True,
                },
                ("торговый центр", "разовые посетители"),
            ),
        )
        for index, (message, values, expected_labels) in enumerate(cases, start=1):
            with self.subTest(message=message):
                adapter = OfflineRuntimeAdapterV1()
                response = adapter.process(request(
                    message, f"systemic_enum_{index}", facts=confirmed_facts(values),
                ))
                self.assertTrue(response["success"], response)
                prompt = adapter.last_trace["model_prompt_contract"]["serialized_prompt"]
                self.assertEqual(forbidden_internal_tokens(prompt), [])
                for label in expected_labels:
                    self.assertIn(label, prompt)

    def test_every_registered_canonical_enum_has_safe_public_label(self):
        for field, mapping in PUBLIC_ENUM_LABELS.items():
            for canonical, expected_public in mapping.items():
                with self.subTest(field=field, canonical=canonical):
                    projected = public_semantic_value(field, canonical)
                    self.assertEqual(projected, expected_public)
                    self.assertNotEqual(projected, canonical)
                    self.assertEqual(forbidden_internal_tokens(str(projected)), [])

    def test_question_planner_suppresses_every_confirmed_non_conflicting_field(self):
        values = {
            "object_type": "business_center", "entrances_count": 2,
            "exits_count": 2, "daily_traffic": 800,
            "user_segments": ["employees", "tenants", "guests"],
        }
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(
            "Продолжай собирать данные об объекте, но задавай строго по одному вопросу.",
            "systemic_question_suppression", facts=confirmed_facts(values),
        ))
        self.assertTrue(response["success"], response)
        self.assertEqual(response["answer"].count("?"), 1)
        answer = response["answer"].casefold()
        for repeated in ("тип объекта", "сколько въезд", "сколько выезд", "суточный поток", "какие группы"):
            self.assertNotIn(repeated, answer)
        self.assertEqual(response["evaluation_result"]["status"], "pass")


class HistoricalPackPermanentRegression(unittest.TestCase):
    def run_case(self, message: str, suffix: str, values: dict | None = None):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(
            message, suffix, facts=confirmed_facts(values or {}),
        ))
        self.assertTrue(response["success"], response)
        attempts = response["executor_trace"]["attempts"]
        self.assertEqual(len(attempts), len({item["attempt_index"] for item in attempts}))
        mutations = response["state_mutations"]
        self.assertEqual(len(mutations), len({item["mutation_id"] for item in mutations}))
        return adapter, response

    def assert_verified_technical_knowledge(self, adapter, response):
        knowledge = adapter.last_trace["knowledge_retrieval"]
        self.assertTrue(knowledge["required"])
        self.assertTrue(knowledge["attempted"])
        self.assertGreaterEqual(knowledge["retrieval_result_count"], 1)
        self.assertEqual(
            knowledge["retrieval_result_count"],
            knowledge["executor_received_knowledge_count"],
        )
        self.assertEqual(adapter.last_trace["evaluation_policy"]["name"], "engineering")
        self.assertEqual(response["evaluation_result"]["status"], "pass")
        self.assertLessEqual(response["repair_result"]["rewrite_ratio"], .35)

    def test_hr01_known_facts_not_reasked(self):
        first_message = (
            "У нас бизнес-центр: два въезда, два выезда, около 800 автомобилей в сутки. "
            "Есть сотрудники, арендаторы и гости."
        )
        first_request = request(first_message, "historical_hr01_t1")
        first_adapter = OfflineRuntimeAdapterV1()
        first_response = first_adapter.process(first_request)
        self.assertTrue(first_response["success"], first_response)
        second_seed = request(
            "Что лучше выбрать для такой парковки: госномера, карты или билеты?",
            "historical_hr01_t2",
            history=[
                {"message_id": first_request["payload"]["message_id"], "role": "user", "content": first_message, "created_at": "2026-08-27T09:00:00Z"},
                {"message_id": first_response["response_id"], "role": "assistant", "content": first_response["answer"], "created_at": "2026-08-27T09:00:01Z"},
            ],
        )
        second_request = apply_mutation_ack_v11(
            second_seed, first_response, acknowledgement(first_response, 1),
            publication_confirmed=True,
        )["next_request"]
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(second_request)
        self.assertTrue(response["success"], response)
        effective = adapter.last_trace["ingestion_observability"]["request_local_effective_facts"]
        for field in ("object_type", "entrances_count", "exits_count", "daily_traffic", "user_segments"):
            self.assertIn(field, effective)
        answer = response["answer"].casefold()
        for marker in ("номер", "карт", "билет"):
            self.assertIn(marker, answer)
        self.assertNotIn("какой тип объекта", answer)
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr02_complete_object_card(self):
        values = {
            "object_type": "shopping_center", "entrances_count": 2,
            "exits_count": 2, "daily_traffic": 800,
            "current_system": "new_build",
            "user_segments": ["employees", "tenants", "guests"],
            "entry_price_rub": 200,
            "gate_requires_payment_confirmation": True,
        }
        adapter, response = self.run_case(
            "Что мы уже выяснили об объекте?", "historical_hr02", values,
        )
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)
        self.assertEqual(set(adapter.last_trace["object_card_projection"]["rendered_fields"]), set(values))
        self.assertIn("200 рублей", response["answer"])
        self.assertIn("после подтверждения оплаты", response["answer"])

    def test_hr03_identifier_comparison(self):
        adapter, response = self.run_case(
            "Сравни распознавание номеров, RFID-карты и билеты для постоянного и разового потока.",
            "historical_hr03", {"user_segments": ["permanent", "one_time"]},
        )
        for marker in ("номер", "карт", "билет"):
            self.assertIn(marker, response["answer"].casefold())
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr04_identification_failure_fallback(self):
        adapter, response = self.run_case(
            "Что должна сделать система, если номер грязный и камера его не распознала?",
            "historical_hr04",
            {"mandatory_automated_fallback": True, "operator_present": True, "primary_identifier": "license_plate_recognition"},
        )
        self.assertEqual(adapter.last_trace["ingestion_observability"]["semantic_route"], "identification_failure_fallback")
        answer = response["answer"].casefold()
        self.assertIn("автоматическ", answer)
        self.assertIn("исключительн", answer)
        self.assertNotIn("охранник", answer)
        self.assertLessEqual(response["answer"].count("?"), 1)
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr05_guest_access(self):
        adapter, response = self.run_case(
            "Нужно заранее регистрировать гостя по номеру автомобиля и времени визита, без ручного пропуска. Как организовать въезд?",
            "historical_hr05",
            {"user_segments": ["guests"], "known_inputs": ["license_plate", "visit_time_window"], "manual_pass_issue_forbidden": True},
        )
        answer = response["answer"].casefold()
        for marker in ("заявк", "право доступа", "временн", "идентифиц"):
            self.assertIn(marker, answer)
        self.assertLessEqual(response["answer"].count("?"), 1)
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr06_card_dispenser_capacity(self):
        adapter, response = self.run_case(
            "Сколько парковочных карт помещается в диспенсер стойки въезда?",
            "historical_hr06",
        )
        answer = response["answer"].casefold()
        self.assertIn("модел", answer)
        self.assertNotRegex(answer, r"\b\d+\s+карт")
        self.assertLessEqual(response["answer"].count("?"), 1)
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr07_ticket_roll_yield(self):
        adapter, response = self.run_case(
            "На сколько выдач обычно хватает одного рулона билетной ленты?",
            "historical_hr07",
        )
        answer = response["answer"].casefold()
        for marker in ("длин", "билет", "настройк"):
            self.assertIn(marker, answer)
        self.assertNotRegex(answer, r"\b\d+\s+(?:выдач|билет)")
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr08_payment_claim_boundary(self):
        values = {"entry_price_rub": 200, "gate_requires_payment_confirmation": True}
        adapter, response = self.run_case(
            "Требование такое: въезд стоит 200 рублей, шлагбаум открывается только после подтверждения оплаты. Какие варианты реализации подтверждены?",
            "historical_hr08", values,
        )
        answer = response["answer"].casefold()
        self.assertIn("200 рублей", answer)
        self.assertIn("подтвержд", answer)
        for unsupported in ("сбп", "эквайринг", "мобильное приложение"):
            self.assertNotIn(unsupported, answer)
        self.assert_verified_technical_knowledge(adapter, response)

    def test_hr09_one_question_without_known_fact_reask(self):
        values = {
            "object_type": "business_center", "entrances_count": 2,
            "exits_count": 2, "daily_traffic": 800,
            "user_segments": ["employees", "tenants", "guests"],
        }
        _adapter, response = self.run_case(
            "Продолжай собирать данные об объекте, но задавай строго по одному вопросу.",
            "historical_hr09", values,
        )
        self.assertEqual(response["answer"].count("?"), 1)
        self.assertNotIn("тип объекта", response["answer"].casefold())
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_hr10_preliminary_recommendation_uses_full_card(self):
        values = {
            "object_type": "shopping_center", "entrances_count": 2,
            "exits_count": 2, "daily_traffic": 800,
            "current_system": "new_build", "permanent_user_share_percent": 30,
            "user_segments": ["employees", "tenants", "guests", "one_time"],
            "entry_price_rub": 200, "gate_requires_payment_confirmation": True,
            "speed_priority": "high", "mandatory_automated_fallback": True,
        }
        adapter, response = self.run_case(
            "Сформулируй предварительную рекомендацию по всей информации, которую мы уже собрали.",
            "historical_hr10", values,
        )
        answer = response["answer"].casefold()
        for marker in (
            "предваритель", "торговый центр", "2/2", "800", "30%",
            "с нуля", "200 рублей", "подтверждения оплаты", "скорост", "автоматический резерв",
        ):
            self.assertIn(marker, answer)
        self.assertLessEqual(response["answer"].count("?"), 1)
        self.assert_verified_technical_knowledge(adapter, response)


if __name__ == "__main__":
    unittest.main()
