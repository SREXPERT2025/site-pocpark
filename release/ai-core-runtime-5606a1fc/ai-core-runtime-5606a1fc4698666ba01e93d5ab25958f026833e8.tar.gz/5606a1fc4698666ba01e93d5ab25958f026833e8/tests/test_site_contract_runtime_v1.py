from __future__ import annotations

import copy
import json
import unittest
from datetime import datetime, timezone
from pathlib import Path

from sales_conversation_controller.site_contract_runtime_v1 import (
    CodexTimeoutStub,
    CodexUnavailableStub,
    OfflineRuntimeAdapterV1,
    apply_mutation_ack,
)
from sales_conversation_controller.site_contract_runtime_v1.canonical import canonical_json, sha256
from sales_conversation_controller.site_contract_runtime_v1.constants import (
    CANONICALIZATION_VERSION,
    CONTRACT_VERSION,
    CONTRACT_TARGET_SHA,
    RUNTIME_ORDER,
)


ROOT = Path(__file__).resolve().parents[1]
GOLDEN = json.loads((ROOT / "tests/fixtures/site_contract_runtime_v1_golden.json").read_text(encoding="utf-8"))


def fact(index: int, field: str, value):
    return {
        "fact_id": f"fact_{index:03d}",
        "field": field,
        "value": value,
        "source_message_id": "message_seed_001",
        "confirmed_at": "2026-08-07T09:00:00Z",
        "version": 1,
        "conflict_state": "none",
    }


BASE_FACTS = [
    fact(1, "object_type", "business_center"),
    fact(2, "entrances_count", 2),
    fact(3, "exits_count", 2),
    fact(4, "daily_traffic", 800),
    fact(5, "user_segments", ["employees", "tenants", "guests"]),
    fact(6, "operator_present", True),
    fact(7, "speed_priority", "high"),
    fact(8, "mandatory_automated_fallback", True),
]


def policy(route: str) -> dict:
    if route.startswith("codex"):
        return {
            "policy_id": "policy:codex:offline",
            "assignment_id": "assignment:codex:offline",
            "planned_executor": "codex",
            "allowed_executors": ["codex", "qwen"],
            "max_model_fallbacks": 1,
            "fallback_order": ["codex", "qwen"],
            "attempt_timeout_ms": 100,
            "total_timeout_ms": 200,
            "cost_bucket_limit": "external_low",
            "deterministic_route_handling": "outside_executor_attempts",
        }
    return {
        "policy_id": "policy:qwen:offline",
        "assignment_id": "assignment:qwen:offline",
        "planned_executor": "qwen",
        "allowed_executors": ["qwen"],
        "max_model_fallbacks": 0,
        "fallback_order": ["qwen"],
        "attempt_timeout_ms": 100,
        "total_timeout_ms": 100,
        "cost_bucket_limit": "local_low",
        "deterministic_route_handling": "outside_executor_attempts",
    }


def request_for(scenario: dict, *, suffix: str = "001") -> dict:
    active = None
    if scenario.get("active_question"):
        active = {
            "question_id": "question_current_system_001",
            "goal": "identify_current_system",
            "expected_fields": ["current_system"],
            "asked_at_message_id": "message_previous_001",
        }
    recent = []
    if scenario.get("repeated"):
        recent = [
            {"message_id": "message_old_user_001", "role": "user", "content": "Что выбрать: номера, карты или билеты?", "created_at": "2026-08-07T09:30:00Z"},
            {"message_id": "message_old_ai_001", "role": "assistant", "content": "Нужно уточнить данные.", "created_at": "2026-08-07T09:31:00Z"},
        ]
    payload = {
        "potential_project_id": None,
        "conversation_thread_id": f"thread_runtime_{suffix}",
        "conversation_id": f"conversation_runtime_{suffix}",
        "message_id": f"message_runtime_{suffix}",
        "parent_message_id": None,
        "timestamp": "2026-08-07T10:00:00Z",
        "channel": "offline",
        "current_message": scenario["message"],
        "recent_messages": recent,
        "state_version": 7,
        "confirmed_project_facts": copy.deepcopy(BASE_FACTS),
        "candidate_facts": [],
        "fact_conflicts": [],
        "intent_hints": [
            {
                "hint_id": "hint_page_offline",
                "source_type": "pathname",
                "value_code": "/solutions/business-center",
                "provenance_ref": "hintref:page:offline",
                "confirmation_status": "unconfirmed",
            }
        ],
        "active_question": active,
        "consent_safe_context_refs": ["ctxref:knowledge:parking_access"],
        "executor_policy": policy(scenario["route"]),
    }
    return {
        "contract_version": CONTRACT_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "request_id": f"request_runtime_{suffix}",
        "idempotency_key": f"idem:runtime:{suffix}",
        "request_payload_hash": sha256(payload),
        "site_release": "ec4172a",
        "gateway_release": None,
        "sent_at": "2026-08-07T10:00:00Z",
        "trace_context": {"trace_id": f"trace:runtime:{suffix}", "span_id": f"span:runtime:{suffix}", "parent_span_id": None},
        "dry_run": True,
        "payload": payload,
    }


class OfflineRuntimeV1Tests(unittest.TestCase):
    def test_01_contract_dependency_is_pinned_and_intact(self):
        adapter = OfflineRuntimeAdapterV1()
        self.assertEqual(adapter.contract_target_sha, CONTRACT_TARGET_SHA)
        self.assertTrue(adapter.validator.verify_dependency()["passed"])

    def test_02_request_and_response_contract_validation(self):
        adapter = OfflineRuntimeAdapterV1()
        request = request_for(GOLDEN["scenarios"][0])
        self.assertTrue(adapter.validator.validate("request-v1.schema.json", request).valid)
        response = adapter.process(request)
        self.assertTrue(response["success"])
        self.assertTrue(adapter.validator.validate("response-v1.schema.json", response).valid)
        self.assertEqual(response["repair_result"]["reason_codes"], [])
        self.assertEqual(response["telemetry"]["repair"]["reason_codes"], [])

    def test_02b_repair_wire_fields_are_required(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request_for(GOLDEN["scenarios"][0], suffix="002b"))
        missing_result = copy.deepcopy(response)
        del missing_result["repair_result"]["reason_codes"]
        self.assertFalse(
            adapter.validator.validate("response-v1.schema.json", missing_result).valid,
        )
        missing_telemetry = copy.deepcopy(response)
        del missing_telemetry["telemetry"]["repair"]["reason_codes"]
        self.assertFalse(
            adapter.validator.validate("response-v1.schema.json", missing_telemetry).valid,
        )

    def test_03_runtime_order_is_exact(self):
        adapter = OfflineRuntimeAdapterV1()
        adapter.process(request_for(GOLDEN["scenarios"][2]))
        self.assertEqual(tuple(adapter.last_trace["runtime_order"]), RUNTIME_ORDER)

    def test_04_current_turn_priority(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request_for(GOLDEN["scenarios"][0]))
        self.assertEqual(response["answer"], "2+2 = 4.")
        self.assertEqual(response["context_resolution"]["ingestion"]["message_id"], "message_runtime_001")
        self.assertTrue(response["context_resolution"]["ingestion"]["ingested"])

    def test_05_remember_fact_proposes_mutation_only(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request_for(GOLDEN["scenarios"][1], suffix="005"))
        mutation = next(item for item in response["state_mutations"] if item["field"] == "entry_price_rub")
        self.assertEqual(mutation["operation"], "set_confirmed_fact")
        self.assertEqual(mutation["expected_state_version"], 7)
        self.assertEqual(mutation["proposed_state_version"], 8)

    def test_06_hint_is_not_promoted_to_confirmed_fact(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request_for(GOLDEN["scenarios"][0], suffix="006"))
        self.assertFalse(any(item["provenance"]["source_type"] == "intent_hint" for item in response["state_mutations"]))
        self.assertFalse(any(item["field"] == "pathname" for item in response["state_mutations"]))

    def test_07_decision_package_is_immutable_through_executor_and_repair(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request_for(GOLDEN["scenarios"][2], suffix="007"))
        hashes = {
            response["decision_package_hash"],
            response["executor_trace"]["decision_package_hash"],
            response["repair_result"]["decision_package_hash"],
            *(item["decision_package_hash"] for item in response["executor_trace"]["attempts"]),
        }
        self.assertEqual(hashes, {sha256(response["decision_package"])})

    def test_08_qwen_stub_route(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][2], suffix="008"))
        self.assertEqual(response["executor_trace"]["planned_executor"], "qwen")
        self.assertEqual(response["executor_trace"]["final_executor"], "qwen")
        self.assertEqual(len(response["executor_trace"]["attempts"]), 1)

    def test_09_codex_stub_route(self):
        scenario = dict(GOLDEN["scenarios"][2], route="codex")
        response = OfflineRuntimeAdapterV1().process(request_for(scenario, suffix="009"))
        self.assertEqual(response["executor_trace"]["planned_executor"], "codex")
        self.assertEqual(response["executor_trace"]["final_executor"], "codex")

    def test_10_codex_timeout_falls_back_once_to_qwen(self):
        adapter = OfflineRuntimeAdapterV1(codex_executor=CodexTimeoutStub())
        response = adapter.process(request_for(GOLDEN["scenarios"][9], suffix="010"))
        trace = response["executor_trace"]
        self.assertEqual([item["status"] for item in trace["attempts"]], ["timeout", "success"])
        self.assertEqual([item["executor"] for item in trace["attempts"]], ["codex", "qwen"])
        self.assertEqual(trace["final_executor"], "qwen")

    def test_11_codex_unavailable_falls_back_once_to_qwen(self):
        adapter = OfflineRuntimeAdapterV1(codex_executor=CodexUnavailableStub())
        scenario = dict(GOLDEN["scenarios"][9], route="codex_unavailable")
        response = adapter.process(request_for(scenario, suffix="011"))
        self.assertEqual(response["executor_trace"]["fallback_reason"], "unavailable")
        self.assertEqual(len(response["executor_trace"]["attempts"]), 2)

    def test_12_fallback_preserves_state_facts_question_and_decision(self):
        adapter = OfflineRuntimeAdapterV1(codex_executor=CodexTimeoutStub())
        request = request_for(GOLDEN["scenarios"][9], suffix="012")
        response = adapter.process(request)
        trace = response["executor_trace"]
        self.assertEqual({item["state_version"] for item in trace["attempts"]}, {7})
        self.assertEqual({item["decision_package_hash"] for item in trace["attempts"]}, {response["decision_package_hash"]})
        self.assertEqual(response["next_question"], response["decision_package"]["next_question"])
        self.assertEqual(request["payload"]["confirmed_project_facts"], BASE_FACTS)

    def test_13_no_answer_mixing(self):
        adapter = OfflineRuntimeAdapterV1(codex_executor=CodexTimeoutStub())
        response = adapter.process(request_for(GOLDEN["scenarios"][9], suffix="013"))
        self.assertEqual(response["answer"], adapter.last_trace["final_answer"])
        self.assertNotIn("safe_stub_timeout", response["answer"])

    def test_14_one_question_rule(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][3], suffix="014"))
        self.assertEqual(response["answer"].count("?"), 1)
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_15_open_question_is_resolved_before_answer(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][4], suffix="015"))
        self.assertEqual(response["context_resolution"]["relation"], "answer_to_previous_question")
        self.assertIn("question_current_system_001", response["context_resolution"]["answered_question_ids"])
        self.assertTrue(any(item["field"] == "current_system" for item in response["state_mutations"]))

    def test_16_guest_application_is_authorization_not_identifier(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][6], suffix="016"))
        guest = response["decision_package"]["recommended_architecture"]["segments"]["guests"]
        self.assertEqual(guest["authorization"]["type"], "guest_application")
        self.assertNotEqual((guest.get("primary_identifier") or {}).get("type"), "guest_application")

    def test_17_operator_is_exception_recovery_only(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][7], suffix="017"))
        plans = response["decision_package"]["recommended_architecture"]["segments"].values()
        self.assertTrue(all((plan.get("assisted_recovery") or {}).get("usage") == "exception_only" for plan in plans))
        self.assertTrue(all("operator_assisted_access" not in {item["type"] for item in plan["automated_fallback_credentials"]} for plan in plans))

    def test_18_unknown_readers_do_not_become_recommendations(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][8], suffix="018"))
        plans = response["decision_package"]["recommended_architecture"]["segments"].values()
        self.assertTrue(all(not plan["automated_fallback_credentials"] for plan in plans))
        self.assertNotRegex(response["answer"].split("Автоматический резерв", 1)[-1].split(".", 1)[0], r"(?i)QR|RFID|карт|билет")

    def test_19_repeated_unsatisfied_intent_keeps_recommendation(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][5], suffix="019"))
        self.assertEqual(response["context_resolution"]["command_requirements"]["action_type"], "recommend_solution")
        self.assertIn("основной способ", response["answer"])

    def test_20_evaluation_is_final_visible_candidate(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request_for(GOLDEN["scenarios"][2], suffix="020"))
        self.assertEqual(response["evaluation_result"]["evaluated_candidate"], "final_visible_candidate")
        self.assertEqual(response["answer"], adapter.last_trace["final_answer"])

    def test_21_publication_semantics(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][2], suffix="021"))
        expected = "allowed" if response["evaluation_result"]["status"] == "pass" else "owner_review"
        self.assertEqual(response["telemetry"]["publication"]["candidate_status"], expected)
        self.assertFalse(response["telemetry"]["publication"]["published"])

    def test_22_idempotent_retry_returns_byte_identical_response(self):
        adapter = OfflineRuntimeAdapterV1()
        request = request_for(GOLDEN["scenarios"][0], suffix="022")
        first = adapter.process(request)
        second = adapter.process(copy.deepcopy(request))
        self.assertEqual(canonical_json(first), canonical_json(second))

    def test_23_idempotency_conflict_is_safe_error(self):
        adapter = OfflineRuntimeAdapterV1()
        request = request_for(GOLDEN["scenarios"][0], suffix="023")
        adapter.process(request)
        conflict = copy.deepcopy(request)
        conflict["payload"]["current_message"] = "Сколько будет 3+3?"
        conflict["request_payload_hash"] = sha256(conflict["payload"])
        result = adapter.process(conflict)
        self.assertFalse(result["success"])
        self.assertEqual(result["error"]["code"], "IDEMPOTENCY_CONFLICT")

    def test_24_invalid_schema_returns_safe_error(self):
        request = request_for(GOLDEN["scenarios"][0], suffix="024")
        request["payload"]["contact"] = "forbidden"
        result = OfflineRuntimeAdapterV1().process(request)
        self.assertFalse(result["success"])
        self.assertEqual(result["error"]["code"], "VALIDATION_ERROR")
        self.assertNotIn("exception", canonical_json(result).lower())

    def test_25_ack_applies_only_accepted_mutation_to_next_request(self):
        adapter = OfflineRuntimeAdapterV1()
        previous = adapter.process(request_for(GOLDEN["scenarios"][1], suffix="025"))
        mutation = next(item for item in previous["state_mutations"] if item["field"] == "entry_price_rub")
        next_request = request_for(GOLDEN["scenarios"][0], suffix="025_next")
        ack = {
            "contract_version": CONTRACT_VERSION,
            "canonicalization_version": CANONICALIZATION_VERSION,
            "request_id": previous["request_id"],
            "response_id": previous["response_id"],
            "acknowledged_at": "2026-08-07T10:01:00Z",
            "acknowledgements": [{
                "mutation_id": mutation["mutation_id"],
                "status": "applied",
                "reason_code": "applied",
                "entity_version_before": 7,
                "entity_version_after": 8,
                "audit_ref": "auditref:runtime:025",
            }],
        }
        prepared = apply_mutation_ack(next_request, previous, ack)
        values = {item["field"]: item["value"] for item in prepared["payload"]["confirmed_project_facts"]}
        self.assertEqual(values["entry_price_rub"], 200)
        self.assertEqual(prepared["payload"]["state_version"], 8)

    def test_26_contract_excludes_private_domain_fields(self):
        response = OfflineRuntimeAdapterV1().process(request_for(GOLDEN["scenarios"][2], suffix="026"))
        forbidden = {"contact", "phone", "email", "consent", "recovery_credential", "raw_exception", "stack_trace"}
        found = set()
        def walk(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    if key in forbidden:
                        found.add(key)
                    walk(item)
            elif isinstance(value, list):
                for item in value:
                    walk(item)
        walk(response)
        self.assertEqual(found, set())

    def test_27_all_ten_golden_scenarios_complete_without_model_calls(self):
        passed = 0
        for index, scenario in enumerate(GOLDEN["scenarios"], start=1):
            codex = CodexTimeoutStub() if scenario["route"] == "codex_timeout" else None
            adapter = OfflineRuntimeAdapterV1(codex_executor=codex)
            response = adapter.process(request_for(scenario, suffix=f"golden_{index:02d}"))
            self.assertTrue(response["success"], scenario["id"])
            self.assertEqual(response["context_resolution"]["command_requirements"]["action_type"], scenario["expected_action"])
            self.assertEqual(adapter.last_trace["model_requests"], 0)
            passed += 1
        self.assertEqual(passed, 10)

    def test_28_conflict_is_recorded_without_overwriting_confirmed_fact(self):
        scenario = {
            "id": "conflict",
            "message": "Зафиксируй: въезд стоит 300 рублей.",
            "route": "qwen",
        }
        request = request_for(scenario, suffix="028")
        request["payload"]["confirmed_project_facts"].append(fact(28, "entry_price_rub", 200))
        request["request_payload_hash"] = sha256(request["payload"])
        response = OfflineRuntimeAdapterV1().process(request)
        self.assertTrue(response["success"])
        conflicts = [item for item in response["state_mutations"] if item["operation"] == "record_conflict"]
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["value"]["old_value"], 200)
        self.assertEqual(conflicts[0]["value"]["new_value"], 300)
        self.assertFalse(any(item["operation"] == "set_confirmed_fact" and item["field"] == "entry_price_rub" for item in response["state_mutations"]))

    def test_29_malformed_request_id_still_returns_valid_safe_error(self):
        adapter = OfflineRuntimeAdapterV1()
        request = request_for(GOLDEN["scenarios"][0], suffix="029")
        request["request_id"] = "x"
        response = adapter.process(request)
        self.assertFalse(response["success"])
        self.assertIsNone(response["request_id"])
        self.assertTrue(adapter.validator.validate("error-envelope-v1.schema.json", response).valid)


if __name__ == "__main__":
    unittest.main()
