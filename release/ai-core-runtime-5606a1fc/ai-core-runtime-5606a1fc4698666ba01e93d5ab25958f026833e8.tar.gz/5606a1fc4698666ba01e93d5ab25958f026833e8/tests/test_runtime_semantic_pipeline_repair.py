from __future__ import annotations

import copy
import unittest
from pathlib import Path
from unittest.mock import patch

from sales_conversation_controller.site_contract_runtime_v1 import OfflineRuntimeAdapterV1
from sales_conversation_controller.site_contract_runtime_v1 import apply_mutation_ack_v11
from sales_conversation_controller.site_contract_runtime_v1.canonical import sha256
from sales_conversation_controller.site_contract_runtime_v1.semantic_runtime import (
    VerifiedPublicKnowledge,
    classify_route,
    remove_executor_disclosure,
)
from sales_conversation_controller.site_contract_runtime_v1.constants import CONTRACT_TARGET_SHA
from sales_conversation_controller.site_contract_runtime_v1.executors import StubOutput
from tests.test_site_contract_runtime_v1 import GOLDEN, request_for


def request(message: str, suffix: str, *, history=None, facts=None):
    value = request_for({**GOLDEN["scenarios"][0], "message": message}, suffix=suffix)
    value["payload"]["recent_messages"] = copy.deepcopy(history or [])
    value["payload"]["confirmed_project_facts"] = copy.deepcopy(facts or [])
    value["request_payload_hash"] = sha256(value["payload"])
    return value


class RuntimeSemanticRepairR01R14(unittest.TestCase):
    def run_case(self, message: str, suffix: str, **kwargs):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(message, suffix, **kwargs))
        self.assertTrue(response["success"], response)
        return adapter, response

    def test_r01_greeting(self):
        adapter, response = self.run_case("Привет!", "r01")
        self.assertEqual(adapter.last_trace["ingestion_observability"]["semantic_route"], "courtesy")
        self.assertEqual(response["executor_trace"]["execution_mode"], "deterministic")
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_r02_repeat_greeting(self):
        adapter, response = self.run_case("И снова здравствуйте", "r02")
        self.assertEqual(adapter.last_trace["ingestion_observability"]["semantic_route"], "courtesy")
        self.assertFalse(response["repair_result"]["applied"])

    def test_r03_utility(self):
        adapter, response = self.run_case("2+2=", "r03")
        self.assertEqual(response["answer"], "2+2 = 4.")
        self.assertEqual(adapter.last_trace["sales_conversation_controller"], "not_invoked")
        self.assertEqual(adapter.last_trace["engineering_decision_laboratory"], "not_invoked")

    def test_r04_identity_and_capabilities(self):
        adapter, response = self.run_case("кто ты? чем можешь помочь?", "r04")
        self.assertIn("AI-консультант РОСПАРК", response["answer"])
        self.assertNotIn("универсаль", response["answer"].casefold())
        self.assertTrue(adapter.last_trace["executor_input_contract"]["public_identity_present"])

    def test_r05_executor_identity(self):
        _, response = self.run_case("Какая у тебя модель и версия, когда тебя создали?", "r05")
        self.assertFalse(any(name in response["answer"].casefold() for name in ("qwen", "codex", "ollama", "alibaba", "tongyi")))
        self.assertEqual(response["executor_trace"]["deterministic_handler"], "executor_identity_policy")

    def test_r06_company_knowledge(self):
        adapter, response = self.run_case("что ты знаешь о РОСПАРК?", "r06")
        knowledge = adapter.last_trace["knowledge_retrieval"]
        self.assertTrue(knowledge["required"])
        self.assertTrue(knowledge["attempted"])
        self.assertGreater(knowledge["retrieval_result_count"], 0)
        self.assertEqual(knowledge["executor_received_knowledge_count"], 1)
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)
        self.assertIn("автоматическая парковочная система", response["answer"])

    def test_r07_capability_scope(self):
        _, response = self.run_case("на какие вопросы ты можешь ответить?", "r07")
        self.assertIn("автоматизации парковок", response["answer"])
        self.assertNotIn("любые вопросы", response["answer"].casefold())

    def test_r08_equipment(self):
        adapter, response = self.run_case("расскажи про оборудование РОСПАРК", "r08")
        self.assertEqual(adapter.last_trace["ingestion_observability"]["semantic_route"], "equipment_overview")
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_r09_r10_trusted_followup_recovery(self):
        history = [{
            "message_id": "message_r09", "role": "user",
            "content": "У нас бизнес-центр, 2 въезда и 2 выезда, поток около 800 машин в день, сотрудники, арендаторы и гости.",
            "created_at": "2026-08-13T01:00:00Z",
        }]
        adapter, response = self.run_case("Что выбрать: карты или билеты?", "r10", history=history)
        observation = adapter.last_trace["ingestion_observability"]
        self.assertEqual(set(observation["trusted_history_recovered_fields"]), {
            "object_type", "entrances_count", "exits_count", "daily_traffic",
            "daily_traffic_certainty", "user_segments",
        })
        self.assertEqual(observation["engineering_lab_input_facts"]["daily_traffic"], 800)
        self.assertEqual(adapter.last_trace["executor_input_contract"]["confirmed_fact_count"], 6)
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_r11_utility_does_not_inherit_engineering(self):
        history = [{"message_id": "old", "role": "user", "content": "Что выбрать: карты или билеты?", "created_at": "2026-08-13T01:00:00Z"}]
        adapter, response = self.run_case("2+5=", "r11", history=history)
        self.assertEqual(response["answer"], "2+5 = 7.")
        self.assertEqual(adapter.last_trace["ingestion_observability"]["semantic_route"], "utility")

    def test_r12_corporate_context_propagation(self):
        adapter, response = self.run_case("что ты знаешь о РОСПАРК?", "r12")
        audit = adapter.last_trace["knowledge_retrieval"]
        self.assertEqual(audit["retrieval_result_count"], audit["knowledge_projection_count"])
        self.assertEqual(audit["knowledge_projection_count"], audit["executor_received_knowledge_count"])
        self.assertEqual(response["executor_trace"]["attempts"], [])

    def test_r13_public_identity_propagation(self):
        adapter, _ = self.run_case("кто ты? чем можешь помочь?", "r13")
        contract = adapter.last_trace["executor_input_contract"]
        self.assertTrue(contract["public_identity_present"])
        self.assertTrue(contract["adapter_context_parity"])

    def test_r14_followup_fact_projection_and_adapter_parity(self):
        history = [{
            "message_id": "message_r14a", "role": "user",
            "content": "Бизнес-центр, 2 въезда, 2 выезда, около 800 машин в день, сотрудники, арендаторы и гости.",
            "created_at": "2026-08-13T01:00:00Z",
        }]
        adapter, _ = self.run_case("Что выбрать: карты или билеты?", "r14", history=history)
        contract = adapter.last_trace["executor_input_contract"]
        projection = adapter.last_trace["verbalization_projection"]
        self.assertEqual(contract["qwen_fields"], contract["codex_fields"])
        self.assertEqual(projection["relevant_confirmed_facts"]["daily_traffic"], 800)

    def test_local_executor_disclosure_repair_removes_whole_fragment(self):
        answer, changed = remove_executor_disclosure(
            "Я помогу по парковке. Я работаю на Qwen от Alibaba. Уточним задачу."
        )
        self.assertTrue(changed)
        self.assertEqual(answer, "Я помогу по парковке. Уточним задачу.")

    def test_taxonomy_has_no_general_information_bucket(self):
        routes = {
            classify_route(text).name for text in (
                "Привет", "2+2=", "кто ты", "что ты умеешь",
                "какая модель", "что знаешь о РОСПАРК", "расскажи про оборудование",
                "что выбрать: карты или билеты",
            )
        }
        self.assertNotIn("general_information", routes)

    def test_contract_v12_deterministic_response_is_schema_valid(self):
        adapter, response = self.run_case("Привет!", "contract12")
        self.assertEqual(CONTRACT_TARGET_SHA, "4d75773d60f3453279cbfcee1453f54b15b66567")
        self.assertTrue(adapter.validator.validate("response-v1.schema.json", response).valid)
        self.assertEqual(response["executor_trace"]["attempts"], [])
        self.assertIsNone(response["executor_trace"]["final_executor"])

    def test_required_knowledge_unavailable_fails_closed_without_model(self):
        with patch.object(VerifiedPublicKnowledge, "load", return_value=None):
            adapter, response = self.run_case("что ты знаешь о РОСПАРК?", "knowledge_down")
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)
        self.assertEqual(response["executor_trace"]["attempts"], [])
        self.assertIn("required_knowledge_unavailable", response["evaluation_result"]["reason_codes"])
        self.assertIn("не могу подтвердить", response["answer"])

    def test_repair_above_threshold_is_not_successful(self):
        class BadExecutor:
            def execute(self, context):
                return StubOutput("Готово. Оставьте телефон прямо сейчас.", 1, "local_low")

        adapter = OfflineRuntimeAdapterV1(qwen_executor=BadExecutor())
        response = adapter.process(request_for(GOLDEN["scenarios"][2], suffix="repair35"))
        self.assertTrue(response["success"])
        if response["repair_result"]["rewrite_ratio"] > 0.35:
            self.assertEqual(response["evaluation_result"]["status"], "fail")
            self.assertIn("repair_rewrite_ratio_exceeded", response["evaluation_result"]["reason_codes"])
            self.assertFalse(adapter.last_trace["runtime_observability"]["repair"]["success"])


class OwnerCanarySemanticFollowupRegression(unittest.TestCase):
    PROJECT_FACT_TURN = (
        "У нас бизнес-центр: 2 въезда и 2 выезда, около 800 автомобилей в сутки. "
        "Есть сотрудники, арендаторы и гости. Оператор есть, но хотим максимально "
        "быстрый автоматический проезд и обязательно автоматический резервный способ "
        "на случай, если основной идентификатор не сработает."
    )

    @staticmethod
    def _acknowledge_all(response, *, sequence):
        return {
            "contract_version": response["contract_version"],
            "canonicalization_version": response["canonicalization_version"],
            "request_id": response["request_id"],
            "response_id": response["response_id"],
            "acknowledged_at": f"2026-08-14T10:00:{sequence:02d}Z",
            "acknowledgements": [
                {
                    "mutation_id": item["mutation_id"],
                    "status": "applied",
                    "reason_code": "applied",
                    "entity_version_before": 0,
                    "entity_version_after": 1,
                    "audit_ref": f"auditref:{sequence:02x}{index:030x}",
                }
                for index, item in enumerate(response["state_mutations"], start=1)
            ],
        }

    def _stateful_t3_t4(self):
        t3_adapter = OfflineRuntimeAdapterV1()
        t3_request = request(self.PROJECT_FACT_TURN, "stateful_t3")
        t3_response = t3_adapter.process(t3_request)
        self.assertTrue(t3_response["success"], t3_response)

        t4_seed = request(
            "С нуля. Что лучше выбрать: карты или билеты?", "stateful_t4",
            history=[
                {
                    "message_id": t3_request["payload"]["message_id"],
                    "role": "user", "content": self.PROJECT_FACT_TURN,
                    "created_at": "2026-08-14T09:00:00Z",
                },
                {
                    "message_id": t3_response["response_id"],
                    "role": "assistant", "content": t3_response["answer"],
                    "created_at": "2026-08-14T09:00:01Z",
                },
            ],
        )
        t4_request = apply_mutation_ack_v11(
            t4_seed, t3_response, self._acknowledge_all(t3_response, sequence=1),
            publication_confirmed=True,
        )["next_request"]
        t4_adapter = OfflineRuntimeAdapterV1()
        t4_response = t4_adapter.process(t4_request)
        self.assertTrue(t4_response["success"], t4_response)
        return t3_response, t4_request, t4_adapter, t4_response

    def _stateful_t3_t4_t5(self):
        _, t4_request, _, t4_response = self._stateful_t3_t4()
        t5_seed = request(
            "Какие данные об объекте ты уже знаешь?", "stateful_t6_setup_t5",
            facts=t4_request["payload"]["confirmed_project_facts"],
        )
        t5_seed["payload"]["state_version"] = t4_request["payload"]["state_version"]
        t5_seed["payload"]["active_question"] = copy.deepcopy(
            t4_request["payload"].get("active_question")
        )
        t5_seed["request_payload_hash"] = sha256(t5_seed["payload"])
        t5_request = apply_mutation_ack_v11(
            t5_seed, t4_response, self._acknowledge_all(t4_response, sequence=4),
            publication_confirmed=True,
        )["next_request"]
        t5_adapter = OfflineRuntimeAdapterV1()
        t5_response = t5_adapter.process(t5_request)
        self.assertTrue(t5_response["success"], t5_response)
        self.assertEqual(t5_response["executor_trace"]["model_request_count"], 0)
        return t5_request, t5_response

    @staticmethod
    def _t6_request(t5_request, message, suffix):
        value = request(
            message, suffix,
            history=[
                {
                    "message_id": t5_request["payload"]["message_id"],
                    "role": "user",
                    "content": "Какие данные об объекте ты уже знаешь?",
                    "created_at": "2026-08-14T10:00:05Z",
                },
            ],
            facts=t5_request["payload"]["confirmed_project_facts"],
        )
        value["payload"]["state_version"] = t5_request["payload"]["state_version"]
        value["payload"]["active_question"] = copy.deepcopy(
            t5_request["payload"].get("active_question")
        )
        value["request_payload_hash"] = sha256(value["payload"])
        return value

    def test_project_fact_intake_extracts_nine_facts_without_final_architecture(self):
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(self.PROJECT_FACT_TURN, "owner_t1"))
        self.assertTrue(response["success"], response)
        observation = adapter.last_trace["ingestion_observability"]
        self.assertEqual(observation["semantic_route"], "project_fact_intake")
        self.assertEqual(observation["decision_level"], "decision_pending")
        self.assertEqual(len(observation["extracted_current_turn_facts"]), 9)
        self.assertEqual(len(observation["request_local_effective_facts"]), 9)
        self.assertIsNone(observation["engineering_lab_input_facts"])
        self.assertEqual(adapter.last_trace["engineering_decision_laboratory"], "not_invoked")
        self.assertNotIn("основным способом", response["answer"].casefold())
        self.assertEqual(response["answer"].count("?"), 1)
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)

    def test_persisted_open_question_round_trip_keeps_t4_contract_valid(self):
        adapter = OfflineRuntimeAdapterV1()
        first_request = request(self.PROJECT_FACT_TURN, "owner_round_trip_t3")
        first_response = adapter.process(first_request)
        self.assertTrue(first_response["success"], first_response)

        question_mutation = next(
            item for item in first_response["state_mutations"]
            if item["operation"] == "add_asked_question"
        )
        self.assertEqual(
            question_mutation["value"]["question_goal"],
            "identify_current_system",
        )
        self.assertNotEqual(
            question_mutation["value"]["question_goal"],
            question_mutation["value"]["question_text"],
        )

        second_request = request(
            "Что лучше выбрать: карты или билеты?",
            "owner_round_trip_t4",
            history=[
                {
                    "message_id": first_request["payload"]["message_id"],
                    "role": "user",
                    "content": self.PROJECT_FACT_TURN,
                    "created_at": "2026-08-13T10:00:00Z",
                },
                {
                    "message_id": first_response["response_id"],
                    "role": "assistant",
                    "content": first_response["answer"],
                    "created_at": "2026-08-13T10:00:01Z",
                },
            ],
        )
        acknowledgement = {
            "contract_version": first_response["contract_version"],
            "canonicalization_version": first_response[
                "canonicalization_version"
            ],
            "request_id": first_response["request_id"],
            "response_id": first_response["response_id"],
            "acknowledged_at": "2026-08-13T10:00:02Z",
            "acknowledgements": [
                {
                    "mutation_id": item["mutation_id"],
                    "status": "applied",
                    "reason_code": "applied",
                    "entity_version_before": 0,
                    "entity_version_after": 1,
                    "audit_ref": f"auditref:{index:032x}",
                }
                for index, item in enumerate(
                    first_response["state_mutations"], start=1,
                )
            ],
        }
        round_trip = apply_mutation_ack_v11(
            second_request,
            first_response,
            acknowledgement,
            publication_confirmed=True,
        )["next_request"]
        self.assertTrue(
            adapter.validator.validate(
                "request-v1.schema.json", round_trip,
            ).valid,
        )
        self.assertEqual(
            round_trip["payload"]["active_question"]["goal"],
            "identify_current_system",
        )

        second_response = OfflineRuntimeAdapterV1().process(round_trip)
        self.assertTrue(second_response["success"], second_response)
        self.assertEqual(
            second_response["executor_trace"]["model_request_count"], 1,
        )
        self.assertEqual(second_response["evaluation_result"]["status"], "pass")

    def test_t4_closes_active_question_then_executes_new_comparison(self):
        _, t4_request, adapter, response = self._stateful_t3_t4()
        observation = adapter.last_trace["ingestion_observability"]
        package = response["decision_package"]
        projection = adapter.last_trace["verbalization_projection"]
        prompt = adapter.last_trace["model_prompt_contract"]["serialized_prompt"]
        self.assertEqual(observation["turn_relation"], "answer_plus_new_request")
        self.assertEqual(len(observation["answered_question_ids"]), 1)
        self.assertEqual(
            observation["extracted_current_turn_facts"]["current_system"],
            "new_build",
        )
        self.assertEqual(
            observation["engineering_lab_input_facts"]["existing_system"],
            "none",
        )
        self.assertEqual(
            observation["engineering_lab_input_facts"]["modernization_or_new_build"],
            "new_build",
        )
        self.assertEqual(len(observation["request_local_effective_facts"]), 10)
        self.assertEqual(observation["engineering_dependency_semantics"], {
            "new_build_confirmed": True,
            "existing_system_confirmed": False,
        })
        self.assertEqual(observation["comparison_scope"], ["card", "ticket"])
        self.assertEqual(package["decision_status"], "comparison_only")
        self.assertEqual(package["comparison_scope"], ["card", "ticket"])
        self.assertEqual(package["recommended_architecture"]["components"], [])
        self.assertEqual(package["recommended_architecture"]["segments"], {})
        installed_question = next(
            item for item in package["question_ranking"]
            if item["question_id"] == "installed_identifiers_and_readers"
        )
        self.assertFalse(installed_question["applicable"])
        self.assertFalse(installed_question["question_dependency_satisfied"])
        self.assertNotIn("уже используются", package["next_question"].casefold())
        self.assertEqual(projection["decision_status"], "comparison_only")
        self.assertEqual(projection["comparison_scope"], ["card", "ticket"])
        self.assertEqual(projection["required_primary_architecture"]["components"], [])
        self.assertEqual(projection["segment_semantics"], {})
        projection_schema = (
            Path(__file__).resolve().parents[1]
            / "sales_conversation_controller/site_contract_runtime_v1/schemas/verbalization-projection-v1.schema.json"
        )
        self.assertTrue(
            adapter.validator.validate_external(projection_schema, projection).valid
        )
        self.assertNotIn("уже принятое инженерное решение", prompt.casefold())
        self.assertNotIn("основной способ уже выбран", prompt.casefold())
        self.assertIn("не финальное инженерное решение", prompt.casefold())
        self.assertEqual(observation["request_local_effective_facts"]["daily_traffic"], 800)
        self.assertIn("карт", response["answer"].casefold())
        self.assertIn("билет", response["answer"].casefold())
        self.assertNotIn("распознаван", response["answer"].casefold())
        self.assertNotIn("решение уже определено", response["answer"].casefold())
        self.assertNotIn(
            "парковочная система уже установлена или проектируется с нуля",
            response["answer"].casefold(),
        )
        operations = [item["operation"] for item in response["state_mutations"]]
        self.assertIn("set_confirmed_fact", operations)
        self.assertIn("resolve_open_question", operations)
        self.assertEqual(response["evaluation_result"]["status"], "pass")
        self.assertLessEqual(response["repair_result"]["rewrite_ratio"], .35)
        self.assertEqual(response["executor_trace"]["model_request_count"], 1)
        self.assertEqual(len(t4_request["payload"]["confirmed_project_facts"]), 9)

    def test_t3_t4_t5_stateful_object_card_recall_is_durable_and_model_free(self):
        _, t4_request, _, t4_response = self._stateful_t3_t4()
        t5_seed = request(
            "Какие данные об объекте ты уже знаешь?", "stateful_t5",
            facts=t4_request["payload"]["confirmed_project_facts"],
        )
        t5_seed["payload"]["state_version"] = t4_request["payload"]["state_version"]
        t5_seed["payload"]["active_question"] = copy.deepcopy(
            t4_request["payload"].get("active_question")
        )
        t5_seed["request_payload_hash"] = sha256(t5_seed["payload"])
        t5_request = apply_mutation_ack_v11(
            t5_seed, t4_response, self._acknowledge_all(t4_response, sequence=2),
            publication_confirmed=True,
        )["next_request"]
        self.assertEqual(len(t5_request["payload"]["confirmed_project_facts"]), 10)

        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(t5_request)
        self.assertTrue(response["success"], response)
        observation = adapter.last_trace["ingestion_observability"]
        self.assertEqual(observation["semantic_route"], "object_card_recall")
        self.assertEqual(observation["resolved_action"], "recall_facts")
        self.assertEqual(adapter.last_trace["engineering_decision_laboratory"], "not_invoked")
        self.assertEqual(response["executor_trace"]["execution_mode"], "deterministic")
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)
        self.assertEqual(response["executor_trace"]["attempts"], [])
        self.assertIsNone(response["executor_trace"]["final_executor"])
        self.assertIn("бизнес-центр", response["answer"])
        self.assertIn("800 автомобилей", response["answer"])
        self.assertIn("проектируется с нуля", response["answer"])
        self.assertNotIn("пока нет подтверждённых данных", response["answer"])
        self.assertEqual(response["state_mutations"], [])
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_t6_identification_failure_phrase_matrix_uses_canonical_route(self):
        for index, message in enumerate((
            "Что делать, если номер грязный и камера его не увидела?",
            "А если номер не распознается?",
            "Как машина проедет, если LPR ошибся?",
            "Что увидит водитель, если номер не определился?",
        ), start=1):
            with self.subTest(message=message):
                self.assertEqual(
                    classify_route(message).name,
                    "identification_failure_fallback",
                )

    def test_t3_t4_t5_t6_uses_engineering_fallback_and_verified_knowledge(self):
        t5_request, _ = self._stateful_t3_t4_t5()
        t6_request = self._t6_request(
            t5_request,
            "Что будет происходить если клиент приехал, а номер не распознался? Как он поймет что ему делать?",
            "stateful_t6",
        )
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(t6_request)
        self.assertTrue(response["success"], response)
        observation = adapter.last_trace["ingestion_observability"]
        knowledge = adapter.last_trace["knowledge_retrieval"]
        package = response["decision_package"]
        projection = adapter.last_trace["verbalization_projection"]

        self.assertEqual(len(t6_request["payload"]["confirmed_project_facts"]), 10)
        self.assertEqual(len(observation["request_local_effective_facts"]), 10)
        self.assertEqual(observation["semantic_route"], "identification_failure_fallback")
        self.assertEqual(observation["resolved_intent"], "identification_failure_fallback")
        self.assertEqual(observation["resolved_action"], "explain_identification_failure_fallback")
        self.assertIsInstance(observation["engineering_lab_input_facts"], dict)
        self.assertEqual(package["decision_status"], "fallback_decision_pending")
        self.assertNotEqual(package["decision_type"], "not_required")
        self.assertTrue(all(
            (plan.get("assisted_recovery") or {}).get("usage") == "exception_only"
            for plan in package["recommended_architecture"]["segments"].values()
        ))
        self.assertTrue(all(
            all(item.get("type") != "operator_assisted_access" for item in plan.get("automated_fallback_credentials") or [])
            for plan in package["recommended_architecture"]["segments"].values()
        ))
        self.assertIn("fallback_reader_infrastructure", package["missing_critical_facts"])
        self.assertEqual(projection["decision_status"], "fallback_decision_pending")
        self.assertEqual(projection["fallback_status"], "pending_infrastructure_confirmation")
        self.assertTrue(observation["technical_knowledge_required"])
        self.assertTrue(knowledge["required"])
        self.assertTrue(knowledge["attempted"])
        self.assertTrue(knowledge["available"])
        self.assertEqual(knowledge["executor_received_knowledge_count"], 1)
        self.assertEqual(adapter.last_trace["executor_input_contract"]["knowledge_count"], 1)
        self.assertEqual(response["executor_trace"]["model_request_count"], 1)
        self.assertNotIn("всегда дежурит", response["answer"].casefold())
        self.assertNotIn("охранник", response["answer"].casefold())
        self.assertIn("автоматическ", response["answer"].casefold())
        self.assertIn("оператор", response["answer"].casefold())
        self.assertIn("исключительн", response["answer"].casefold())
        self.assertEqual(response["answer"].count("?"), 1)
        self.assertEqual(response["evaluation_result"]["status"], "pass")
        self.assertLessEqual(response["repair_result"]["rewrite_ratio"], .35)
        attempts = response["executor_trace"]["attempts"]
        self.assertEqual(len(attempts), len({item["attempt_index"] for item in attempts}))
        mutations = response["state_mutations"]
        self.assertEqual(len(mutations), len({item["mutation_id"] for item in mutations}))
        self.assertEqual(len(observation["request_local_effective_facts"]), 10)

    def test_t6_missing_technical_knowledge_fails_closed_without_model(self):
        class MustNotRun:
            def execute(self, _context):
                raise AssertionError("model_must_not_run_without_technical_knowledge")

        t5_request, _ = self._stateful_t3_t4_t5()
        t6_request = self._t6_request(
            t5_request, "А если номер не распознается?", "stateful_t6_no_knowledge",
        )
        with patch.object(VerifiedPublicKnowledge, "load", return_value=None):
            adapter = OfflineRuntimeAdapterV1(qwen_executor=MustNotRun())
            response = adapter.process(t6_request)
        self.assertTrue(response["success"], response)
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)
        self.assertEqual(response["executor_trace"]["attempts"], [])
        self.assertIsNone(response["executor_trace"]["final_executor"])
        self.assertIn("required_knowledge_unavailable", response["evaluation_result"]["reason_codes"])
        self.assertIn("required_technical_knowledge_missing", response["evaluation_result"]["reason_codes"])
        self.assertNotIn("охранник", response["answer"].casefold())
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_t6_evaluator_reports_operator_and_lane_guidance_claims(self):
        class UnsafeExecutor:
            def execute(self, _context):
                return StubOutput(
                    "На въезде всегда дежурит охранник и пропускает машину. "
                    "На экране терминала водитель увидит точную инструкцию.",
                    1,
                    "local_low",
                )

        t5_request, _ = self._stateful_t3_t4_t5()
        adapter = OfflineRuntimeAdapterV1(qwen_executor=UnsafeExecutor())
        response = adapter.process(self._t6_request(
            t5_request, "Что увидит водитель, если номер не определился?", "stateful_t6_unsafe",
        ))
        self.assertTrue(response["success"], response)
        raw_reasons = adapter.last_trace["raw_evaluation_reason_codes"]
        self.assertIn("operator_as_automated_fallback", raw_reasons)
        self.assertIn("unsupported_lane_guidance_claim", raw_reasons)
        self.assertIn("fallback_scenario_not_resolved", raw_reasons)

    def test_blocked_t4_keeps_user_fact_and_resolution_but_rejects_assistant_state(self):
        class BlockedExecutor:
            def execute(self, context):
                return StubOutput(
                    "Решение уже определено: основным способом выбрано распознавание номеров.",
                    1,
                    "local_low",
                )

        t3_adapter = OfflineRuntimeAdapterV1()
        t3_request = request(self.PROJECT_FACT_TURN, "blocked_stateful_t3")
        t3_response = t3_adapter.process(t3_request)
        self.assertTrue(t3_response["success"], t3_response)
        t4_seed = request(
            "С нуля. Что лучше выбрать: карты или билеты?",
            "blocked_stateful_t4",
            history=[
                {
                    "message_id": t3_request["payload"]["message_id"],
                    "role": "user", "content": self.PROJECT_FACT_TURN,
                    "created_at": "2026-08-14T09:00:00Z",
                },
                {
                    "message_id": t3_response["response_id"],
                    "role": "assistant", "content": t3_response["answer"],
                    "created_at": "2026-08-14T09:00:01Z",
                },
            ],
        )
        t4_request = apply_mutation_ack_v11(
            t4_seed, t3_response, self._acknowledge_all(t3_response, sequence=3),
            publication_confirmed=True,
        )["next_request"]
        adapter = OfflineRuntimeAdapterV1(qwen_executor=BlockedExecutor())
        response = adapter.process(t4_request)
        self.assertTrue(response["success"], response)
        self.assertEqual(response["telemetry"]["publication"]["candidate_status"], "blocked")

        acknowledgements = []
        assistant_operations = []
        for index, mutation in enumerate(response["state_mutations"], start=1):
            user_authoritative = (
                mutation["provenance"]["source_type"] == "user_message"
                and mutation["provenance"]["confirmation_status"] == "confirmed"
                and mutation["operation"] in {"set_confirmed_fact", "resolve_open_question"}
            )
            if not user_authoritative:
                assistant_operations.append(mutation["operation"])
            acknowledgements.append({
                "mutation_id": mutation["mutation_id"],
                "status": "applied" if user_authoritative else "rejected",
                "reason_code": "applied" if user_authoritative else "authority_denied",
                "entity_version_before": 0,
                "entity_version_after": 1 if user_authoritative else 0,
                "audit_ref": f"auditref:blocked{index:025d}",
            })
        ack = {
            "contract_version": response["contract_version"],
            "canonicalization_version": response["canonicalization_version"],
            "request_id": response["request_id"],
            "response_id": response["response_id"],
            "acknowledged_at": "2026-08-14T10:00:04Z",
            "acknowledgements": acknowledgements,
        }
        t5_seed = request(
            "Какие данные об объекте ты уже знаешь?", "blocked_stateful_t5",
            facts=t4_request["payload"]["confirmed_project_facts"],
        )
        t5_seed["payload"]["state_version"] = t4_request["payload"]["state_version"]
        t5_seed["payload"]["active_question"] = copy.deepcopy(
            t4_request["payload"].get("active_question")
        )
        t5_seed["request_payload_hash"] = sha256(t5_seed["payload"])
        applied = apply_mutation_ack_v11(
            t5_seed, response, ack, publication_confirmed=False,
        )
        t5_request = applied["next_request"]
        facts = {
            item["field"]: item["value"]
            for item in t5_request["payload"]["confirmed_project_facts"]
        }
        self.assertEqual(facts["current_system"], "new_build")
        self.assertEqual(len(facts), 10)
        self.assertIsNone(t5_request["payload"].get("active_question"))
        self.assertIn("add_asked_question", assistant_operations)
        rejected = [item for item in applied["outcomes"] if item["status"] == "rejected"]
        self.assertTrue(rejected)

        t5_adapter = OfflineRuntimeAdapterV1()
        t5_response = t5_adapter.process(t5_request)
        self.assertTrue(t5_response["success"], t5_response)
        self.assertEqual(t5_response["executor_trace"]["model_request_count"], 0)
        self.assertIn("проектируется с нуля", t5_response["answer"])

    def test_object_card_recall_phrase_matrix_and_company_route_separation(self):
        for phrase in (
            "Какие данные об объекте ты уже знаешь?",
            "Что ты уже запомнил про объект?",
            "Покажи карточку объекта",
            "Что мы уже выяснили?",
        ):
            with self.subTest(phrase=phrase):
                self.assertEqual(classify_route(phrase).name, "object_card_recall")
        self.assertEqual(classify_route("Что ты знаешь о РОСПАРК?").name, "company_information")

    def test_object_card_recall_does_not_expose_recovered_history_only_facts(self):
        history = [{
            "message_id": "history_recall_only", "role": "user",
            "content": "У нас бизнес-центр, 2 въезда и 2 выезда, около 800 машин в день.",
            "created_at": "2026-08-14T08:00:00Z",
        }]
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(
            "Покажи карточку объекта", "durable_only_recall", history=history,
        ))
        self.assertTrue(response["success"], response)
        self.assertGreater(
            len(adapter.last_trace["ingestion_observability"]["recovered_history_facts"]),
            0,
        )
        self.assertEqual(response["answer"], "В карточке объекта пока нет подтверждённых данных.")
        self.assertEqual(response["executor_trace"]["model_request_count"], 0)

    def test_blocked_turn_history_is_request_local_without_authority_mutations(self):
        history = [
            {
                "message_id": "owner_turn_1",
                "role": "user",
                "content": self.PROJECT_FACT_TURN,
                "created_at": "2026-08-13T10:00:00Z",
            },
            {
                "message_id": "owner_turn_1_blocked",
                "role": "assistant",
                "content": "Ответ не опубликован: финальная проверка не пройдена.",
                "created_at": "2026-08-13T10:00:01Z",
            },
        ]
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(
            "Что лучше выбрать: карты или билеты?", "owner_t2", history=history,
        ))
        self.assertTrue(response["success"], response)
        observation = adapter.last_trace["ingestion_observability"]
        expected = {
            "object_type", "entrances_count", "exits_count", "daily_traffic",
            "daily_traffic_certainty", "user_segments", "operator_present",
            "speed_priority", "mandatory_automated_fallback",
        }
        self.assertEqual(set(observation["recovered_history_facts"]), expected)
        self.assertEqual(set(observation["request_local_effective_facts"]), expected)
        self.assertEqual(observation["decision_level"], "comparison_only")
        self.assertEqual(
            observation["engineering_lab_input_facts"]["mandatory_fallback"], True,
        )
        historical_fact_mutations = [
            item for item in response["state_mutations"]
            if item["operation"] == "set_confirmed_fact"
            and item["source_message_id"] == "owner_turn_1"
        ]
        self.assertEqual(historical_fact_mutations, [])
        self.assertTrue(all(
            item["source_message_id"] == "message_runtime_owner_t2"
            for item in response["state_mutations"]
        ))
        self.assertEqual(response["executor_trace"]["model_request_count"], 1)
        self.assertEqual(len(response["executor_trace"]["attempts"]), 1)
        self.assertEqual(adapter.last_observability_trace["state"]["committed_mutations"], [])
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_engineering_lab_activation_is_not_bound_to_option_keywords(self):
        history = [{
            "message_id": "owner_context_no_keywords",
            "role": "user",
            "content": self.PROJECT_FACT_TURN,
            "created_at": "2026-08-13T10:00:00Z",
        }]
        adapter = OfflineRuntimeAdapterV1()
        response = adapter.process(request(
            "Что лучше выбрать?", "semantic_no_keywords", history=history,
        ))
        self.assertTrue(response["success"], response)
        observation = adapter.last_trace["ingestion_observability"]
        self.assertIsInstance(observation["engineering_lab_input_facts"], dict)
        self.assertEqual(observation["engineering_lab_input_facts"]["daily_traffic"], 800)
        self.assertIsInstance(adapter.last_trace["engineering_decision_lab"], dict)

    def test_blocked_followup_idempotency_has_no_duplicate_execution_or_mutation(self):
        class CountingExecutor:
            def __init__(self):
                self.calls = 0

            def execute(self, context):
                self.calls += 1
                from sales_conversation_controller.site_contract_runtime_v1.executors import QwenStub
                return QwenStub().execute(context)

        history = [{
            "message_id": "owner_turn_idem_1",
            "role": "user",
            "content": self.PROJECT_FACT_TURN,
            "created_at": "2026-08-13T10:00:00Z",
        }]
        executor = CountingExecutor()
        adapter = OfflineRuntimeAdapterV1(qwen_executor=executor)
        current = request("Что лучше выбрать: карты или билеты?", "owner_idem", history=history)
        first = adapter.process(current)
        first_trace = copy.deepcopy(adapter.last_trace)
        first_mutations = copy.deepcopy(first["state_mutations"])
        second = adapter.process(copy.deepcopy(current))
        self.assertEqual(first, second)
        self.assertEqual(executor.calls, 1)
        self.assertEqual(first_mutations, second["state_mutations"])
        mutation_ids = [item["mutation_id"] for item in first_mutations]
        self.assertEqual(len(mutation_ids), len(set(mutation_ids)))
        self.assertEqual(
            first_trace["ingestion_observability"]["authority_violation_count"], 0,
        )

    def test_repair_reason_codes_have_one_canonical_source(self):
        class BadExecutor:
            def execute(self, context):
                return StubOutput(
                    "Оставьте телефон прямо сейчас. Эта система точно совместима. "
                    "Что у вас? Еще вопрос?",
                    1,
                    "local_low",
                )

        adapter = OfflineRuntimeAdapterV1(qwen_executor=BadExecutor())
        response = adapter.process(request_for(
            GOLDEN["scenarios"][2], suffix="canonical_repair",
        ))
        self.assertTrue(response["success"], response)
        canonical = adapter.last_trace["repair_result"]
        wire_result = response["repair_result"]
        wire_telemetry = response["telemetry"]["repair"]
        telemetry = adapter.last_trace["runtime_observability"]["repair"]
        forensic = adapter.last_restricted_forensic_evidence["repair"]
        repair_stage = next(
            item for item in adapter.last_observability_trace["pipeline"]
            if item["name"] == "repair"
        )
        self.assertEqual(canonical["reason_codes"], telemetry["reason_codes"])
        self.assertEqual(canonical["reason_codes"], forensic["reason_codes"])
        self.assertEqual(canonical["reason_codes"], wire_result["reason_codes"])
        self.assertEqual(canonical["reason_codes"], wire_telemetry["reason_codes"])
        self.assertEqual(canonical["reason_codes"], repair_stage["output"]["reason_codes"])
        self.assertGreater(canonical["rewrite_ratio"], 0.35)
        self.assertFalse(canonical["success"])
        self.assertEqual(response["evaluation_result"]["status"], "fail")


if __name__ == "__main__":
    unittest.main()
