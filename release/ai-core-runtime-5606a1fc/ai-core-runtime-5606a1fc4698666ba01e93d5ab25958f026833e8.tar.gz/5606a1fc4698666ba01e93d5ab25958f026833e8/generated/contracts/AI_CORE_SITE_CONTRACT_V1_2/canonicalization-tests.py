#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / "reference/canonical_json_hash_v1.py"
spec = importlib.util.spec_from_file_location("canonical_json_hash_v1", REFERENCE)
if spec is None or spec.loader is None:
    raise RuntimeError("reference canonicalizer unavailable")
canonical = importlib.util.module_from_spec(spec)
spec.loader.exec_module(canonical)


def main() -> int:
    corpus = json.loads(
        (ROOT / "fixtures/canonical-json-hash-v1-golden.json").read_text(
            encoding="utf-8"
        )
    )
    assert corpus["canonicalization_version"] == canonical.CANONICALIZATION_VERSION
    for vector in corpus["valid_vectors"]:
        value = json.loads(vector["semantic_json"])
        assert canonical.canonical_json(value) == vector["expected_canonical_utf8"]
        assert canonical.canonical_sha256(value) == vector["expected_sha256"]

    rejection_values = {
        "NaN": float("nan"),
        "Infinity": float("inf"),
        "-Infinity": float("-inf"),
        "9007199254740992": 9_007_199_254_740_992,
        "unpaired_high_surrogate": "\ud800",
    }
    for vector in corpus["rejection_vectors"]:
        try:
            canonical.canonical_json(rejection_values[vector["runtime_value"]])
        except canonical.CanonicalizationError as error:
            assert str(error) == vector["expected_error"]
        else:
            raise AssertionError(f"rejection vector accepted: {vector['id']}")

    incident = json.loads(
        (ROOT / "fixtures/regression/failed-live-decision-package.json").read_text(
            encoding="utf-8"
        )
    )
    assert incident["integral_float_count"] == 57
    assert (
        canonical.canonical_sha256(incident["decision_package"])
        == incident["expected_canonical_sha256"]
    )
    print(json.dumps({
        "canonicalization_version": canonical.CANONICALIZATION_VERSION,
        "golden_vectors": len(corpus["valid_vectors"]),
        "rejection_vectors": len(corpus["rejection_vectors"]),
        "incident_regression": "pass",
        "result": "pass",
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
