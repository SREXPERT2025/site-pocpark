# Version compatibility and transport semantics

## Версии

Canonical contract version: `1.2`.
Canonical hashing version: `CANONICAL_JSON_HASH_V1`.

Эта immutable revision v1.2.x делает repair integrity wire-поля обязательными:
`response.repair_result.reason_codes` и
`response.telemetry.repair.reason_codes`. Их отсутствие или несовпадение
завершает обработку fail closed; fallback между источниками запрещён. Точная
revision identity определяется Git commit SHA, строка protocol version остаётся
`1.2`.

- additive optional field без изменения смысла — совместимый minor release;
- новое required field, удаление поля, изменение enum или семантики — новый major schema ID;
- неизвестный major или неизвестная component version — fail closed;
- `not_invoked` разрешён только для компонента, который действительно не участвовал;
- Site pin-ит schema package hash и не выводит версию из имени файла или branch.

## Idempotency

Site владеет idempotency store.

Ключ обработки:

```text
conversation_thread_id + message_id + idempotency_key
```

`request_payload_hash` — SHA-256 точных UTF-8 bytes объекта `payload` по
`CANONICAL_JSON_HASH_V1`. Правила чисел, Unicode, sorting, rejection и encoding
заданы в `CANONICAL_JSON_HASH_V1.md`, а не делегированы сериализатору языка.

- повтор с тем же ключом и тем же payload hash возвращает byte-identical cached response;
- тот же ключ с другим payload hash возвращает safe error
  `IDEMPOTENCY_CONFLICT` и не вызывает AI Core;
- timeout не разрешает слепой повтор: сначала Site проверяет сохранённый response;
- `request_id`, `sent_at` и trace context не меняют identity domain payload;
- mutation ID применяется не более одного раза и получает deterministic ack.

## Executor и fallback

- planned assignment передаёт Site и AI Core его не изменяет;
- целевая цепочка: `codex → qwen`;
- разрешён максимум один model fallback;
- каждый attempt использует одинаковые `decision_package_hash` и `state_version`;
- fallback не меняет confirmed facts, next question или thread state;
- `final_executor` равен единственному successful attempt;
- текст ответа берётся целиком только от final executor;
- deterministic FAQ/safe response — route, а не executor reassignment;
- `execution_mode=model` требует хотя бы один model attempt, ненулевой
  `model_request_count`, model `planned_executor` и model `final_executor`;
- `execution_mode=deterministic` требует `attempts=[]`,
  `planned_executor=null`, `final_executor=null`, `model_request_count=0`,
  `fallback_reason=none` и разрешённый стабильный `deterministic_handler`;
- смешивание deterministic handler с model attempt запрещено.

## Mutations

AI Core возвращает proposal с `expected_state_version`. Site проверяет schema,
authority, privacy, version и conflict, затем возвращает `mutation-ack-v1`.
Предложенная версия должна быть ровно `expected_state_version + 1` для
последовательного применения. Hint с `unconfirmed` provenance нельзя применить
как confirmed fact. Decision Package не является mutation target.

## Ошибки

Error envelope содержит только стабильный code/category/retryable/stage и
safe message code. Raw exception, stack trace, свободный пользовательский текст,
PII и credential запрещены.

Unsupported `canonicalization_version`, canonicalizer failure и любой hash
mismatch завершаются fail closed. Site обязан самостоятельно пересчитать hash.

## Publication

Только final visible candidate с Evaluation Integrity `pass` может быть
кандидатом на публикацию. `review_required`, `fail` и `not_evaluable` не дают
автоматического разрешения. Настоящая production policy остаётся отдельным gate.

Repair integrity проверяется отдельно от publication: совпавший canonical набор
`repair_rewrite_ratio_exceeded` проходит integrity gate, но blocked publication
не становится разрешённой.
