# CANONICAL_JSON_HASH_V1

`CANONICAL_JSON_HASH_V1` is the byte contract used whenever Site and AI Core
compare a SHA-256 digest of a JSON value. It is intentionally independent of
`json.dumps`, `JSON.stringify`, locale, process encoding, and object insertion
order.

## Accepted data model

The input MUST be a finite JSON tree consisting only of objects with string
keys, arrays without holes, strings containing Unicode scalar values,
booleans, null, and finite IEEE-754 binary64 numbers. Integer-valued numbers
outside the interoperable range `[-9007199254740991, 9007199254740991]` are
rejected because their value cannot be transported losslessly by both Python
and JavaScript JSON implementations. Cyclic structures and non-JSON runtime
values are rejected.

## Canonical UTF-8 representation

1. Object members are ordered lexicographically by Unicode scalar value of
   the key. Duplicate JSON member names MUST be rejected by the parser before
   canonicalization. No whitespace is emitted.
2. Array element order is preserved exactly.
3. Strings are enclosed in U+0022 quotation marks. U+0022 and U+005C are
   escaped as `\"` and `\\`. Every control scalar U+0000 through U+001F is
   escaped as lowercase `\u00xx`. Every other Unicode scalar is emitted
   literally. Unpaired UTF-16 surrogates are rejected.
4. `null`, `true`, and `false` are emitted as those exact ASCII tokens.
5. A number is interpreted as its IEEE-754 binary64 value. Positive and
   negative zero both serialize as `0`. Every other accepted number is
   rendered as the exact base-10 value of that binary64 number in fixed-point
   notation, with no leading plus sign, no unnecessary leading zeroes, no
   trailing fractional zeroes, and no decimal point for an integral value.
   Exponent notation is never emitted; exponent-form inputs are normalized to
   the same exact fixed-point representation. NaN and infinities are rejected.
6. The resulting Unicode string is encoded as strict UTF-8 without BOM.
7. SHA-256 is computed over exactly those UTF-8 bytes and represented as 64
   lowercase hexadecimal characters.

## Failure semantics

Canonicalizer failure, unsupported `canonicalization_version`, and digest
mismatch are contract failures. Callers MUST fail closed and MUST NOT trust a
digest supplied by the other side without recomputing it.

The authoritative cross-language vectors are
`fixtures/canonical-json-hash-v1-golden.json`. The sanitized incident fixture
is `fixtures/regression/failed-live-decision-package.json`.
