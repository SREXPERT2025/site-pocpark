# OWNER_CANARY_BLOCKED_FORENSIC_V1

Ограниченное forensic-расширение для заблокированных authenticated Owner Canary turns.

- Базовый Site↔Runtime Contract не изменён.
- Runtime формирует payload до publication rejection и не включает полный текст пользователя.
- `raw_answer` и `repaired_answer` разрешены только для ограниченного owner forensic storage.
- Сайт отвечает за авторизацию, срок хранения, права доступа и корреляцию по `ai_core_request_id`.
- Обычные Site B events не получают тексты ответов.

Schema SHA256: `37d3ac2a9dadb34790035a7ff52e4623f2753130fae1896a87f59310bb7c3149`.
