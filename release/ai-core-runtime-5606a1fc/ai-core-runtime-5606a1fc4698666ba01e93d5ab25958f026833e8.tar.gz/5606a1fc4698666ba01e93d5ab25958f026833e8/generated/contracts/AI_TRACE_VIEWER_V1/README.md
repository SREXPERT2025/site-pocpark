# AI_TRACE_VIEWER_V1 — Runtime observability boundary

`AI_CORE_RUNTIME_TRACE_V1` is an additive transport-side observability envelope.
It is deliberately outside `response-v1.schema.json`, so the AI Core Site
Contract, canonicalization rules, decision semantics, prompts, repair, and
publication gates remain unchanged.

The envelope contains observable structured inputs and outputs only. It never
asks for or stores chain-of-thought. Cookie, credential, token, API-key,
environment, and hidden-reasoning fields are removed or redacted.

The Site is the retention and access-control authority:

- full trace payload: 14 days;
- immutable aggregate metadata: 90 days;
- owner annotations: separate append-only records;
- owner/admin director authorization only;
- trace storage failure is fail-open relative to an otherwise publishable
  customer answer.
