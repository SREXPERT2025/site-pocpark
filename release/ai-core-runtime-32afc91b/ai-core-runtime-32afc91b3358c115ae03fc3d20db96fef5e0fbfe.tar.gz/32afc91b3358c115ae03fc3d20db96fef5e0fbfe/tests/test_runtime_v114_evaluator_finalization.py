from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

from sales_conversation_controller.site_contract_runtime_v1 import OfflineRuntimeAdapterV1
from sales_conversation_controller.site_contract_runtime_v1.canonical import canonical_sha256
from sales_conversation_controller.site_contract_runtime_v1.executors import StubOutput
from sales_conversation_controller.verbalization_semantics import (
    recommendation_basis_present,
    recommendation_present,
)
from tests.test_site_contract_runtime_v1 import request_for


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = json.loads(
    (ROOT / "tests/fixtures/real_qwen_probe_6a937b7d_raw_001.json").read_text(encoding="utf-8")
)


class FrozenExecutor:
    executor = "qwen"

    def __init__(self, answer: str) -> None:
        self.answer = answer
        self.calls = 0

    def execute(self, context):
        self.calls += 1
        return StubOutput(self.answer, 1, "local_low")


def run_saved(suffix: str = "v114_saved"):
    executor = FrozenExecutor(FIXTURE["raw_answer"])
    adapter = OfflineRuntimeAdapterV1(qwen_executor=executor)
    response = adapter.process(request_for({
        "message": FIXTURE["current_message"],
        "route": "qwen",
    }, suffix=suffix))
    return executor, adapter, response


class RecommendationDetectionTests(unittest.TestCase):
    def test_01_saved_evidence_hash(self):
        self.assertEqual(
            hashlib.sha256(FIXTURE["raw_answer"].encode()).hexdigest(),
            FIXTURE["raw_answer_sha"],
        )

    def test_02_we_selected_as_primary(self):
        self.assertTrue(recommendation_present("Мы выбрали карты как основной способ идентификации."))

    def test_03_selected_as_primary(self):
        self.assertTrue(recommendation_present("Выбрано распознавание номеров как основное решение."))

    def test_04_primary_solution_is(self):
        self.assertTrue(recommendation_present("Основным решением является распознавание номеров."))

    def test_05_mention_only_consider(self):
        self.assertFalse(recommendation_present("Рассмотрим распознавание номеров."))

    def test_06_one_of_options(self):
        self.assertFalse(recommendation_present("Карта является одним из вариантов."))

    def test_07_can_study(self):
        self.assertFalse(recommendation_present("Можно изучить билеты."))


class RecommendationBasisTests(unittest.TestCase):
    def test_08_same_sentence_basis(self):
        self.assertTrue(recommendation_basis_present(
            "С учётом потока 800 машин в день мы выбрали номера как основной способ."
        ))

    def test_09_preceding_sentence_basis(self):
        self.assertTrue(recommendation_basis_present(
            "Для объекта приоритетна скорость. Основным решением является распознавание номеров."
        ))

    def test_10_no_recommendation_no_basis(self):
        self.assertFalse(recommendation_basis_present(
            "Для бизнес-центра с потоком 800 машин в день рассмотрим номера."
        ))

    def test_11_saved_basis(self):
        self.assertTrue(recommendation_basis_present(FIXTURE["raw_answer"]))


class SavedProbeReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.executor, cls.adapter, cls.response = run_saved()
        cls.trace = cls.adapter.last_trace

    def test_12_offline_only_one_frozen_call(self):
        self.assertEqual(self.executor.calls, 1)

    def test_13_saved_recommendation_and_basis_pass(self):
        command = self.trace["raw_evaluation"]["command_assessment"]
        self.assertTrue(command["recommended_option_present"])
        self.assertTrue(command["recommendation_basis_present"])
        self.assertEqual(command["result"], "pass")
        self.assertNotIn("recommendation_missing", command.get("missing_requirements") or [])

    def test_14_current_turn_context_invariant(self):
        context = self.trace["raw_evaluation"]["context_assessment"]
        self.assertEqual(context["uses_current_turn"], "pass")
        self.assertEqual(context["result"], "pass")
        self.assertTrue(set(context["required_entities"]) <= set(context["covered_entities"]))
        self.assertNotIn("context_assessment_failed", context.get("reason_codes") or [])

    def test_15_raw_coverage_exact(self):
        coverage = self.trace["raw_semantic_coverage"]
        self.assertEqual(coverage["primary"], "pass")
        self.assertEqual(coverage["authorization"], "pass")
        self.assertEqual(coverage["assisted_recovery"], "pass")
        self.assertEqual(coverage["fallback_semantics"], "pass")
        self.assertEqual(coverage["tradeoffs"], "missing")
        self.assertEqual(coverage["unknown_conditionality"], "missing")
        self.assertEqual(coverage["next_question"], "pass")
        self.assertEqual(coverage["reason_codes"], FIXTURE["expected"]["raw_reason_codes"])

    def test_16_raw_review_required_without_false_negatives(self):
        self.assertEqual(self.response["telemetry"]["evaluation"]["raw_status"], "review_required")
        violations = self.trace["raw_evaluation"]["violations"]
        for code in ("recommendation_missing", "command_assessment_failed", "context_assessment_failed"):
            self.assertNotIn(code, violations)

    def test_17_repaired_final_pass(self):
        self.assertEqual(self.response["telemetry"]["evaluation"]["final_status"], "pass")
        self.assertEqual(self.response["evaluation_result"]["reason_codes"], [])
        self.assertEqual(self.trace["final_evaluation"]["violations"], [])

    def test_18_rewrite_ratio_unchanged(self):
        self.assertEqual(self.response["repair_result"]["rewrite_ratio"], FIXTURE["expected"]["rewrite_ratio"])
        self.assertLessEqual(self.response["repair_result"]["rewrite_ratio"], 0.35)

    def test_19_decision_package_immutable(self):
        expected = canonical_sha256(self.response["decision_package"])
        self.assertEqual(self.response["decision_package_hash"], expected)
        self.assertEqual(set(self.trace["decision_package_hashes"].values()), {expected})

    def test_20_projection_and_safety_invariants(self):
        self.assertEqual(self.trace["projection_decision_drift"], [])
        self.assertEqual(
            self.trace["model_prompt_contract"]["projection_hash"],
            canonical_sha256(self.trace["verbalization_projection"]),
        )
        fidelity = self.trace["final_verbalization_fidelity"]
        self.assertEqual(fidelity["unknown_facts_promoted"], 0)
        self.assertEqual(fidelity["new_engineering_decisions"], 0)
        self.assertEqual(fidelity["operator_semantic_violations"], 0)
        self.assertEqual(fidelity["unconfirmed_fallback_selections"], 0)

    def test_21_final_question_and_markers(self):
        answer = self.response["answer"]
        question = self.response["next_question"]
        self.assertEqual(answer.count(question), 1)
        self.assertNotIn("exact_next_question", answer)
        self.assertEqual(self.trace["final_evaluation"]["command_assessment"]["result"], "pass")
        self.assertEqual(self.trace["final_evaluation"]["context_assessment"]["result"], "pass")


if __name__ == "__main__":
    unittest.main()
