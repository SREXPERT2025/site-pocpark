from __future__ import annotations

import copy
import hashlib
import json
import unittest
from pathlib import Path
from unittest.mock import patch

from sales_conversation_controller.site_contract_runtime_v1 import OfflineRuntimeAdapterV1
from sales_conversation_controller.site_contract_runtime_v1.canonical import canonical_sha256
from sales_conversation_controller.site_contract_runtime_v1.executors import StubOutput
from sales_conversation_controller.verbalization_fidelity import evaluate_verbalization_fidelity
from sales_conversation_controller.verbalization_projection import (
    build_model_prompt_contract,
    build_projection_prompt,
    build_verbalization_projection,
    forbidden_internal_tokens,
    projection_decision_drift,
    sha256 as projection_sha256,
)
from sales_conversation_controller.verbalization_semantics import (
    operator_presented_as_automatic_fallback,
    recommendation_present,
)
from tests.test_site_contract_runtime_v1 import request_for


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = json.loads((ROOT / "tests/fixtures/real_qwen_reprobe_38a66115_raw_001.json").read_text(encoding="utf-8"))


class FrozenExecutor:
    executor = "qwen"

    def __init__(self, answer: str) -> None:
        self.answer = answer
        self.calls = 0

    def execute(self, context):
        self.calls += 1
        return StubOutput(self.answer, 1, "local_low")


def probe_request(suffix: str) -> dict:
    return request_for({"message": FIXTURE["current_message"], "route": "qwen"}, suffix=suffix)


def run_saved(suffix: str = "v113_saved"):
    executor = FrozenExecutor(FIXTURE["raw_answer"])
    adapter = OfflineRuntimeAdapterV1(qwen_executor=executor)
    response = adapter.process(probe_request(suffix))
    return executor, adapter, response


class ServiceMarkerTests(unittest.TestCase):
    def test_01_fixture_hash_is_immutable(self):
        self.assertEqual(hashlib.sha256(FIXTURE["raw_answer"].encode()).hexdigest(), FIXTURE["raw_answer_sha"])

    def test_02_prompt_has_no_internal_marker(self):
        _, adapter, _ = run_saved("v113_prompt_marker")
        prompt = adapter.last_trace["model_prompt_contract"]["serialized_prompt"]
        self.assertEqual(forbidden_internal_tokens(prompt), [])

    def test_03_prompt_materializes_exact_question(self):
        _, adapter, response = run_saved("v113_prompt_question")
        prompt = adapter.last_trace["model_prompt_contract"]["serialized_prompt"]
        self.assertIn(response["next_question"], prompt)
        self.assertNotIn("exact_next_question", prompt)

    def test_04_forbidden_marker_scan(self):
        self.assertEqual(forbidden_internal_tokens("Ответ: exact_next_question"), ["exact_next_question"])

    def test_05_pre_model_fail_closed(self):
        executor = FrozenExecutor("Не должен вызываться")
        adapter = OfflineRuntimeAdapterV1(qwen_executor=executor)
        with patch(
            "sales_conversation_controller.site_contract_runtime_v1.adapter.build_model_prompt_contract",
            side_effect=ValueError("forbidden_internal_token_in_model_prompt"),
        ):
            response = adapter.process(probe_request("v113_fail_closed"))
        self.assertFalse(response["success"])
        self.assertEqual(executor.calls, 0)

    def test_06_marker_removed_from_final(self):
        _, _, response = run_saved("v113_marker_removed")
        self.assertNotIn("exact_next_question", response["answer"])

    def test_07_exact_question_once(self):
        _, _, response = run_saved("v113_question_once")
        self.assertEqual(response["answer"].count(response["next_question"]), 1)


class RecommendationTests(unittest.TestCase):
    def test_08_primary_solution_is(self):
        self.assertTrue(recommendation_present("Основным решением является распознавание номеров."))

    def test_09_primary_method_is(self):
        self.assertTrue(recommendation_present("Основным способом является распознавание номеров."))

    def test_10_primary_option_dash(self):
        self.assertTrue(recommendation_present("Основной вариант — распознавание номеров."))

    def test_11_recommend(self):
        self.assertTrue(recommendation_present("Рекомендую распознавание номеров."))

    def test_12_propose(self):
        self.assertTrue(recommendation_present("Предлагаю распознавание номеров."))

    def test_13_advisable(self):
        self.assertTrue(recommendation_present("Целесообразно использовать распознавание номеров как основной способ."))

    def test_14_better_use(self):
        self.assertTrue(recommendation_present("Лучше использовать распознавание номеров."))

    def test_15_preferable(self):
        self.assertTrue(recommendation_present("Для этого объекта предпочтительно распознавание номеров."))

    def test_16_plain_mention_is_not_recommendation(self):
        self.assertFalse(recommendation_present("Распознавание номеров, карты и билеты существуют."))

    def test_17_rejected_option_is_not_recommendation(self):
        self.assertFalse(recommendation_present("Не рекомендую карты без подтверждённого считывателя."))


class FidelityDetectorTests(unittest.TestCase):
    def test_18_negated_operator_fallback_is_safe(self):
        text = "Оператор не является автоматическим резервом; его роль ограничена исключением при сбоях."
        self.assertFalse(operator_presented_as_automatic_fallback(text))

    def test_19_real_operator_fallback_is_violation(self):
        self.assertTrue(operator_presented_as_automatic_fallback("Оператор используется как автоматический резерв."))

    def test_20_saved_raw_operator_violation_zero(self):
        _, adapter, _ = run_saved("v113_operator_saved")
        self.assertEqual(adapter.last_trace["raw_verbalization_fidelity"]["operator_semantic_violations"], 0)

    def test_21_saved_raw_new_decisions_zero(self):
        _, adapter, _ = run_saved("v113_decisions_saved")
        self.assertEqual(adapter.last_trace["raw_verbalization_fidelity"]["new_engineering_decisions"], 0)

    def test_22_real_new_fallback_detected(self):
        _, adapter, response = run_saved("v113_package_for_bad")
        result = evaluate_verbalization_fidelity("Автоматическим резервом будет RFID.", response["decision_package"])
        self.assertGreater(result.new_engineering_decisions, 0)

    def test_23_conditional_candidates_are_not_decisions(self):
        _, adapter, response = run_saved("v113_package_for_conditional")
        text = "Карты, RFID и QR требуют подтверждения наличия соответствующих считывателей."
        self.assertEqual(evaluate_verbalization_fidelity(text, response["decision_package"]).new_engineering_decisions, 0)


class SavedReprobePipelineTests(unittest.TestCase):
    def test_24_saved_recommendation_detected(self):
        _, adapter, _ = run_saved("v113_recommendation")
        command = adapter.last_trace["raw_evaluation"]["command_assessment"]
        self.assertTrue(command["recommended_option_present"])
        self.assertEqual(command["result"], "pass")

    def test_25_saved_current_turn_pass(self):
        _, adapter, _ = run_saved("v113_current_turn")
        context = adapter.last_trace["raw_evaluation"]["context_assessment"]
        self.assertEqual(context["uses_current_turn"], "pass")
        self.assertEqual(context["result"], "pass")
        self.assertTrue(set(context["required_entities"]) <= set(context["covered_entities"]))

    def test_26_saved_raw_internal_marker_is_now_blocked(self):
        _, adapter, response = run_saved("v113_raw_status")
        self.assertEqual(response["telemetry"]["evaluation"]["raw_status"], "fail")
        self.assertIn(
            "internal_instruction_leak",
            adapter.last_trace["raw_evaluation"]["v22_reason_codes"],
        )
        self.assertEqual(
            adapter.last_trace["raw_semantic_coverage"]["reason_codes"],
            FIXTURE["expected"]["raw_missing_semantics"],
        )

    def test_27_saved_final_pass(self):
        _, _, response = run_saved("v113_final_status")
        self.assertEqual(response["telemetry"]["evaluation"]["final_status"], "pass")
        self.assertEqual(response["evaluation_result"]["reason_codes"], [])

    def test_28_rewrite_ratio_within_gate(self):
        _, _, response = run_saved("v113_ratio")
        self.assertLessEqual(response["repair_result"]["rewrite_ratio"], 0.35)

    def test_29_decision_package_immutable(self):
        _, adapter, response = run_saved("v113_immutable")
        expected = canonical_sha256(response["decision_package"])
        self.assertEqual(response["decision_package_hash"], expected)
        self.assertEqual(set(adapter.last_trace["decision_package_hashes"].values()), {expected})

    def test_30_projection_drift_zero(self):
        _, adapter, response = run_saved("v113_projection")
        self.assertEqual(adapter.last_trace["projection_decision_drift"], [])
        self.assertEqual(
            projection_sha256(adapter.last_trace["verbalization_projection"]),
            canonical_sha256(adapter.last_trace["verbalization_projection"]),
        )

    def test_31_pass_has_no_blocking_reasons(self):
        _, adapter, response = run_saved("v113_blocking")
        self.assertEqual(response["evaluation_result"]["status"], "pass")
        self.assertEqual(response["evaluation_result"]["reason_codes"], [])
        for assessment in adapter.last_trace["final_evaluation"]["required_assessments"]:
            value = adapter.last_trace["final_evaluation"][f"{assessment}_assessment"]
            if value.get("result") == "pass":
                self.assertNotIn("current_command_not_fulfilled", value.get("reason_codes") or [])


class PromptContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        _, cls.adapter, cls.response = run_saved("v113_prompt_contract")
        cls.projection = cls.adapter.last_trace["verbalization_projection"]
        cls.contract = build_model_prompt_contract(cls.projection)

    def test_32_contract_version(self):
        self.assertEqual(self.contract["model_prompt_schema_version"], "1.1")

    def test_33_contract_hash_deterministic(self):
        self.assertEqual(self.contract, build_model_prompt_contract(copy.deepcopy(self.projection)))

    def test_34_contract_hashes_bound(self):
        self.assertEqual(self.contract["projection_hash"], canonical_sha256(self.projection))
        self.assertEqual(
            self.contract["source_decision_package_hash"],
            canonical_sha256(self.response["decision_package"]),
        )

    def test_35_prompt_deterministic_order(self):
        first, _ = build_projection_prompt(self.projection)
        second, _ = build_projection_prompt(copy.deepcopy(self.projection))
        self.assertEqual(first, second)

    def test_36_prompt_has_no_duplicate_question_instruction(self):
        prompt = self.contract["serialized_prompt"]
        self.assertEqual(prompt.count("Заверши ответ ровно этим вопросом:"), 1)

    def test_37_projection_decision_drift_zero(self):
        self.assertEqual(projection_decision_drift(self.projection, self.response["decision_package"]), [])


if __name__ == "__main__":
    unittest.main()
