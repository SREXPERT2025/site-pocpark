from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

from sales_conversation_controller.site_contract_runtime_v1 import (
    OfflineRuntimeAdapterV1,
    apply_mutation_ack_v11,
)
from sales_conversation_controller.site_contract_runtime_v1.executors import StubOutput
from sales_conversation_controller.verbalization_semantics import (
    recommendation_basis_present,
    recommendation_present,
)
from tests.test_runtime_semantic_pipeline_repair import request


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = json.loads(
    (ROOT / "tests/fixtures/live_historical_smoke_recommendation_20260827_raw.json")
    .read_text(encoding="utf-8")
)


class FrozenExecutor:
    executor = "qwen"

    def __init__(self, answer: str) -> None:
        self.answer = answer
        self.calls = 0

    def execute(self, _context):
        self.calls += 1
        return StubOutput(self.answer, 1, "local_high")


def acknowledgement(response: dict) -> dict:
    return {
        "contract_version": response["contract_version"],
        "canonicalization_version": response["canonicalization_version"],
        "request_id": response["request_id"],
        "response_id": response["response_id"],
        "acknowledged_at": "2026-08-27T15:00:00Z",
        "acknowledgements": [
            {
                "mutation_id": item["mutation_id"],
                "status": "applied",
                "reason_code": "applied",
                "entity_version_before": 0,
                "entity_version_after": 1,
                "audit_ref": f"auditref:recommendation{index:016x}",
            }
            for index, item in enumerate(response["state_mutations"], start=1)
        ],
    }


class RecommendationEvaluatorRepairTests(unittest.TestCase):
    def _captured_live_replay(self):
        first_request = request(FIXTURE["context_message"], "recommendation_live_t1")
        first_adapter = OfflineRuntimeAdapterV1()
        first_response = first_adapter.process(first_request)
        self.assertTrue(first_response["success"], first_response)

        second_seed = request(
            FIXTURE["current_message"],
            "recommendation_live_t2",
            history=[
                {
                    "message_id": first_request["payload"]["message_id"],
                    "role": "user",
                    "content": FIXTURE["context_message"],
                    "created_at": "2026-08-27T14:59:58Z",
                },
                {
                    "message_id": first_response["response_id"],
                    "role": "assistant",
                    "content": first_response["answer"],
                    "created_at": "2026-08-27T14:59:59Z",
                },
            ],
        )
        second_request = apply_mutation_ack_v11(
            second_seed,
            first_response,
            acknowledgement(first_response),
            publication_confirmed=True,
        )["next_request"]
        executor = FrozenExecutor(FIXTURE["raw_answer"])
        adapter = OfflineRuntimeAdapterV1(qwen_executor=executor)
        response = adapter.process(second_request)
        self.assertTrue(response["success"], response)
        return executor, adapter, response

    def test_preliminary_recommendation_language_is_semantically_detected(self):
        positive = (
            "Предварительный анализ указывает на распознавание номеров как наиболее "
            "подходящий основной способ для сотрудников, так как трафик высокий.",
            "Распознавание номеров — наиболее подходящий основной способ для объекта.",
            "Предварительно рассматривается карта для постоянных пользователей.",
            "Билеты предварительно рассматриваются как основной вариант для разовых посетителей.",
        )
        for answer in positive:
            with self.subTest(answer=answer):
                self.assertTrue(recommendation_present(answer))
        for answer in (
            "Карты рассматриваются как один из вариантов.",
            "Можно изучить билеты.",
            "Основной вариант пока не выбран: карты и билеты требуют сравнения.",
        ):
            with self.subTest(answer=answer):
                self.assertFalse(recommendation_present(answer))

    def test_captured_live_recommendation_replay_publishes(self):
        self.assertEqual(
            hashlib.sha256(FIXTURE["raw_answer"].encode("utf-8")).hexdigest(),
            "e2c16c9847a5a2dd959765908578d93733209b19374a7d793027f02da7c1d044",
        )
        self.assertTrue(recommendation_present(FIXTURE["raw_answer"]))
        self.assertTrue(recommendation_basis_present(FIXTURE["raw_answer"]))

        executor, adapter, response = self._captured_live_replay()
        trace = adapter.last_trace
        raw = trace["raw_evaluation"]
        command = raw["command_assessment"]
        context = raw["context_assessment"]

        self.assertEqual(executor.calls, 1)
        self.assertTrue(command["recommended_option_present"])
        self.assertTrue(command["recommendation_basis_present"])
        self.assertEqual(command["result"], "pass")
        self.assertEqual(context["result"], "pass")
        self.assertEqual(context["uses_current_turn"], "pass")
        self.assertEqual(
            set(context["covered_entities"]),
            {"option:license_plate", "option:card", "option:ticket"},
        )
        for phantom in (
            "recommendation_missing",
            "recommendation_basis_missing",
            "command_assessment_failed",
            "context_assessment_failed",
        ):
            self.assertNotIn(phantom, raw["violations"])
            self.assertNotIn(phantom, trace["raw_evaluation_reason_codes"])

        answer = response["answer"].casefold()
        self.assertIn("право доступа задаёт гостевая заявка", answer)
        self.assertIn("идентификация на полосе выполняется отдельно", answer)
        self.assertIn("наличие считывателей пока не подтверждено", answer)
        self.assertTrue(response["answer"].endswith(FIXTURE["expected_next_question"]))
        self.assertEqual(response["evaluation_result"]["status"], "pass")
        self.assertEqual(trace["final_evaluation_status"], "pass")
        self.assertTrue(response["success"])
        self.assertNotEqual(response["answer"], "AI_CORE_FINAL_GATE_BLOCKED")
        self.assertEqual(len(response["executor_trace"]["attempts"]), 1)
        mutation_ids = [item["mutation_id"] for item in response["state_mutations"]]
        self.assertEqual(len(mutation_ids), len(set(mutation_ids)))


if __name__ == "__main__":
    unittest.main()
