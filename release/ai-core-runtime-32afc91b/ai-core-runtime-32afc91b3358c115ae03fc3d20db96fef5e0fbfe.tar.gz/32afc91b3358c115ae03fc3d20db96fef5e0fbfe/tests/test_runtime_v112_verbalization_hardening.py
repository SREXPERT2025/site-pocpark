from __future__ import annotations

import copy
import hashlib
import json
import unittest
from pathlib import Path

from sales_conversation_controller.context_integrity_v22 import normalize_pass_assessment_reason_codes
from sales_conversation_controller.decision_package_semantic_coverage import evaluate_semantic_coverage
from sales_conversation_controller.site_contract_runtime_v1 import OfflineRuntimeAdapterV1
from sales_conversation_controller.site_contract_runtime_v1.canonical import (
    CANONICALIZATION_VERSION,
    canonical_sha256,
    sha256,
)
from sales_conversation_controller.site_contract_runtime_v1.executors import StubOutput
from sales_conversation_controller.site_contract_runtime_v1.schema_validation import ContractSchemaValidator
from sales_conversation_controller.verbalization_projection import (
    build_projection_prompt,
    build_verbalization_projection,
    projection_decision_drift,
)
from sales_conversation_controller.verbalization_semantics import recommendation_present
from tests.test_site_contract_runtime_v1 import BASE_FACTS, request_for


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = json.loads((ROOT / "tests/fixtures/real_qwen_probe_a9066e_raw_001.json").read_text(encoding="utf-8"))


class FrozenExecutor:
    def __init__(self, answer: str) -> None:
        self.answer = answer

    def execute(self, context):
        return StubOutput(self.answer, 1, "local_low")


def probe_request(suffix: str) -> dict:
    return request_for({"message": FIXTURE["current_message"], "route": "qwen"}, suffix=suffix)


def baseline_package() -> dict:
    return OfflineRuntimeAdapterV1().process(probe_request("v112_package"))["decision_package"]


class RecommendationSemanticsTests(unittest.TestCase):
    def test_01_recommend(self):
        self.assertTrue(recommendation_present("Рекомендую распознавание номеров."))

    def test_02_propose(self):
        self.assertTrue(recommendation_present("Предлагаю распознавание номеров."))

    def test_03_primary_variant_will_be(self):
        self.assertTrue(recommendation_present("Основным вариантом будет распознавание номеров."))

    def test_04_primary_method_will_be(self):
        self.assertTrue(recommendation_present("Основным способом входа будет распознавание номеров."))

    def test_05_advisable(self):
        self.assertTrue(recommendation_present("Целесообразно использовать распознавание номеров как основной способ."))

    def test_06_object_better(self):
        self.assertTrue(recommendation_present("Для данного объекта лучше распознавание номеров."))

    def test_07_conditional_primary(self):
        self.assertTrue(recommendation_present("Предварительно можно рассматривать распознавание номеров как основной способ."))

    def test_08_negative_rejection(self):
        self.assertFalse(recommendation_present("Не рекомендую карты без проверки считывателя."))

    def test_09_negative_not_selected(self):
        self.assertFalse(recommendation_present("Резервный вариант не выбран: карты остаются кандидатом."))

    def test_10_negative_plain_option(self):
        self.assertFalse(recommendation_present("Карты рассматриваются как один из вариантов."))

    def test_11_negative_unrelated_primary(self):
        self.assertFalse(recommendation_present("Основным вопросом будет состояние системы."))


class SemanticCoverageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.package = baseline_package()
        cls.question = cls.package["next_question"]
        cls.complete = (
            "Для сотрудников и арендаторов основным способом будет распознавание номеров. "
            "Для гостей право доступа задаёт гостевая заявка, а идентификация выполняется по номеру. "
            "Автоматический резерв пока не выбран, потому что инфраструктура считывателей не подтверждена. "
            "Оператор используется только для ручной обработки исключительных ситуаций. "
            "Карты требуют выдачи, возврата и контроля состояния, а билеты — расхода ленты и обслуживания механизма; "
            "значимость зависит от потока и эксплуатации. " + cls.question
        )

    def coverage(self, answer: str):
        return evaluate_semantic_coverage(answer, self.package, user_message=FIXTURE["current_message"])

    def test_12_complete_coverage(self):
        self.assertEqual(self.coverage(self.complete).status, "pass")

    def test_13_missing_authorization(self):
        result = self.coverage(self.complete.replace("Для гостей право доступа задаёт гостевая заявка, а идентификация выполняется по номеру. ", "Для гостей используется номер. "))
        self.assertIn("missing_guest_authorization", result.reason_codes)

    def test_14_missing_assisted_recovery(self):
        result = self.coverage(self.complete.replace("Оператор используется только для ручной обработки исключительных ситуаций. ", ""))
        self.assertIn("missing_assisted_recovery", result.reason_codes)

    def test_15_missing_tradeoff(self):
        answer = self.complete.replace(
            "Карты требуют выдачи, возврата и контроля состояния, а билеты — расхода ленты и обслуживания механизма; значимость зависит от потока и эксплуатации. ",
            "Карты и билеты остаются вариантами. ",
        )
        self.assertIn("missing_required_tradeoff", self.coverage(answer).reason_codes)

    def test_16_missing_question(self):
        self.assertIn("missing_or_wrong_next_question", self.coverage(self.complete.replace(self.question, "")).reason_codes)

    def test_17_wrong_question(self):
        self.assertIn("missing_or_wrong_next_question", self.coverage(self.complete.replace(self.question, "Какие считыватели установлены?")).reason_codes)

    def test_18_missing_fallback_semantics(self):
        answer = self.complete.replace("Автоматический резерв пока не выбран, потому что инфраструктура считывателей не подтверждена. ", "")
        self.assertIn("missing_fallback_semantics", self.coverage(answer).reason_codes)

    def test_19_missing_unknown_conditionality(self):
        answer = self.complete.replace("Автоматический резерв пока не выбран, потому что инфраструктура считывателей не подтверждена. ", "Автоматический резерв пока не выбран. ")
        self.assertIn("missing_unknown_conditionality", self.coverage(answer).reason_codes)


class SavedProbeRegressionTests(unittest.TestCase):
    def run_saved(self):
        request = probe_request("v112_saved_probe")
        adapter = OfflineRuntimeAdapterV1(qwen_executor=FrozenExecutor(FIXTURE["raw_answer"]))
        response = adapter.process(request)
        return adapter, response

    def test_20_fixture_hash(self):
        self.assertEqual(hashlib.sha256(FIXTURE["raw_answer"].encode()).hexdigest(), FIXTURE["raw_answer_sha"])

    def test_21_same_decision_package_hash(self):
        _, response = self.run_saved()
        self.assertEqual(
            response["decision_package_hash"],
            canonical_sha256(response["decision_package"]),
        )

    def test_22_saved_recommendation_passes(self):
        adapter, _ = self.run_saved()
        command = adapter.last_trace["raw_evaluation"]["command_assessment"]
        self.assertTrue(command["recommended_option_present"])
        self.assertEqual(command["result"], "pass")

    def test_23_saved_current_turn_passes(self):
        adapter, _ = self.run_saved()
        context = adapter.last_trace["raw_evaluation"]["context_assessment"]
        self.assertEqual(context["uses_current_turn"], "pass")
        self.assertEqual(context["result"], "pass")

    def test_24_saved_raw_is_review_required(self):
        adapter, response = self.run_saved()
        self.assertEqual(response["telemetry"]["evaluation"]["raw_status"], "review_required")
        self.assertEqual(adapter.last_trace["raw_semantic_coverage"]["reason_codes"], FIXTURE["expected"]["missing_semantics"])

    def test_25_additive_repair_recovers_missing_semantics(self):
        adapter, response = self.run_saved()
        self.assertTrue(response["repair_result"]["applied"])
        self.assertEqual(response["repair_result"]["method"], "deterministic")
        self.assertEqual(adapter.last_trace["final_semantic_coverage"]["status"], "pass")
        self.assertIn(FIXTURE["raw_answer"].split("Парковочная система", 1)[0].strip(), response["answer"])

    def test_26_saved_final_passes(self):
        _, response = self.run_saved()
        self.assertEqual(response["telemetry"]["evaluation"]["final_status"], "pass")
        self.assertEqual(response["evaluation_result"]["reason_codes"], [])

    def test_27_decision_package_immutable(self):
        adapter, response = self.run_saved()
        self.assertEqual(set(adapter.last_trace["decision_package_hashes"].values()), {response["decision_package_hash"]})

    def test_28_repair_does_not_select_fallback(self):
        _, response = self.run_saved()
        answer = response["answer"].casefold()
        self.assertNotRegex(answer, r"резерв(?:ом|ный)?[^.]{0,60}(?:карта|билет|qr|rfid)")

    def test_29_operator_automatic_fallback_is_not_accepted(self):
        bad = FIXTURE["raw_answer"].replace(
            "Карты и билеты рассматриваются как варианты",
            "Автоматический резерв — карта или оператор",
        )
        adapter = OfflineRuntimeAdapterV1(qwen_executor=FrozenExecutor(bad))
        response = adapter.process(probe_request("v112_operator_bad"))
        self.assertNotIn("карта или оператор", response.get("answer", "").casefold())

    def test_30_unconfirmed_reader_promotion_is_removed(self):
        bad = FIXTURE["raw_answer"].replace(
            "Карты и билеты рассматриваются как варианты, но их применение зависит от наличия соответствующих считывателей и инфраструктуры, которые пока не подтверждены.",
            "Автоматическим резервом будет RFID.",
        )
        response = OfflineRuntimeAdapterV1(qwen_executor=FrozenExecutor(bad)).process(probe_request("v112_reader_bad"))
        self.assertNotRegex(response.get("answer", ""), r"(?i)резервом\s+будет\s+RFID")

    def test_31_pass_context_cannot_retain_current_command_not_fulfilled(self):
        adapter, _ = self.run_saved()
        context = adapter.last_trace["raw_evaluation"]["context_assessment"]
        self.assertEqual(context["result"], "pass")
        self.assertNotIn("current_command_not_fulfilled", context["reason_codes"])
        self.assertIn("current_command_not_fulfilled", context["historical_reason_codes"])

    def test_32_pass_assessment_cannot_retain_blocking_reason_code(self):
        normalized = normalize_pass_assessment_reason_codes({
            "result": "pass",
            "reason_codes": ["context_assessment_failed", "non_blocking_observation"],
        })
        self.assertEqual(normalized["reason_codes"], ["non_blocking_observation"])
        self.assertEqual(normalized["historical_reason_codes"], ["context_assessment_failed"])


class ProjectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.package = baseline_package()
        cls.request = probe_request("v112_projection")
        cls.projection = build_verbalization_projection(
            cls.package,
            current_message=cls.request["payload"]["current_message"],
            confirmed_project_facts=cls.request["payload"]["confirmed_project_facts"],
            source_decision_package_hash=canonical_sha256(cls.package),
            canonicalization_version=CANONICALIZATION_VERSION,
        )

    def test_31_source_hash(self):
        self.assertEqual(self.projection["source_decision_package_hash"], sha256(self.package))

    def test_32_projection_has_no_drift(self):
        self.assertEqual(projection_decision_drift(self.projection, self.package), [])

    def test_33_projection_hash_is_deterministic(self):
        second = build_verbalization_projection(
            copy.deepcopy(self.package),
            current_message=self.request["payload"]["current_message"],
            confirmed_project_facts=copy.deepcopy(BASE_FACTS),
            source_decision_package_hash=canonical_sha256(self.package),
            canonicalization_version=CANONICALIZATION_VERSION,
        )
        self.assertEqual(second["projection_hash"], self.projection["projection_hash"])

    def test_34_projection_preserves_segment_semantics(self):
        for segment in ("employees", "tenants", "guests"):
            self.assertEqual(
                self.projection["segment_semantics"][segment]["primary_identifier"],
                self.package["recommended_architecture"]["segments"][segment]["primary_identifier"],
            )

    def test_35_projection_preserves_pending_fallback(self):
        self.assertEqual(self.projection["fallback_status"], "pending_infrastructure_confirmation")

    def test_36_projection_prompt_is_below_estimated_target(self):
        _, metrics = build_projection_prompt(self.projection)
        self.assertLessEqual(metrics["estimated_tokens"], 2500)

    def test_37_projection_omits_internal_ranking_noise(self):
        prompt, _ = build_projection_prompt(self.projection)
        self.assertNotIn("criterion_trace", prompt)
        self.assertNotIn("sensitivity_analysis", prompt)
        self.assertNotIn("normalized_score", prompt)

    def test_38_runtime_exposes_projection_without_drift(self):
        adapter = OfflineRuntimeAdapterV1()
        adapter.process(probe_request("v112_runtime_projection"))
        self.assertEqual(adapter.last_trace["projection_decision_drift"], [])
        self.assertEqual(
            adapter.last_trace["verbalization_projection"]["source_decision_package_hash"],
            adapter.last_trace["decision_package_hash"],
        )

    def test_39_projection_schema_accepts_example(self):
        schema = ROOT / "sales_conversation_controller/site_contract_runtime_v1/schemas/verbalization-projection-v1.schema.json"
        self.assertTrue(ContractSchemaValidator().validate_external(schema, self.projection).valid)


if __name__ == "__main__":
    unittest.main()
