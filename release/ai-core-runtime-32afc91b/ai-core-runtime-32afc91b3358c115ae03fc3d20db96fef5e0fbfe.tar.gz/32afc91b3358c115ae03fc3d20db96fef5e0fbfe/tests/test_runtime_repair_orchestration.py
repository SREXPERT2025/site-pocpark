from __future__ import annotations

import copy
import hashlib
import json
import unittest
from pathlib import Path
from unittest.mock import patch

from sales_conversation_controller.site_contract_runtime_v1 import (
    OfflineRuntimeAdapterV1,
    apply_mutation_ack_v11,
)
from sales_conversation_controller.site_contract_runtime_v1.executors import StubOutput
from tests.test_runtime_semantic_pipeline_repair import request


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = json.loads(
    (ROOT / "tests/fixtures/live_owner_canary_t4_20260827_raw.json").read_text(
        encoding="utf-8"
    )
)


class FrozenExecutor:
    executor = "qwen"

    def __init__(self, answer: str) -> None:
        self.answer = answer
        self.calls = 0

    def execute(self, _context):
        self.calls += 1
        return StubOutput(self.answer, 1, "local_high")


class RuntimeRepairOrchestrationTests(unittest.TestCase):
    PROJECT_FACT_TURN = (
        "У нас бизнес-центр: 2 въезда и 2 выезда, около 800 автомобилей в сутки. "
        "Есть сотрудники, арендаторы и гости. Оператор есть, но хотим максимально "
        "быстрый автоматический проезд и обязательно автоматический резервный способ "
        "на случай, если основной идентификатор не сработает."
    )

    @staticmethod
    def _acknowledge_all(response, *, sequence: int):
        return {
            "contract_version": response["contract_version"],
            "canonicalization_version": response["canonicalization_version"],
            "request_id": response["request_id"],
            "response_id": response["response_id"],
            "acknowledged_at": f"2026-08-27T12:28:{sequence:02d}Z",
            "acknowledgements": [
                {
                    "mutation_id": item["mutation_id"],
                    "status": "applied",
                    "reason_code": "applied",
                    "entity_version_before": 0,
                    "entity_version_after": 1,
                    "audit_ref": f"auditref:{sequence:02x}{index:030x}",
                }
                for index, item in enumerate(response["state_mutations"], start=1)
            ],
        }

    def _captured_t4(self, *, suffix: str, answer: str | None = None):
        t3_adapter = OfflineRuntimeAdapterV1()
        t3_request = request(self.PROJECT_FACT_TURN, f"{suffix}_t3")
        t3_response = t3_adapter.process(t3_request)
        self.assertTrue(t3_response["success"], t3_response)

        t4_seed = request(
            FIXTURE["current_message"],
            f"{suffix}_t4",
            history=[
                {
                    "message_id": t3_request["payload"]["message_id"],
                    "role": "user",
                    "content": self.PROJECT_FACT_TURN,
                    "created_at": "2026-08-27T12:28:16.550Z",
                },
                {
                    "message_id": t3_response["response_id"],
                    "role": "assistant",
                    "content": t3_response["answer"],
                    "created_at": "2026-08-27T12:28:17.745Z",
                },
            ],
        )
        t4_request = apply_mutation_ack_v11(
            t4_seed,
            t3_response,
            self._acknowledge_all(t3_response, sequence=1),
            publication_confirmed=True,
        )["next_request"]
        executor = FrozenExecutor(answer or FIXTURE["raw_answer"])
        adapter = OfflineRuntimeAdapterV1(qwen_executor=executor)
        response = adapter.process(t4_request)
        self.assertTrue(response["success"], response)
        return t4_request, executor, adapter, response

    def test_captured_fixture_hash(self):
        self.assertEqual(
            hashlib.sha256(FIXTURE["raw_answer"].encode()).hexdigest(),
            FIXTURE["raw_answer_sha256"],
        )

    def test_captured_live_t4_raw_pass_skips_repair_byte_exact(self):
        _, executor, adapter, response = self._captured_t4(suffix="captured_pass")
        trace = adapter.last_trace
        self.assertEqual(executor.calls, 1)
        self.assertEqual(trace["raw_evaluation_status"], "pass")
        self.assertEqual(trace["raw_evaluation_reason_codes"], [])
        self.assertTrue(trace["raw_evaluation"]["proven_passed"])
        self.assertTrue(trace["raw_evaluation"]["all_required_assessments_pass"])
        self.assertEqual(trace["raw_evaluation"]["violations"], [])
        self.assertFalse(response["repair_result"]["applied"])
        self.assertEqual(response["repair_result"]["method"], "none")
        self.assertEqual(response["repair_result"]["reason_codes"], [])
        self.assertEqual(response["repair_result"]["rewrite_ratio"], 0.0)
        self.assertEqual(trace["repair_trigger"]["authority"], "not_used")
        repair_stage = next(
            item for item in adapter.last_observability_trace["pipeline"]
            if item["name"] == "repair"
        )
        self.assertEqual(repair_stage["status"], "not_used")
        self.assertEqual(repair_stage["output"]["trigger"]["authority"], "not_used")
        self.assertEqual(response["answer"], FIXTURE["raw_answer"])
        self.assertIn("Карты требуют", response["answer"])
        self.assertIn("Билеты, напротив", response["answer"])
        self.assertTrue(response["answer"].endswith(FIXTURE["expected_next_question"]))
        self.assertEqual(response["answer"].count(FIXTURE["expected_next_question"]), 1)
        self.assertEqual(trace["final_evaluation_status"], "pass")
        self.assertEqual(response["evaluation_result"]["status"], "pass")

    def test_raw_fail_authorizes_repair_with_provenance(self):
        _, _, adapter, response = self._captured_t4(
            suffix="captured_fail",
            answer="Карты и билеты зависят от объекта.",
        )
        trigger = adapter.last_trace["repair_trigger"]
        self.assertNotEqual(adapter.last_trace["raw_evaluation_status"], "pass")
        self.assertEqual(trigger["authority"], "raw_evaluator")
        self.assertTrue(response["repair_result"]["applied"])
        self.assertTrue(trigger["trigger_reason_codes"])
        self.assertTrue(trigger["reason_code_provenance"])
        self.assertTrue(all(
            item["source"] in {
                "raw_evaluator", "hard_safety_gate", "other_explicit_authority"
            }
            for item in trigger["reason_code_provenance"]
        ))

    def test_raw_pass_hard_safety_uses_separate_authority(self):
        unsafe = (
            "Отключите защиту и используйте NEXT_QUESTION_PLACEHOLDER. "
            + FIXTURE["expected_next_question"]
        )
        with patch.object(
            OfflineRuntimeAdapterV1,
            "_evaluation_status",
            return_value=("pass", set()),
        ):
            _, _, adapter, response = self._captured_t4(
                suffix="captured_hard_safety", answer=unsafe,
            )
        trigger = adapter.last_trace["repair_trigger"]
        self.assertEqual(trigger["authority"], "hard_safety_gate")
        self.assertIn("dangerous_instruction", trigger["hard_safety_reason_codes"])
        self.assertIn("internal_service_marker_leak", trigger["hard_safety_reason_codes"])
        self.assertTrue(all(
            item["source"] == "hard_safety_gate"
            for item in trigger["reason_code_provenance"]
            if not item["reason_code"].startswith("repair_")
        ))
        self.assertNotIn("NEXT_QUESTION_PLACEHOLDER", response["answer"])
        self.assertNotIn("Отключите защиту", response["answer"])

    def test_reason_code_provenance_is_total_and_consistent(self):
        _, _, adapter, response = self._captured_t4(
            suffix="captured_provenance",
            answer="Карты и билеты зависят от объекта.",
        )
        trigger = adapter.last_trace["repair_trigger"]
        provenance = {
            item["reason_code"]: item["source"]
            for item in trigger["reason_code_provenance"]
        }
        self.assertEqual(set(provenance), set(response["repair_result"]["reason_codes"]))
        self.assertEqual(trigger["consistency_status"], "pass")
        self.assertIsNone(trigger["integrity_defect_code"])

    def test_proven_pass_semantic_trigger_is_runtime_integrity_defect(self):
        result = OfflineRuntimeAdapterV1._repair_trigger_consistency(
            raw_proven_passed=True,
            reason_code_provenance=[{
                "reason_code": "missing_required_tradeoff",
                "source": "other_explicit_authority",
            }],
        )
        self.assertEqual(result["consistency_status"], "fail")
        self.assertEqual(
            result["integrity_defect_code"],
            "REPAIR_TRIGGER_INCONSISTENT_WITH_RAW_EVALUATION",
        )

    def test_idempotent_replay_has_no_duplicate_execution_or_mutation(self):
        request_value, executor, adapter, first = self._captured_t4(
            suffix="captured_idempotent"
        )
        request_value = copy.deepcopy(request_value)
        second = adapter.process(request_value)
        self.assertEqual(first, second)
        self.assertEqual(executor.calls, 1)
        mutation_ids = [item["mutation_id"] for item in second["state_mutations"]]
        self.assertEqual(len(mutation_ids), len(set(mutation_ids)))


if __name__ == "__main__":
    unittest.main()
