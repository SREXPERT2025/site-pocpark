from __future__ import annotations

import re


RECOMMENDATION_OPTION_RE = re.compile(
    r"\b(?:распознаван\w*\s+(?:государственн\w*\s+)?номер\w*|госномер\w*|"
    r"номер\w*|карт\w*|билет\w*|qr|rfid|радиомет\w*)\b",
    re.I,
)


def recommendation_present(text: str) -> bool:
    """Распознаёт выбор варианта по смыслу, не привязываясь к одной фразе."""
    for sentence in re.split(r"(?<=[.!?])\s+|\n+", str(text or "")):
        clean = normalize(sentence)
        if not clean or not RECOMMENDATION_OPTION_RE.search(clean):
            continue
        if re.search(r"\b(?:не\s+рекоменду\w*|не\s+предлага\w*|вариант\w*\s+не\s+выбран\w*)\b", clean):
            continue
        if re.search(r"\b(?:рекоменду\w*|предлага\w*)\b", clean):
            return True
        if re.search(r"\bцелесообразно\s+использовать\b", clean):
            return True
        if re.search(
            r"\b(?:мы\s+)?выбра\w*\b.{0,120}\bкак\s+основн\w+\s+"
            r"(?:вариант|способ|решение|идентификатор)\w*\b",
            clean,
        ):
            return True
        if re.search(
            r"\b(?:основн\w+\s+(?:вариант|способ|решение|идентификатор)\w*)\b.{0,90}"
            r"\b(?:будет|явля\w*|служит|выступа\w*|можно\s+(?:использовать|рассматривать|выбрать))\b",
            clean,
        ):
            return True
        if re.search(r"\bосновн\w+\s+(?:вариант|способ|решение|идентификатор)\w*\s*[—:-]", clean):
            return True
        if re.search(
            r"\b(?:можно\s+рассматривать|целесообразно\s+использовать)\b.{0,100}"
            r"\b(?:как\s+)?основн\w+\s+(?:вариант|способ|идентификатор)\w*\b",
            clean,
        ):
            return True
        if re.search(r"\bдля\s+(?:данн\w+\s+)?объект\w*\b.{0,80}\bлучше\b", clean):
            return True
        if re.search(r"\b(?:лучше\s+использовать|предпочтител\w*)\b", clean):
            return True
        if re.search(
            r"\b(?:предварительн\w+\s+(?:анализ|оценк|вывод)\w*\s+"
            r"(?:указывает|показывает|вед[её]т)\s+на\s+)?"
            r"(?:распознаван\w*\s+(?:государственн\w*\s+)?номер\w*|госномер\w*|"
            r"номер\w*|карт\w*|билет\w*|qr|rfid|радиомет\w*)"
            r".{0,100}\bнаиболее\s+подходящ\w*\s+основн\w+\s+"
            r"(?:вариант|способ|решение|идентификатор)\w*\b",
            clean,
        ):
            return True
        if re.search(
            r"\bпредварительно\s+рассматрива\w*\s+"
            r"(?:распознаван\w*\s+(?:государственн\w*\s+)?номер\w*|госномер\w*|"
            r"номер\w*|карт\w*|билет\w*|qr|rfid|радиомет\w*)\b",
            clean,
        ) and not re.search(r"\bкак\s+(?:один|одна|одно)\s+из\s+вариант\w*\b", clean):
            return True
        if re.search(
            r"\b(?:распознаван\w*\s+(?:государственн\w*\s+)?номер\w*|госномер\w*|"
            r"номер\w*|карт\w*|билет\w*|qr|rfid|радиомет\w*)"
            r".{0,70}\bпредварительно\s+рассматрива\w*\b.{0,70}"
            r"\bкак\s+основн\w+\s+(?:вариант|способ|решение|идентификатор)\w*\b",
            clean,
        ):
            return True
    return False


def recommendation_basis_present(text: str) -> bool:
    """Ищет явное основание рядом с рекомендацией, не подменяя сам выбор."""
    sentences = [
        normalize(part)
        for part in re.split(r"(?<=[.!?])\s+|\n+", str(text or ""))
        if normalize(part)
    ]
    explicit_basis = re.compile(
        r"\b(?:потому\s+что|поскольку|так\s+как|с\s+учетом|исходя\s+из|"
        r"при\s+заданн\w*|для\s+объект\w*\s+с|за\s+сч[её]т)\b",
        re.I,
    )
    factual_basis = re.compile(
        r"\b(?:бизнес[- ]центр\w*|тип\w*\s+объект\w*|приоритет\w*\s+скорост\w*|"
        r"скорост\w*|поток\w*|трафик\w*|\d+\s+(?:машин|автомобил)\w*\s+в\s+день|"
        r"для\s+сотрудник\w*|для\s+арендатор\w*|сниж\w*\s+нагрузк\w*|"
        r"бесконтактн\w*\s+поток\w*)\b",
        re.I,
    )
    for index, sentence in enumerate(sentences):
        if not recommendation_present(sentence):
            continue
        neighborhood = " ".join(sentences[max(0, index - 1):index + 1])
        if explicit_basis.search(neighborhood) or factual_basis.search(neighborhood):
            return True
    return False


def normalize(text: str) -> str:
    return " ".join(str(text or "").casefold().replace("ё", "е").split())


def explicitly_rejects_candidate_promotion(sentence: str) -> bool:
    """Отрицание выбора не должно считаться рекомендацией кандидата."""
    clean = normalize(sentence)
    return bool(re.search(
        r"(?:"
        r"(?:автоматическ\w*\s+)?резерв\w*(?:\s+метод)?\s+не\s+выбран|"
        r"не\s+выбран[^.!?]{0,35}резерв|"
        r"кандидат\w*[^.!?]{0,55}не\s+рекоменду|"
        r"не\s+рекоменду\w*[^.!?]{0,55}кандидат|"
        r"наличи\w*[^.!?]{0,80}не\s+подтвержден"
        r")",
        clean,
        re.I,
    ))


def is_candidate_recommendation_context(sentence: str) -> bool:
    clean = normalize(sentence)
    if explicitly_rejects_candidate_promotion(clean):
        return False
    return bool(re.search(
        r"\b(?:резерв\w*|рекоменду\w*|автоматическ\w+\s+(?:способ|идентификатор))\b",
        clean,
        re.I,
    ))


def operator_presented_as_automatic_fallback(text: str) -> bool:
    for sentence in re.split(r"(?<=[.!?])\s+|\n+", str(text or "")):
        clean = normalize(sentence)
        if "оператор" not in clean or "резерв" not in clean:
            continue
        if re.search(r"не\s+явля\w*[^.!?]{0,45}(?:автоматическ\w*\s+)?резерв", clean, re.I):
            continue
        if re.search(r"оператор\w*[^.!?]{0,65}(?:только\s+для|исключительн|ручн\w*\s+обработ)", clean, re.I):
            continue
        return True
    return False


def operator_exception_only_preserved(text: str) -> bool:
    clean = normalize(text)
    if operator_presented_as_automatic_fallback(clean):
        return False
    return bool(
        re.search(r"(?:исключительн|в\s+случае\s+сбо)[^.!?]{0,110}оператор", clean, re.I)
        or re.search(r"оператор[^.!?]{0,110}(?:исключительн|ручн\w*\s+обработ|не\s+явля\w*[^.!?]{0,35}резерв)", clean, re.I)
    )
