from __future__ import annotations

import math
import re
from dataclasses import dataclass, fields, replace
from typing import Any

from .context_integrity_v21 import (
    ContextIntentIntegrityLayerV21,
    FinalIntegrityResultV21,
    IntegrityResolution,
    IntegrityState,
)
from .decision_package_semantic_coverage import evaluate_semantic_coverage
from .verbalization_semantics import (
    is_candidate_recommendation_context,
    recommendation_basis_present,
    recommendation_present,
)
from .non_engineering_evaluation import (
    BUSINESS_OPENER_ACTION,
    CONVERSATIONAL_COURTESY_ACTION,
    assess_conversational_courtesy,
    classify_business_opener,
    classify_conversational_courtesy,
)
from .verbalization_projection import internal_instruction_leaks


ACTION_TYPES = {
    "answer_question", "execute_command", "remember_fact", "recall_facts",
    "provide_source", "provide_link", "compare_options", "recommend_solution",
    "ask_one_question", "change_topic", "utility_request", "clarify_conflict",
    "propose_next_step", "provide_contact", "conversation_summary", "memory_conflict_resolution",
    CONVERSATIONAL_COURTESY_ACTION,
    BUSINESS_OPENER_ACTION,
}

V22_REASON_CODES = {
    "insufficient_context_for_manual_review", "dataset_context_export_defect",
    "current_turn_ignored", "command_type_misclassified",
    "client_fact_misclassified_as_company_fact", "source_request_not_fulfilled",
    "summary_does_not_cover_conversation", "memory_conflict_handled_correctly",
    "corporate_practice_not_verified", "corporate_practice_contradicted",
    "repair_converted_bad_to_good", "client_fact_preserved_correctly",
    "manual_recovery_misclassified_as_fallback_identifier",
    "fallback_not_segment_specific", "fallback_requires_unconfirmed_reader",
    "universal_operational_claim", "mixed_tradeoff_categories",
    "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
    "authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated",
    "missing_primary_identifier", "missing_required_segments", "missing_guest_authorization",
    "missing_assisted_recovery", "missing_fallback_semantics", "missing_required_tradeoff",
    "missing_unknown_conditionality", "missing_or_wrong_next_question",
    "operator_as_automated_fallback", "required_technical_knowledge_missing",
    "fallback_scenario_not_resolved", "unsupported_lane_guidance_claim",
    "courtesy_turn_not_acknowledged", "unsupported_non_engineering_claim",
    "confirmed_context_contradicted", "unrequested_engineering_decision",
    "unsafe_non_engineering_content", "courtesy_pressure_pattern",
    "courtesy_question_limit_exceeded", "courtesy_response_incomplete",
    "internal_instruction_leak",
}

PASS_INCOMPATIBLE_REASON_CODES = {
    "command_assessment_failed", "context_assessment_failed", "topic_assessment_failed",
    "fact_assessment_failed", "question_assessment_failed", "link_assessment_failed",
    "source_assessment_failed", "current_command_not_fulfilled", "current_turn_ignored",
    "recommendation_missing", "recommendation_basis_missing", "conditionality_not_handled",
    "source_request_not_fulfilled", "summary_does_not_cover_conversation",
}


def normalize_pass_assessment_reason_codes(assessment: dict[str, Any]) -> dict[str, Any]:
    """Не оставляет активную блокирующую причину у уже прошедшей проверки."""
    normalized = dict(assessment)
    active = list(dict.fromkeys(normalized.get("reason_codes") or []))
    if normalized.get("result") != "pass":
        normalized["reason_codes"] = active
        return normalized
    stale = [code for code in active if code in PASS_INCOMPATIBLE_REASON_CODES]
    normalized["reason_codes"] = [code for code in active if code not in PASS_INCOMPATIBLE_REASON_CODES]
    if stale:
        normalized["historical_reason_codes"] = list(dict.fromkeys((
            *(normalized.get("historical_reason_codes") or []), *stale,
        )))
    return normalized

EVALUATOR_PRIORITY_ORDER = (
    "context_completeness", "action_type", "current_turn", "explicit_command",
    "topic", "memory", "state_conflict", "facts", "fallback", "client_acceptability",
)

FACET_PATTERNS = {
    "object": r"\b(?:бизнес-центр|торговый центр|жилой комплекс|склад|объект)\b",
    "entrances": r"\b(?:въезд|въезда|въездов)\b",
    "exits": r"\b(?:выезд|выезда|выездов)\b",
    "traffic": r"\b(?:автомобил\w*\s+в\s+день|суточн\w+\s+поток|поток)\b",
    "identification": r"\b(?:госномер|распознаван\w+\s+номер|карт|билет|qr|радиомет)\w*\b",
    "guest_access": r"\b(?:гост|гостев)\w*\b",
    "payment": r"\b(?:оплат|рубл|тариф)\w*\b",
    "fallback": r"\b(?:резерв|не\s+распозна|оператор|ручн)\w*\b",
    "resilience": r"\b(?:питан|связ|интернет|бесперебойн)\w*\b",
}


@dataclass(frozen=True)
class FinalIntegrityResultV22(FinalIntegrityResultV21):
    action_type: str = "answer_question"
    context_complete: bool = True
    eligible_for_evaluator_metrics: bool = True
    v22_reason_codes: tuple[str, ...] = ()
    evaluator_priority_order: tuple[str, ...] = EVALUATOR_PRIORITY_ORDER

    def to_dict(self) -> dict[str, Any]:
        payload = super().to_dict()
        payload.update({
            "action_type": self.action_type,
            "context_complete": self.context_complete,
            "eligible_for_evaluator_metrics": self.eligible_for_evaluator_metrics,
            "v22_reason_codes": list(self.v22_reason_codes),
            "evaluator_priority_order": list(self.evaluator_priority_order),
        })
        return payload


class ContextIntentIntegrityLayerV22(ContextIntentIntegrityLayerV21):
    VERSION = "2.2"

    @staticmethod
    def repair_business_lift(raw_rating: str, final_rating: str) -> bool:
        """Возвращает только наблюдаемый переход, без домысливания оценки."""
        return raw_rating in {"bad", "controversial"} and final_rating == "good"

    def process(
        self, *, conversation_id: str, message_id: str, raw_text: str,
        state: IntegrityState, recent_messages: list[dict[str, str]] | None = None,
        timestamp: str | None = None,
    ) -> IntegrityResolution:
        history = list(recent_messages or [])
        resolution = super().process(
            conversation_id=conversation_id, message_id=message_id, raw_text=raw_text,
            state=state, recent_messages=history, timestamp=timestamp,
        )
        action_type = self.classify_action(raw_text, resolution, state)
        context_complete = self.manual_context_complete(raw_text, action_type, history)
        requirements = dict(resolution.command_requirements)
        requirements.update({
            "action_type": action_type,
            "manual_context_complete": context_complete,
            "conversation_facets": self.conversation_facets(history),
        })
        return replace(resolution, version=self.VERSION, command_requirements=requirements)

    @staticmethod
    def classify_action(text: str, resolution: IntegrityResolution, state: IntegrityState | None = None) -> str:
        lower = " ".join(text.lower().split())
        if classify_conversational_courtesy(lower):
            return CONVERSATIONAL_COURTESY_ACTION
        if classify_business_opener(lower):
            return BUSINESS_OPENER_ACTION
        if re.search(r"\b(?:зафиксируй|запомни|сохрани)\b", lower):
            return "remember_fact"
        if re.search(
            r"\b(?:вспомни|вспоминай|я\s+уже\s+говорил|что\s+я\s+говорил|"
            r"какие\s+данные\s+(?:об|про)\s+объект|"
            r"что\s+(?:ты\s+)?уже\s+запомнил\w*\s+(?:об|про)\s+объект|"
            r"покажи\s+(?:мне\s+)?карточк\w*\s+объект|"
            r"что\s+мы\s+уже\s+выяснили)\b",
            lower,
        ):
            if state and state.conflicts:
                return "memory_conflict_resolution"
            return "recall_facts"
        if re.search(r"\b(?:дай|пришли|покажи)\w*\s+(?:мне\s+)?ссылк\w*", lower):
            return "provide_link"
        if re.search(r"\bгде\b.*(?:прочит|напис|опис|источник|документ)|\bв\s+каком\s+документе\b|\b(?:источник|документаци)\w*\b", lower):
            return "provide_source"
        if re.search(r"\b(?:сформулируй|подведи|дай)\w*.*\b(?:итог|рекомендаци)\w*.*\b(?:бесед|диалог|истори)\w*", lower):
            return "conversation_summary"
        if re.search(r"\b(?:как\s+связаться|контакт(?:ы|ами)?|телефон\s+роспарк)\b", lower):
            return "provide_contact"
        if resolution.command == "compare_options":
            return "compare_options"
        if resolution.command == "recommend":
            return "recommend_solution"
        if resolution.command == "ask_one_question":
            return "ask_one_question"
        if resolution.intent == "simple_utility_question":
            return "utility_request"
        if resolution.command == "handoff":
            return "propose_next_step"
        if re.search(r"\b(?:уточни|разреши)\w*.*\b(?:противореч|конфликт)\w*", lower):
            return "clarify_conflict"
        if re.search(r"\b(?:сменим|другая)\s+тем", lower):
            return "change_topic"
        if resolution.command not in {"answer_directly", "explain", "be_brief"}:
            return "execute_command"
        return "answer_question"

    @staticmethod
    def manual_context_complete(text: str, action_type: str, history: list[dict[str, str]]) -> bool:
        lower = " ".join(text.lower().split())
        deictic = bool(re.search(r"\b(?:это|этом|этого|про\s+это|таком|такой)\b", lower))
        if action_type in {"provide_source", "provide_link"} and deictic:
            meaningful = [item for item in history if str(item.get("content") or "").strip()]
            return bool(meaningful)
        return True

    @staticmethod
    def conversation_facets(history: list[dict[str, str]]) -> list[str]:
        content = " ".join(str(item.get("content") or "") for item in history).lower()
        return [name for name, pattern in FACET_PATTERNS.items() if re.search(pattern, content)]

    @staticmethod
    def _answer_facets(answer: str) -> list[str]:
        return [name for name, pattern in FACET_PATTERNS.items() if re.search(pattern, answer)]

    def _assess_facts(
        self, answer: str, resolution: IntegrityResolution, state: IntegrityState,
    ) -> tuple[dict[str, Any], list[str], list[str]]:
        fact, claim_types, numeric_claims = super()._assess_facts(answer, resolution, state)
        action_type = str(resolution.command_requirements.get("action_type") or "")
        if action_type == "remember_fact":
            required_values: list[str] = []
            for key, value in resolution.extracted_facts.items():
                if key.endswith("__fact_type"):
                    continue
                raw = value.get("value") if isinstance(value, dict) else value
                if isinstance(raw, float) and raw.is_integer():
                    raw = int(raw)
                required_values.append(str(raw).lower())
            normalized_answer = answer.lower().replace(" ", " ")
            preserved = all(value in normalized_answer for value in required_values)
            payment_condition_required = bool(re.search(r"после\s+подтверждени\w+\s+оплат", resolution.ingestion.normalized_text))
            payment_condition_present = bool(re.search(r"после\s+подтверждени\w+\s+оплат", normalized_answer))
            if payment_condition_required:
                preserved = preserved and payment_condition_present
            fact = dict(fact)
            fact.update({
                "result": "pass" if preserved else "fail",
                "claim_types": ["client_supplied_fact"],
                "numeric_claims": numeric_claims,
                "client_fact_source_message_id": resolution.ingestion.message_id,
                "client_fact_preserved": preserved,
            })
            claim_types = ["client_supplied_fact"]
        return fact, claim_types, numeric_claims

    def _required_for_action(self, action_type: str, resolution: IntegrityResolution) -> tuple[str, ...]:
        mapping = {
            "remember_fact": ("command", "fact", "context"),
            "recall_facts": ("command", "fact", "context"),
            "memory_conflict_resolution": ("command", "fact", "context"),
            "provide_source": ("command", "source", "context"),
            "provide_link": ("command", "link", "source", "context"),
            "conversation_summary": ("command", "context"),
            "utility_request": ("topic", "command", "context"),
            "ask_one_question": ("command", "question", "context"),
            "compare_options": ("topic", "command", "source", "context"),
            "recommend_solution": ("topic", "command", "context"),
            "propose_next_step": ("topic", "command", "context"),
            "provide_contact": ("topic", "command", "context"),
            CONVERSATIONAL_COURTESY_ACTION: ("command", "context"),
            BUSINESS_OPENER_ACTION: ("command", "context"),
        }
        return mapping.get(action_type, super().required_assessments_for(resolution, "", []))

    @staticmethod
    def _source_request_evidence(answer: str) -> bool:
        return bool(re.search(
            r"(?:https?://\S+|/[-\w./]+|\b(?:документ|инструкци|руководств|раздел)\w*\s+[«\"A-Za-zА-Яа-я0-9]|"
            r"\b(?:могу|можем)\s+(?:прислать|отправить)\s+(?:ссылк|источник|документ))",
            answer, re.I,
        ))

    def final_check(
        self, answer: str, resolution: IntegrityResolution, state: IntegrityState,
        knowledge_package: Any | None = None,
    ) -> FinalIntegrityResultV22:
        parent = super().final_check(answer, resolution, state, knowledge_package)
        action_type = str(resolution.command_requirements.get("action_type") or "answer_question")
        context_complete = bool(resolution.command_requirements.get("manual_context_complete", True))
        topic = dict(parent.topic_assessment)
        command = dict(parent.command_assessment)
        fact = dict(parent.fact_assessment)
        question = dict(parent.question_assessment)
        link = dict(parent.link_assessment)
        source = dict(parent.source_assessment)
        context = dict(parent.context_assessment)
        reasons: list[str] = []
        corrected_false_violations: set[str] = set()

        if not context_complete:
            context.update(result="unknown", reason_codes=["insufficient_context_for_manual_review"])
            reasons.extend(("insufficient_context_for_manual_review", "dataset_context_export_defect"))
        else:
            clean = " ".join(str(answer or "").lower().split())
            if action_type in {CONVERSATIONAL_COURTESY_ACTION, BUSINESS_OPENER_ACTION}:
                turn_type = (
                    "business_opener" if action_type == BUSINESS_OPENER_ACTION
                    else classify_conversational_courtesy(resolution.resolved_text) or "small_talk"
                )
                courtesy = assess_conversational_courtesy(
                    answer,
                    turn_type=turn_type,
                    contradiction_detected=bool(fact.get("contradictions")),
                )
                result = courtesy.status
                command.update(
                    result=result,
                    reason="conversational_courtesy_policy_checked",
                    missing_requirements=list(courtesy.reason_codes),
                    evidence=courtesy.to_dict(),
                )
                context.update(
                    result=result,
                    uses_current_turn="pass" if courtesy.current_turn_acknowledged else "fail",
                    uses_required_context="not_applicable",
                    reason="conversational_courtesy_relevance_checked",
                    reason_codes=[],
                )
                topic.update(result="not_applicable", reason="engineering_topic_not_required")
                reasons.extend(courtesy.reason_codes)
                corrected_false_violations.update({
                    "command_assessment_failed", "context_assessment_failed",
                    "current_command_not_fulfilled", "current_turn_ignored",
                    "recommendation_missing", "recommendation_basis_missing",
                    "conditionality_not_handled",
                })
            elif action_type == "remember_fact":
                command["result"] = "pass" if fact.get("result") == "pass" else "fail"
                command["reason"] = "client_fact_preservation_checked"
                source.update(result="not_applicable", reason="client_fact_does_not_require_company_source")
                context.update(result="pass", uses_current_turn="pass")
                if fact.get("result") == "pass":
                    reasons.append("client_fact_preserved_correctly")
                elif parent.fact_assessment.get("result") == "fail":
                    reasons.append("client_fact_misclassified_as_company_fact")
            elif action_type in {"recall_facts", "memory_conflict_resolution"}:
                recalled = sum(
                    bool(re.search(rf"\b{re.escape(str(int(value.get('value')) if isinstance(value.get('value'), float) and value.get('value').is_integer() else value.get('value')))}\b", clean))
                    for value in state.confirmed_facts.values() if value.get("value") is not None
                )
                conflict_handled = not state.conflicts or bool(re.search(r"\b(?:противореч|уточн|ранее.*позже|отдельно\s+нужно)\w*", clean))
                result = "pass" if recalled >= 2 and conflict_handled else "fail"
                command.update(result=result, reason="memory_recall_and_conflict_checked", recalled_fact_count=recalled)
                fact.update(result=result, memory_conflict_handled=conflict_handled)
                context.update(result="pass", uses_current_turn="pass")
                if result == "pass" and state.conflicts:
                    reasons.append("memory_conflict_handled_correctly")
            elif action_type in {"provide_source", "provide_link"}:
                fulfilled = self._source_request_evidence(answer)
                result = "pass" if fulfilled else "fail"
                command.update(result=result, reason="source_artifact_checked")
                source.update(result=result, reason="source_artifact_present" if fulfilled else "source_request_not_fulfilled")
                if action_type == "provide_link":
                    link["result"] = result
                context.update(result="pass", uses_current_turn="pass")
                if not fulfilled:
                    reasons.append("source_request_not_fulfilled")
            elif action_type == "conversation_summary":
                expected = list(resolution.command_requirements.get("conversation_facets") or [])
                covered = self._answer_facets(clean)
                minimum = min(len(expected), max(3, math.ceil(len(expected) * .6))) if expected else 1
                result = "pass" if len(set(expected) & set(covered)) >= minimum else "fail"
                command.update(
                    result=result, reason="conversation_summary_coverage_checked",
                    expected_facets=expected, covered_facets=covered, minimum_required=minimum,
                )
                context.update(result="pass", uses_current_turn="pass")
                if result == "fail":
                    reasons.append("summary_does_not_cover_conversation")
            elif action_type == "recommend_solution":
                option_patterns = {
                    "license_plate": r"номер", "card": r"карт", "ticket": r"билет",
                    "qr": r"\bqr\b", "radio_tag": r"радиомет|\brfid\b",
                }
                covered_options = {
                    name for name, pattern in option_patterns.items() if re.search(pattern, clean, re.I)
                }
                recommendation_detected = recommendation_present(clean)
                recommendation_basis_detected = recommendation_basis_present(clean)
                conditionality_handled = bool(re.search(
                    r"\b(?:в\s+зависимости\s+от|зависит\s+от|при\s+условии|если|может\s+формироваться|"
                    r"предварительно|нужно\s+подтвердить|после\s+(?:подтверждения|проверки)|"
                    r"до\s+подтверждения|не\s+подтвержден\w*|не\s+выбран)\b",
                    clean, re.I,
                ))
                required_options = {
                    name for name, pattern in option_patterns.items()
                    if re.search(pattern, resolution.resolved_text, re.I)
                }
                current_turn_used = (
                    required_options <= covered_options
                    if required_options
                    else recommendation_detected and recommendation_basis_detected
                )
                command_evidence = dict(command.get("evidence") or {})
                command_evidence.update(
                    recommended_option_present=recommendation_detected,
                    recommendation_basis_present=recommendation_basis_detected,
                    conditionality_handled=conditionality_handled,
                )
                command.update(
                    result="pass" if recommendation_detected and recommendation_basis_detected else "fail",
                    reason="semantic_recommendation_structure_checked",
                    recommended_option_present=recommendation_detected,
                    recommendation_basis_present=recommendation_basis_detected,
                    conditionality_handled=conditionality_handled,
                    evidence=command_evidence,
                    missing_requirements=[
                        name for name, present in (
                            ("recommendation_missing", recommendation_detected),
                            ("recommendation_basis_missing", recommendation_basis_detected),
                        ) if not present
                    ],
                )
                if current_turn_used:
                    context.update(
                        result="pass",
                        uses_current_turn="pass",
                        covered_entities=sorted(set(context.get("covered_entities") or ()) | {
                            f"option:{name}" for name in covered_options
                        }),
                    )
                    if topic.get("result") in {"unknown", "not_applicable"}:
                        topic.update(
                            result="pass",
                            reason="recommendation_command_and_basis_match_current_turn",
                        )
                if command.get("result") == "pass" and current_turn_used:
                    corrected_false_violations.update({
                        "command_assessment_failed", "context_assessment_failed",
                        "recommendation_missing", "recommendation_basis_missing",
                        "current_command_not_fulfilled", "conditionality_not_handled",
                    })
            if action_type == "provide_contact":
                channel_count = sum(word in clean for word in ("форм", "телефон", "почт", "контакт"))
                if channel_count >= 2:
                    topic.update(result="pass", reason="contact_navigation_answered")
                    command.update(result="pass", reason="contact_channels_provided")
                    context.update(result="pass", uses_current_turn="pass")
            if action_type == "utility_request" and context.get("result") == "fail":
                reasons.append("current_turn_ignored")
            if source.get("result") == "fail" and parent.fact_assessment.get("numeric_claims"):
                reasons.append("corporate_practice_contradicted")
            elif source.get("result") == "unknown" and parent.fact_assessment.get("numeric_claims"):
                reasons.append("corporate_practice_not_verified")

        assessments = {
            "topic": normalize_pass_assessment_reason_codes(topic),
            "command": normalize_pass_assessment_reason_codes(command),
            "fact": normalize_pass_assessment_reason_codes(fact),
            "question": normalize_pass_assessment_reason_codes(question),
            "link": normalize_pass_assessment_reason_codes(link),
            "source": normalize_pass_assessment_reason_codes(source),
            "context": normalize_pass_assessment_reason_codes(context),
        }
        topic, command, fact, question, link, source, context = (
            assessments[name] for name in ("topic", "command", "fact", "question", "link", "source", "context")
        )
        required = self._required_for_action(action_type, resolution)
        if "corporate_practice_contradicted" in reasons or "corporate_practice_not_verified" in reasons:
            required = tuple(dict.fromkeys((*required, "source")))
        engineering_package = (
            knowledge_package
            if isinstance(knowledge_package, dict)
            and knowledge_package.get("decision_type") != "not_required"
            else None
        )
        coverage = evaluate_semantic_coverage(
            answer,
            engineering_package,
            user_message=resolution.resolved_text,
        )
        command["semantic_coverage"] = coverage.to_dict()
        semantic_review_reasons = list(dict.fromkeys((
            *(
                self._engineering_semantic_reasons(answer, engineering_package)
                if engineering_package is not None else ()
            ),
            *coverage.reason_codes,
        )))
        reasons.extend(semantic_review_reasons)
        if not context_complete:
            status = "insufficient_evidence"
            unknown = tuple(required)
            failures: tuple[str, ...] = ()
        else:
            unknown = tuple(name for name in required if assessments[name].get("result") in {"unknown", "not_applicable"})
            failures = tuple(name for name in required if assessments[name].get("result") == "fail")
            status = "fail" if failures else "insufficient_evidence" if unknown else "review_required" if semantic_review_reasons else "pass"
        passed_assessment_failures = {
            f"{name}_assessment_failed"
            for name, assessment in assessments.items()
            if assessment.get("result") == "pass"
        }
        violations = [
            item for item in parent.violations
            if item not in corrected_false_violations
            and item not in passed_assessment_failures
        ]
        violations.extend(f"{name}_assessment_failed" for name in failures)
        instruction_leaks = internal_instruction_leaks(answer)
        if instruction_leaks:
            status = "fail"
            violations.append("internal_instruction_leak")
            reasons.append("internal_instruction_leak")
        base_values = {item.name: getattr(parent, item.name) for item in fields(FinalIntegrityResultV21)}
        base_values.update({
            "topic_assessment": topic, "command_assessment": command,
            "fact_assessment": fact, "question_assessment": question,
            "link_assessment": link, "source_assessment": source,
            "context_assessment": context,
            "violations": tuple(dict.fromkeys(violations)),
            "evaluation_status": status,
            "no_proven_failure": not failures and not instruction_leaks,
            "all_required_assessments_pass": status == "pass",
            "required_assessments": required, "unknown_required_assessments": unknown,
        })
        return FinalIntegrityResultV22(
            **base_values, action_type=action_type, context_complete=context_complete,
            eligible_for_evaluator_metrics=context_complete,
            v22_reason_codes=tuple(dict.fromkeys(reason for reason in reasons if reason in V22_REASON_CODES)),
        )

    @staticmethod
    def _engineering_semantic_reasons(answer: str, knowledge_package: Any | None) -> list[str]:
        clean = " ".join(str(answer or "").casefold().split())
        reasons: list[str] = []
        package = knowledge_package if isinstance(knowledge_package, dict) else {}
        if package.get("decision_status") == "comparison_only":
            if (
                re.search(r"\b(?:распознаван\w*\s+номер|госномер|lpr)\b", clean, re.I)
                and recommendation_present(clean)
            ):
                reasons.append("unrequested_engineering_decision")
            return reasons
        if package.get("decision_status") == "fallback_decision_pending":
            if re.search(
                r"\b(?:всегда|постоянно)\b.{0,50}\b(?:охранник|оператор)\w*|"
                r"\b(?:охранник|оператор)\w*\b.{0,50}\b(?:всегда|постоянно)\b|"
                r"\b(?:охранник|дежурн\w*|оператор)\w*\b.{0,55}\b(?:дежурит|откроет|открывает|пропустит|пропускает)\b",
                clean, re.I,
            ) and not re.search(
                r"\b(?:только\s+для\s+исключ|исключительн|не\s+явля\w*.{0,35}резерв)\b",
                clean, re.I,
            ):
                reasons.append("operator_as_automated_fallback")
            if re.search(
                r"\b(?:экран|табло|терминал)\w*\b.{0,90}\b(?:покаж|увид|инструкц|подсказ)",
                clean, re.I,
            ) and not re.search(
                r"\b(?:не\s+подтвержден|нельзя\s+(?:утверждать|определить)|только\s+после\s+подтверждения)\b",
                clean, re.I,
            ):
                reasons.append("unsupported_lane_guidance_claim")
            if not re.search(
                r"(?:автоматическ\w*\s+резерв|резерв\w*.{0,90}(?:не\s+выбран|зависит|нужно\s+(?:выбрать|определить)))",
                clean, re.I,
            ):
                reasons.append("fallback_scenario_not_resolved")
            return reasons
        if re.search(
            r"\b(?:qr|карт\w*|билет\w*|rfid|радиомет\w*)\b.{0,55}\b(?:или|и|,)\s*оператор\w*",
            clean, re.I,
        ):
            reasons.append("manual_recovery_misclassified_as_fallback_identifier")
        if (
            package.get("decision_type") == "access_identifier_selection"
            and "резерв" in clean
            and not re.search(r"\b(?:сотрудник|арендатор|гост)\w*\b", clean, re.I)
        ):
            reasons.append("fallback_not_segment_specific")
        if re.search(r"\bкарт\w*\s+или\s+билет\w*\b.{0,80}\b(?:высок\w*|больш\w*)\s+нагрузк\w*", clean, re.I):
            reasons.extend((
                "universal_operational_claim", "mixed_tradeoff_categories",
                "operational_claim_missing_conditions", "decision_relevant_comparative_claim_not_verified",
            ))
        if re.search(
            r"(?:гостев\w+\s+заявк\w*\b.{0,30}\b(?:является|служит|как)\b.{0,20}\bидентификатор|"
            r"идентификац\w*\s+(?:через|по)\s+гостев\w+\s+заявк\w*)", clean, re.I,
        ):
            reasons.extend(("authorization_misclassified_as_identifier", "guest_workflow_and_identifier_conflated"))
        candidates = package.get("candidate_options") or package.get("candidate_credentials_requiring_confirmation") or []
        candidate_scope = clean
        package_question = str(package.get("next_question") or "").casefold().strip()
        if package_question:
            candidate_scope = candidate_scope.replace(package_question, "")
        candidate_scope = " ".join(
            sentence for sentence in re.split(r"(?<=[.!?])\s+", candidate_scope)
            if is_candidate_recommendation_context(sentence)
        )
        for item in candidates:
            identifier = str(item.get("identifier") or (item.get("credential") or {}).get("type") or "")
            patterns = {
                "guest_qr": r"\bqr\b", "guest_card": r"\bкарт\w*\b",
                "parking_card": r"\bкарт\w*\b", "radio_tag": r"\b(?:rfid|радиомет\w*)\b",
                "parking_ticket": r"\bбилет\w*\b",
            }
            if patterns.get(identifier) and re.search(patterns[identifier], candidate_scope, re.I):
                reasons.append("fallback_requires_unconfirmed_reader")
                break
        return list(dict.fromkeys(reasons))
