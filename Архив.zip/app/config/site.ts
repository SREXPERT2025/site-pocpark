export const siteConfig = {
  name: "РОСПАРК",
  companyName: "СР-Эксперт",
  companyStartYear: 2010,
  phone: "+7 (499) 321-20-40",
  phoneHref: "tel:+74993212040",
  // Основной корпоративный email (публичный, для заявок)
  email: "sales@rospark.ru",
  emailHref: "mailto:sales@rospark.ru",

  // Для закрывающих документов (пока используем единый корпоративный email)
  docsEmail: "sales@rospark.ru",
  docsEmailHref: "mailto:sales@rospark.ru",
};
