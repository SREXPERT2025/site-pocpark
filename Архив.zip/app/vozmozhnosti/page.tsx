import FeaturesShowcase from '@/app/components/FeaturesShowcase';
export default function Page(){return <FeaturesShowcase/>;}