export default function PainPoints() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Типовые риски для службы безопасности на парковке
          </h2>
          <p className="text-slate-600 text-lg">
            Парковка — это точка контроля доступа и источник инцидентов: конфликтов, нарушений,
            «проездов по звонку», потерь доказательств и размывания ответственности.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* 1 */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <div className="text-4xl mb-4">🛑</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Нет управляемого контроля доступа
            </h3>
            <p className="text-slate-600">
              Проезды “по знакомству”, ручные решения охраны, отсутствие единого сценария блокировок и
              правил допуска для гостей/арендаторов/служб.
            </p>
          </div>

          {/* 2 */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <div className="text-4xl mb-4">📸</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Слабая доказательная база по инцидентам
            </h3>
            <p className="text-slate-600">
              Нет связки “проезд → событие → фото/номер → операторское действие”.
              Сложно доказать факт нарушения, восстановить хронологию и ответственных.
            </p>
          </div>

          {/* 3 */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <div className="text-4xl mb-4">👤</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Человеческий фактор и “серые” сценарии
            </h3>
            <p className="text-slate-600">
              Ручное управление шлагбаумом, устные “разрешения”, отсутствие прозрачного журнала действий —
              всё это рождает уязвимости и конфликтные ситуации.
            </p>
          </div>

          {/* 4 */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <div className="text-4xl mb-4">⏱️</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Нет быстрых реакций на нарушителей
            </h3>
            <p className="text-slate-600">
              Нет “черных списков”, правил по долгам/нарушениям, автоматической блокировки и
              сигналов СБ при повторных попытках въезда.
            </p>
          </div>

          {/* 5 */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <div className="text-4xl mb-4">📂</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Архив событий и доступы не стандартизированы
            </h3>
            <p className="text-slate-600">
              Трудно понять, кто и что смотрел/менял. Нет ролевой модели: СБ, охрана, администратор,
              инженер, управляющий — все “в одном аккаунте”.
            </p>
          </div>

          {/* 6 */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <div className="text-4xl mb-4">🧩</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Разрозненные системы на объекте
            </h3>
            <p className="text-slate-600">
              Парковка отдельно, СКУД отдельно, видеонаблюдение отдельно.
              Нет единой картины: события не коррелируются, расследования занимают время.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
