export default function Reliability() {
  return (
    <section id="reliability" className="py-20 bg-slate-900 text-white">
      <div className="container mx-auto px-4">

        <h2 className="text-3xl font-bold mb-12 text-center">
          Отказоустойчивость и работа в нештатных ситуациях
        </h2>

        <div className="grid md:grid-cols-2 gap-10">

          {/* ЛЕВАЯ КОЛОНКА */}
          <div className="space-y-8">

            <div className="flex gap-4">
              <div className="text-3xl text-red-400">⚡</div>
              <div>
                <h3 className="text-xl font-bold mb-1">
                  Отключение электропитания
                </h3>
                <p className="text-slate-300">
                  Ключевые узлы системы (контроллеры, камеры, стойки)
                  подключаются через ИБП.  
                  КПП продолжает работу в автономном режиме.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-3xl text-red-400">🌐</div>
              <div>
                <h3 className="text-xl font-bold mb-1">
                  Потеря интернет-соединения
                </h3>
                <p className="text-slate-300">
                  Проезды продолжают фиксироваться локально.
                  Все события сохраняются в буфере и
                  синхронизируются после восстановления связи.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-3xl text-red-400">🔌</div>
              <div>
                <h3 className="text-xl font-bold mb-1">
                  Обрыв линий связи
                </h3>
                <p className="text-slate-300">
                  Поддержка резервных каналов (LTE / второй провайдер).
                  Критические решения принимаются на уровне контроллеров,
                  без зависимости от центрального сервера.
                </p>
              </div>
            </div>

          </div>

          {/* ПРАВАЯ КОЛОНКА */}
          <div className="space-y-8">

            <div className="flex gap-4">
              <div className="text-3xl text-red-400">🧠</div>
              <div>
                <h3 className="text-xl font-bold mb-1">
                  Локальная логика принятия решений
                </h3>
                <p className="text-slate-300">
                  Контроллеры работают автономно:
                  списки доступа, блокировки и сценарии
                  не зависят от облака или оператора.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-3xl text-red-400">📋</div>
              <div>
                <h3 className="text-xl font-bold mb-1">
                  Журналирование и аудит
                </h3>
                <p className="text-slate-300">
                  Все действия операторов и автоматических сценариев
                  логируются. Возможна последующая проверка и разбор
                  инцидентов.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="text-3xl text-red-400">🛑</div>
              <div>
                <h3 className="text-xl font-bold mb-1">
                  Ручной режим и аварийные сценарии
                </h3>
                <p className="text-slate-300">
                  Предусмотрены регламентированные режимы:
                  полный запрет проезда, свободный проезд,
                  управление по кнопке охраны.
                </p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
