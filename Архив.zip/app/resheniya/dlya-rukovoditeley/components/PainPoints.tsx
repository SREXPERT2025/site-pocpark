export default function PainPoints() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">

        {/* Заголовок */}
        <div className="max-w-3xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Типовые проблемы парковки глазами руководителя
          </h2>
          <p className="text-lg text-slate-600">
            Даже при хорошем трафике парковка часто остаётся источником потерь,
            конфликтов и неконтролируемых расходов.
          </p>
        </div>

        {/* Карточки болей */}
        <div className="grid md:grid-cols-3 gap-8">

          {/* Боль 1 */}
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <div className="text-4xl mb-4">❌</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Непрозрачная выручка
            </h3>
            <p className="text-slate-600">
              Невозможно точно понять, сколько автомобилей заехало,
              сколько оплатили и сколько денег реально поступило.
              Человеческий фактор и «серые» схемы съедают доход.
            </p>
          </div>

          {/* Боль 2 */}
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <div className="text-4xl mb-4">📉</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Операционные потери
            </h3>
            <p className="text-slate-600">
              Зарплаты парковщиков, инкассация, расходные материалы,
              ошибки персонала и простои оборудования напрямую
              снижают чистый операционный доход (NOI).
            </p>
          </div>

          {/* Боль 3 */}
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <div className="text-4xl mb-4">😡</div>
            <h3 className="text-xl font-bold mb-3 text-slate-900">
              Недовольство арендаторов и клиентов
            </h3>
            <p className="text-slate-600">
              Очереди на выезде, сложные сценарии оплаты,
              неработающие карты и конфликтные ситуации
              напрямую бьют по репутации объекта.
            </p>
          </div>

        </div>

        {/* Усиливающий текст */}
        <div className="max-w-4xl mx-auto mt-14 text-center">
          <p className="text-lg text-slate-700">
            В результате парковка перестаёт быть управляемым активом
            и превращается в постоянную головную боль для управляющей компании.
          </p>
        </div>

      </div>
    </section>
  );
}
