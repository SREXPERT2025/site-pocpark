# Лидогенерация: Email + Telegram

Ниже — минимальная инструкция по включению отправки заявок из `LeadForm` и из квиза.

## 1) Что отправляем

Все формы отправляют POST JSON на endpoint:

- `POST /api/lead`

Сервер дублирует заявку:

- на Email (можно 2–3 адреса через запятую)
- в Telegram (можно 1–N чатов через запятую)

## 2) Переменные окружения

Создайте файл `.env.local` в корне проекта и добавьте настройки.

### Email (SMTP)

Обязательно для email-канала:

```bash
LEAD_EMAIL_TO="sales@company.ru,ceo@company.ru"
LEAD_EMAIL_FROM="ROSPARK <no-reply@company.ru>"

SMTP_HOST="smtp.company.ru"
SMTP_PORT="465"
SMTP_SECURE="true"
SMTP_USER="no-reply@company.ru"
SMTP_PASS="********"
```

Пояснения:

- `LEAD_EMAIL_TO` — список получателей через запятую.
- `SMTP_SECURE` — `true` для 465, `false` для 587.

### Telegram

```bash
LEAD_TELEGRAM_BOT_TOKEN="123456:ABCDEF..."
LEAD_TELEGRAM_CHAT_IDS="-1001234567890,123456789"
```

Пояснения:

- `LEAD_TELEGRAM_CHAT_IDS` — можно несколько, через запятую.
- Для канала/группы обычно нужен id вида `-100...`.

## 3) Установка зависимостей

В этой версии добавлен пакет `nodemailer`.

После обновления исходников выполните:

```bash
npm install
npm run build
npm run start
```

## 4) Быстрая проверка

1) Откройте главную и отправьте заявку внизу страницы.
2) Проверьте: пришло письмо и/или сообщение в Telegram.

Если настроен только один канал (только Email или только Telegram) — заявка будет отправлена в доступный канал.
