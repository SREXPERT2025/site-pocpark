export const siteConfig = {
  phone: "+7 (499) 321-20-40",
  phoneHref: "tel:+74993212040",
  email: "is@srexpert.su",
  emailHref: "mailto:is@srexpert.su",
};
